import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl, Qt
from PyQt5.QtGui import QIcon
from logger import get_logger

logger = get_logger("window")

API_BASE = "http://127.0.0.1:5000"


class OverlayWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Twitch Chat Overlay")
        self.resize(1100, 700)
        self.setMinimumSize(900, 600)
        self.setWindowIcon(QIcon("icon.ico"))  # или полный путь
        # Dark title bar (Windows)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #0a0a0f;
            }
        """)

        self.webview = QWebEngineView()
        self.webview.setUrl(QUrl(f"{API_BASE}/app"))
        self.setCentralWidget(self.webview)

        logger.info("Окно WebEngine создано")


def run_overlay_window():
    logger.info("Запуск оконного приложения")
    app = QApplication(sys.argv)
    app.setApplicationName("Twitch Chat Overlay")
    window = OverlayWindow()
    window.show()
    logger.info("Окно отображено")
    sys.exit(app.exec_())