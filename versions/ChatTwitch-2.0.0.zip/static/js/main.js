// ================================================================
//  JAVASCRIPT – исправленная версия (только BTTV, CORS-safe)
// ================================================================

if (typeof io === 'undefined') {
    document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;color:#ff4757;font-size:18px;">Ошибка загрузки Socket.IO</div>';
    throw new Error('Socket.IO not loaded');
}

const socket = io();

// ============ TABS ============
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById(this.dataset.tab).classList.add('active');
    });
});

// ============ BAN LIST ============
let banWordList = [];
let suppressSave = false;

function updateBanList(silent = false) {
    const input = document.getElementById('banWords').value;
    const newList = input.split(',').map(w => w.trim().toLowerCase()).filter(w => w.length > 0);
    if (JSON.stringify(newList) === JSON.stringify(banWordList)) return;
    banWordList = newList;
    localStorage.setItem('banWords', input);
    recensorAllMessages();
    if (!silent) {
        saveTTSSettings({ ban_words: input });
    }
}

function censorText(text) {
    let censored = text;
    let hasCensored = false;
    banWordList.forEach(word => {
        const regex = new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
        if (regex.test(censored)) {
            censored = censored.replace(regex, match => '★'.repeat(match.length));
            hasCensored = true;
        }
    });
    return { text: censored, hasCensored };
}

function recensorAllMessages() {
    allMessages.forEach(msg => {
        const result = censorText(msg.originalMessage);
        msg.message = result.text;
        const textNode = msg.el.querySelector('.chat-text');
        if (textNode) {
            textNode.innerHTML = replaceEmotes(result.text);
        }
        msg.el.classList.toggle('censored', result.hasCensored);
    });
    filterMessages();
}

function onBanWordsChange() {
    updateBanList(false);
}

// ============ EMOTES (только BTTV) ============
let emoteMap = {};

async function loadBTTVEmotes() {
    try {
        const resp = await fetch('https://api.betterttv.net/3/cached/emotes/global');
        if (!resp.ok) throw new Error('BTTV API error');
        const data = await resp.json();
        data.forEach(emote => {
            const url = `https://cdn.betterttv.net/emote/${emote.id}/3x.webp`;
            emoteMap[emote.code] = url;
        });
        console.log(`Загружено ${data.length} BTTV-эмоций`);
    } catch (e) {
        console.warn('Не удалось загрузить BTTV-эмоции:', e);
    }
}

async function loadAllEmotes() {
    try {
        const resp = await fetch('/api/emotes');
        console.log('Ответ /api/emotes:', resp.status, resp.statusText);
        if (!resp.ok) throw new Error('Emotes API error');
        const data = await resp.json();
        emoteMap = data;
        console.log(`Загружено ${Object.keys(emoteMap).length} эмоций, пример:`, Object.keys(emoteMap).slice(0,5));
    } catch (e) {
        console.warn('Не удалось загрузить эмоции:', e);
        emoteMap = {};
    }
}

function replaceEmotes(text) {
    const parts = text.split(/(\s+)/);
    return parts.map(part => {
        if (emoteMap[part]) {
            return `<img class="chat-emote" src="${emoteMap[part]}" alt="${part}" title="${part}" />`;
        }
        return part;
    }).join('');
}

// ============ AVATARS ============
const avatarCache = {};
async function loadAvatar(username) {
    if (avatarCache[username]) return avatarCache[username];
    try {
        const resp = await fetch(`/api/avatar/${encodeURIComponent(username)}`);
        if (resp.ok) {
            const data = await resp.json();
            if (data.url) {
                avatarCache[username] = data.url;
                return data.url;
            }
        }
    } catch (e) {
        console.warn('Ошибка загрузки аватара для', username, e);
    }
    return null;
}

// ============ BADGES ============
function renderBadges(badges) {
    if (!badges || badges.length === 0) return '';
    let html = '';
    badges.forEach(b => {
        const src = `https://static-cdn.jtvnw.net/badges/v1/${b.name}/${b.version}`;
        html += `<img class="chat-badge" src="${src}" alt="${b.name}" title="${b.name}" />`;
    });
    return html;
}

// ============ TTS FUNCTIONS ============
function updateTTSSlider(type) {
    const volEl = document.getElementById('volumeValue');
    const rateEl = document.getElementById('rateValue');
    if (volEl) volEl.textContent = document.getElementById('ttsVolume').value + '%';
    if (rateEl) rateEl.textContent = document.getElementById('ttsRate').value + ' wpm';
    saveTTSSettings();
}

async function saveTTSSettings(extra = {}) {
    if (saveTTSSettings._pending) return;
    saveTTSSettings._pending = true;
    const payload = {
        users: document.getElementById('ttsUsers').value,
        volume: parseInt(document.getElementById('ttsVolume').value),
        rate: parseInt(document.getElementById('ttsRate').value),
        engine: document.getElementById('ttsEngine').value,
        ...extra
    };
    try {
        await fetch('/api/tts/config', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
    } catch (e) {
        console.error('Save TTS error:', e);
    } finally {
        saveTTSSettings._pending = false;
    }
}
saveTTSSettings._pending = false;

async function testTTS() {
    try {
        const resp = await fetch('/api/tts/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                text: 'Привет! Это тест синтеза речи.',
                engine: document.getElementById('ttsEngine').value,
                volume: parseInt(document.getElementById('ttsVolume').value),
                rate: parseInt(document.getElementById('ttsRate').value)
            })
        });
        const data = await resp.json();
        showToast(data.message || 'Тест запущен');
    } catch (e) {
        showToast('Ошибка TTS');
    }
}

async function stopTTS() {
    await fetch('/api/tts/stop', { method: 'POST' });
    showToast('Озвучка остановлена');
}

async function loadTTSEngines() {
    try {
        const resp = await fetch('/api/tts/engines');
        const engines = await resp.json();
        const select = document.getElementById('ttsEngine');
        if (!select) return;
        select.innerHTML = '<option value="auto">Авто</option>';
        for (const [name, info] of Object.entries(engines)) {
            if (info.available) {
                const option = document.createElement('option');
                option.value = name;
                option.textContent = name + ' ✅';
                select.appendChild(option);
            }
        }
        select.value = localStorage.getItem('ttsEngine') || 'auto';
    } catch (e) {
        console.error('Load engines error:', e);
    }
}

async function loadTTSSettings() {
    try {
        const resp = await fetch('/api/tts/config');
        const cfg = await resp.json();
        const usersInput = document.getElementById('ttsUsers');
        const volumeInput = document.getElementById('ttsVolume');
        const rateInput = document.getElementById('ttsRate');
        const volumeLabel = document.getElementById('volumeValue');
        const rateLabel = document.getElementById('rateValue');
        const engineStatus = document.getElementById('engineStatus');
        const banWordsInput = document.getElementById('banWords');

        if (usersInput) usersInput.value = (cfg.users || []).join(',');
        if (volumeInput) volumeInput.value = cfg.volume || 80;
        if (rateInput) rateInput.value = cfg.rate || 160;
        if (volumeLabel) volumeLabel.textContent = (cfg.volume || 80) + '%';
        if (rateLabel) rateLabel.textContent = (cfg.rate || 160) + ' wpm';
        if (engineStatus && cfg.engine_status) {
            engineStatus.textContent = Object.entries(cfg.engine_status)
                .map(([n, a]) => n + ': ' + (a ? '✅' : '❌')).join(' | ');
        }
        if (cfg.ban_words && cfg.ban_words.length && banWordsInput) {
            banWordsInput.value = cfg.ban_words.join(', ');
            banWordList = cfg.ban_words.map(w => w.toLowerCase());
            recensorAllMessages();
        }
    } catch (e) {
        console.error('Load TTS settings error:', e);
    }
}

// ============ GLOBAL STATE ============
const allMessages = [];
const nicknameInput = document.getElementById('nickname');
const ttlInput = document.getElementById('ttl');
const maxMessagesInput = document.getElementById('maxMessages');
const cssInput = document.getElementById('css');
const logToggle = document.getElementById('logToggle');
const showViewersToggle = document.getElementById('showViewersToggle');
const showAvatarsToggle = document.getElementById('showAvatars');
if (showAvatarsToggle) {
    showAvatarsToggle.addEventListener('change', function() {
        showAvatars = this.checked;
        updateConfig();
        // Перерисовываем все сообщения
        allMessages.forEach(msg => {
            const avatar = msg.el.querySelector('.chat-avatar');
            if (avatar) {
                if (showAvatars) {
                    avatar.style.display = '';
                    if (!avatar.src || avatar.src.includes('data:image')) {
                        loadAvatar(msg.username).then(url => {
                            if (url) avatar.src = url;
                            else avatar.style.display = 'none';
                        });
                    }
                } else {
                    avatar.style.display = 'none';
                }
            }
        });
    });
}
const toggleBtn = document.getElementById('toggleBtn');
const btnIcon = document.getElementById('btnIcon');
const btnText = document.getElementById('btnText');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const chatContainer = document.getElementById('chatContainer');
const msgCount = document.getElementById('msgCount');
const uptimeEl = document.getElementById('uptime');
const viewersCountEl = document.getElementById('viewersCount');
const viewersStatEl = document.getElementById('viewersStat');
const copyBtn = document.getElementById('copyBtn');
const searchInput = document.getElementById('searchInput');
const searchCount = document.getElementById('searchCount');
let isRunning = false;
let messageCounter = 0;
let startTime = null;
let uptimeInterval = null;
let isNearBottom = true;
let showAvatars = true; // по умолчанию

// ============ INIT ============
async function init() {
    initBanList();
    await loadAllEmotes();
    await loadTTSEngines();
    await loadTTSSettings();
    await loadAnimationSettings();
    setupAnimationSliders();
    try {
        const cfg = await fetch('/api/config').then(r => r.json());
        if (nicknameInput) nicknameInput.value = cfg.nickname || '';
        if (ttlInput) ttlInput.value = cfg.ttl || 0;
        if (maxMessagesInput) maxMessagesInput.value = cfg.max_messages || 100;
        if (cssInput) cssInput.value = cfg.css || '';
        if (logToggle) logToggle.checked = cfg.log_messages || false;
        if (showViewersToggle) showViewersToggle.checked = cfg.show_viewers_in_overlay || false;
        showAvatars = cfg.show_avatars !== undefined ? cfg.show_avatars : true;

        const status = await fetch('/api/status').then(r => r.json());
        updateUI(status.running);
        if (status.start_time) {
            startTime = new Date(status.start_time);
            updateUptime();
            uptimeInterval = setInterval(updateUptime, 1000);
        }
        messageCounter = status.message_count || 0;
        if (msgCount) msgCount.textContent = messageCounter;
        if (viewersCountEl) viewersCountEl.textContent = status.viewers || 0;
        if (viewersStatEl) viewersStatEl.textContent = status.viewers || 0;

        const historyResp = await fetch('/api/messages').then(r => r.json());
        if (historyResp.messages && historyResp.messages.length > 0 && chatContainer) {
            const empty = chatContainer.querySelector('.empty-state');
            if (empty) empty.remove();
            historyResp.messages.forEach(msg => addMessageToDOM(msg, false));
            chatContainer.scrollTop = chatContainer.scrollHeight;
            if (historyResp.start_time) startTime = new Date(historyResp.start_time);
        }
    } catch (e) {
        console.error('Init error:', e);
    }

    if (chatContainer) {
        chatContainer.addEventListener('scroll', () => {
            isNearBottom = chatContainer.scrollHeight - chatContainer.scrollTop - chatContainer.clientHeight < 60;
            updateScrollButton();
        });
    }
}

function initBanList() {
    const saved = localStorage.getItem('banWords');
    if (saved) {
        const input = document.getElementById('banWords');
        if (input) input.value = saved;
        updateBanList(true);
    }
}

function updateUI(running) {
    isRunning = running;
    if (toggleBtn) toggleBtn.classList.toggle('running', running);
    if (btnIcon) btnIcon.textContent = running ? '⏹' : '▶';
    if (btnText) btnText.textContent = running ? 'Остановить парсер' : 'Запустить парсер';
    if (statusDot) statusDot.classList.toggle('active', running);
    if (statusText) statusText.textContent = running ? 'Парсер активен' : 'Готов к работе';
    if (running) {
        if (!startTime) { startTime = new Date(); updateUptime(); uptimeInterval = setInterval(updateUptime, 1000); }
    } else {
        startTime = null;
        if (uptimeInterval) { clearInterval(uptimeInterval); uptimeInterval = null; }
        if (uptimeEl) uptimeEl.textContent = '00:00';
    }
}
async function loadAnimationSettings() {
    try {
        const resp = await fetch('/api/animation/config');
        if (!resp.ok) throw new Error('Animation API error');
        const data = await resp.json();

        const entrySelect = document.getElementById('animEntry');
        const exitSelect = document.getElementById('animExit');
        const speedSlider = document.getElementById('animSpeed');
        const delaySlider = document.getElementById('animDelay');
        const speedLabel = document.getElementById('animSpeedLabel');
        const delayLabel = document.getElementById('animDelayLabel');

        if (entrySelect) entrySelect.value = data.entry || 'fade';
        if (exitSelect) exitSelect.value = data.exit || 'fade';
        if (speedSlider) {
            speedSlider.value = data.speed || 300;
            if (speedLabel) speedLabel.textContent = data.speed || 300;
        }
        if (delaySlider) {
            delaySlider.value = data.delay || 0;
            if (delayLabel) delayLabel.textContent = data.delay || 0;
        }

        return data;
    } catch (e) {
        console.error('Load animation settings error:', e);
        return null;
    }
}

// ============ СОХРАНЕНИЕ НАСТРОЕК АНИМАЦИЙ ============
async function saveAnimationSettings() {
    const entry = document.getElementById('animEntry')?.value || 'fade';
    const exit = document.getElementById('animExit')?.value || 'fade';
    const speed = parseInt(document.getElementById('animSpeed')?.value || 300);
    const delay = parseInt(document.getElementById('animDelay')?.value || 0);

    const payload = { entry, exit, speed, delay };

    try {
        const resp = await fetch('/api/animation/config', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!resp.ok) throw new Error('Save animation error');
        showToast('Настройки анимации сохранены');
    } catch (e) {
        console.error('Save animation error:', e);
        showToast('Ошибка сохранения настроек');
    }
}

// Обновление отображения значений слайдеров
function setupAnimationSliders() {
    const speedSlider = document.getElementById('animSpeed');
    const delaySlider = document.getElementById('animDelay');
    const speedLabel = document.getElementById('animSpeedLabel');
    const delayLabel = document.getElementById('animDelayLabel');

    if (speedSlider && speedLabel) {
        speedSlider.addEventListener('input', () => {
            speedLabel.textContent = speedSlider.value;
        });
        speedSlider.addEventListener('change', saveAnimationSettings);
    }

    if (delaySlider && delayLabel) {
        delaySlider.addEventListener('input', () => {
            delayLabel.textContent = delaySlider.value;
        });
        delaySlider.addEventListener('change', saveAnimationSettings);
    }

    const entrySelect = document.getElementById('animEntry');
    const exitSelect = document.getElementById('animExit');

    if (entrySelect) entrySelect.addEventListener('change', saveAnimationSettings);
    if (exitSelect) exitSelect.addEventListener('change', saveAnimationSettings);
}

// ============ ПРЕДПРОСМОТР АНИМАЦИИ ============
function previewAnimation() {
    const entry = document.getElementById('animEntry')?.value || 'fade';
    const speed = parseInt(document.getElementById('animSpeed')?.value || 300);

    const container = document.getElementById('chatContainer');
    if (!container) return;

    const empty = container.querySelector('.empty-state');
    if (empty) empty.remove();

    const msgEl = document.createElement('div');
    msgEl.className = 'chat-msg';
    msgEl.style.setProperty('--anim-speed', (speed / 1000) + 's');
    msgEl.classList.add('anim-' + entry);

    const username = document.createElement('span');
    username.className = 'chat-username';
    username.style.color = '#7c5cfc';
    username.textContent = 'Тестовый_пользователь';

    const text = document.createElement('span');
    text.textContent = ' → Привет! Это тестовое сообщение для предпросмотра анимации.';

    msgEl.appendChild(username);
    msgEl.appendChild(document.createTextNode(': '));
    msgEl.appendChild(text);

    container.appendChild(msgEl);
    container.scrollTop = container.scrollHeight;

    setTimeout(() => {
        const exitEffect = document.getElementById('animExit')?.value || 'fade';
        msgEl.classList.remove('anim-' + entry);
        msgEl.classList.add('exit-' + exitEffect);
        msgEl.classList.add('removing');

        setTimeout(() => {
            if (msgEl.parentNode) {
                msgEl.remove();
                if (container.children.length === 0) {
                    container.innerHTML = `
                        <div class="empty-state">
                            <div class="icon">💭</div>
                            <div class="title">Чат пока пуст</div>
                            <div class="desc">Запустите парсер, указав имя канала Twitch</div>
                        </div>
                    `;
                }
            }
        }, speed + 100);
    }, 3000);

    showToast(`Предпросмотр: ${entry}`);
}
// Добавляем обработчик для кнопки предпросмотра
document.addEventListener('DOMContentLoaded', () => {
    // Кнопка предпросмотра будет добавлена в tab_settings.html
    // Обработчик можно добавить через onclick
});
async function initAnimations() {
    await loadAnimationSettings();
    setupAnimationSliders();
}
function updateUptime() {
    if (!startTime || !uptimeEl) return;
    const diff = Math.floor((Date.now() - startTime.getTime()) / 1000);
    const h = Math.floor(diff / 3600);
    const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
    const s = (diff % 60).toString().padStart(2, '0');
    uptimeEl.textContent = h > 0 ? `${h}:${m}:${s}` : `${m}:${s}`;
}
function setupAnimationSliders() {
    const speedSlider = document.getElementById('animSpeed');
    const delaySlider = document.getElementById('animDelay');
    const speedLabel = document.getElementById('animSpeedLabel');
    const delayLabel = document.getElementById('animDelayLabel');

    if (speedSlider && speedLabel) {
        speedSlider.addEventListener('input', () => {
            speedLabel.textContent = speedSlider.value;
        });
        speedSlider.addEventListener('change', saveAnimationSettings);
    }

    if (delaySlider && delayLabel) {
        delaySlider.addEventListener('input', () => {
            delayLabel.textContent = delaySlider.value;
        });
        delaySlider.addEventListener('change', saveAnimationSettings);
    }

    const entrySelect = document.getElementById('animEntry');
    const exitSelect = document.getElementById('animExit');

    if (entrySelect) entrySelect.addEventListener('change', saveAnimationSettings);
    if (exitSelect) exitSelect.addEventListener('change', saveAnimationSettings);
}
function updateScrollButton() {
    const btn = document.getElementById('scrollBottomBtn');
    if (btn) btn.classList.toggle('visible', !isNearBottom && allMessages.length > 5);
}

function scrollToBottom() {
    if (chatContainer) {
        chatContainer.scrollTop = chatContainer.scrollHeight;
        isNearBottom = true;
        updateScrollButton();
    }
}

function showToast(message) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => toast.classList.remove('show'), 2000);
}

function copyOverlayURL() {
    const url = window.location.origin + '/overlay';
    const ta = document.createElement('textarea');
    ta.value = url;
    ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta);
    ta.select();
    try {
        document.execCommand('copy');
        if (copyBtn) {
            copyBtn.classList.add('success');
            copyBtn.innerHTML = '✅ Скопировано!';
        }
        showToast('URL скопирован');
        setTimeout(() => {
            if (copyBtn) {
                copyBtn.classList.remove('success');
                copyBtn.innerHTML = '📋 Копировать URL';
            }
        }, 2000);
    } catch (e) {
        prompt('Скопируйте вручную:', url);
    }
    document.body.removeChild(ta);
}

async function toggleParser() {
    if (isRunning) {
        await fetch('/api/stop', { method: 'POST' });
        updateUI(false);
    } else {
        const nickname = nicknameInput ? nicknameInput.value.trim() : '';
        if (!nickname) { alert('Введите имя канала'); return; }
        const resp = await fetch('/api/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                nickname,
                ttl: parseInt(ttlInput ? ttlInput.value : 0) || 0,
                max_messages: parseInt(maxMessagesInput ? maxMessagesInput.value : 100) || 100,
                css: cssInput ? cssInput.value : '',
                log_messages: logToggle ? logToggle.checked : false,
                show_viewers_in_overlay: showViewersToggle ? showViewersToggle.checked : false,
                show_avatars: showAvatars
            })
        });
        if (resp.ok) {
            updateUI(true);
            if (chatContainer) {
                chatContainer.innerHTML = `<div class="empty-state"><div class="icon">⏳</div><div class="title">Ожидание сообщений...</div><div class="desc">Подключение к чату <strong>${nickname}</strong></div></div>`;
            }
            allMessages.length = 0;
            messageCounter = 0;
            if (msgCount) msgCount.textContent = '0';
        }
    }
}

async function updateConfig() {
    const payload = {
        ttl: parseInt(ttlInput ? ttlInput.value : 0) || 0,
        max_messages: parseInt(maxMessagesInput ? maxMessagesInput.value : 100) || 100,
        css: cssInput ? cssInput.value : '',
        log_messages: logToggle ? logToggle.checked : false,
        show_viewers_in_overlay: showViewersToggle ? showViewersToggle.checked : false,
        show_avatars: showAvatars
    };
    await fetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
}

async function clearMessages() {
    await fetch('/api/clear', { method: 'POST' });
    if (chatContainer) {
        chatContainer.innerHTML = `<div class="empty-state"><div class="icon">💭</div><div class="title">Чат очищен</div><div class="desc">Новые сообщения появятся здесь</div></div>`;
    }
    allMessages.length = 0;
    messageCounter = 0;
    if (msgCount) msgCount.textContent = '0';
    if (searchCount) searchCount.textContent = '';
}

function filterMessages() {
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    let visibleCount = 0;
    allMessages.forEach(msg => {
        let show = true;
        if (query && !(msg.username + ' ' + msg.message).toLowerCase().includes(query)) show = false;
        msg.el.classList.toggle('hidden', !show);
        if (show) {
            visibleCount++;
            if (query) highlightText(msg.el, query);
            else removeHighlight(msg.el);
        } else removeHighlight(msg.el);
    });
    if (searchCount) searchCount.textContent = query ? `Найдено: ${visibleCount}` : '';
}

function highlightText(el, query) {
    removeHighlight(el);
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
        const text = node.textContent;
        const lower = text.toLowerCase();
        if (lower.includes(query)) {
            const span = document.createElement('span');
            const idx = lower.indexOf(query);
            span.textContent = text.substring(0, idx);
            const mark = document.createElement('mark');
            mark.className = 'search-highlight';
            mark.textContent = text.substring(idx, idx + query.length);
            span.appendChild(mark);
            span.appendChild(document.createTextNode(text.substring(idx + query.length)));
            node.parentNode.replaceChild(span, node);
        }
    });
}

function removeHighlight(el) {
    el.querySelectorAll('.search-highlight').forEach(mark => {
        const parent = mark.parentNode;
        parent.replaceChild(document.createTextNode(mark.textContent), mark);
        parent.normalize();
    });
}

// ============ ДОБАВЛЕНИЕ СООБЩЕНИЯ В DOM ============
function addMessageToDOM(data, animate = true) {
    if (!chatContainer) return;
    const empty = chatContainer.querySelector('.empty-state');
    if (empty) empty.remove();

    const msgEl = document.createElement('div');
    msgEl.className = 'chat-msg';
    if (!animate) msgEl.style.animation = 'none';

    const original = data.message;
    const censored = censorText(original);
    const displayMessage = censored.text;

    // ---- АВАТАР (только если включен) ----
    const avatarImg = document.createElement('img');
    avatarImg.className = 'chat-avatar';
    avatarImg.alt = data.username;
    if (showAvatars) {
        loadAvatar(data.username).then(url => {
            if (url) avatarImg.src = url;
            else avatarImg.style.display = 'none';
        });
        avatarImg.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"%3E%3Ccircle cx="16" cy="16" r="16" fill="%23333"/%3E%3Ctext x="16" y="20" text-anchor="middle" fill="%23999" font-size="14" font-family="sans-serif"%3E?%3C/text%3E%3C/svg%3E';
    } else {
        avatarImg.style.display = 'none';
    }

    // ---- БАДЖИ ----
    const badgesHtml = renderBadges(data.badges || []);
    const badgesSpan = document.createElement('span');
    badgesSpan.className = 'chat-badges';
    badgesSpan.innerHTML = badgesHtml;

    // ---- ИМЯ (кликабельное) ----
    const userSpan = document.createElement('span');
    userSpan.className = 'chat-username';
    userSpan.style.color = data.color || '#eaeaf0';
    userSpan.textContent = data.username;
    userSpan.dataset.username = data.username;

    // ---- ТЕКСТ ----
    const textSpan = document.createElement('span');
    textSpan.className = 'chat-text';
    textSpan.innerHTML = replaceEmotes(displayMessage);

    // ---- ВРЕМЯ ----
    const timeSpan = document.createElement('span');
    timeSpan.className = 'chat-time';
    const ts = data.timestamp ? new Date(data.timestamp) : new Date();
    timeSpan.textContent = ts.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    // Собираем
    const userContainer = document.createElement('span');
    userContainer.className = 'chat-user-container';
    userContainer.appendChild(avatarImg);
    userContainer.appendChild(badgesSpan);
    userContainer.appendChild(userSpan);

    msgEl.appendChild(userContainer);
    msgEl.appendChild(document.createTextNode(': '));
    msgEl.appendChild(textSpan);
    msgEl.appendChild(timeSpan);

    if (censored.hasCensored) msgEl.classList.add('censored');
    chatContainer.appendChild(msgEl);

    const msgObj = {
        username: data.username,
        originalMessage: original,
        message: displayMessage,
        color: data.color,
        timestamp: data.timestamp || new Date().toISOString(),
        el: msgEl
    };
    allMessages.push(msgObj);

    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    if (query && !(data.username + ' ' + displayMessage).toLowerCase().includes(query)) msgEl.classList.add('hidden');
    else if (query) highlightText(msgEl, query);

    if (isNearBottom) chatContainer.scrollTop = chatContainer.scrollHeight;
    updateScrollButton();

    const ttl = parseInt(ttlInput ? ttlInput.value : 0) || 0;
    if (ttl > 0) setTimeout(() => {
        msgEl.style.opacity = '0';
        msgEl.style.transform = 'translateX(20px)';
        msgEl.style.transition = '0.3s';
        setTimeout(() => {
            if (msgEl.parentNode) {
                msgEl.remove();
                const idx = allMessages.indexOf(msgObj);
                if (idx > -1) allMessages.splice(idx, 1);
            }
        }, 300);
    }, ttl * 1000);
}

// ============ SOCKET EVENTS ============
socket.on('chat_message', data => {
    addMessageToDOM(data, true);
    messageCounter++;
    if (msgCount) msgCount.textContent = messageCounter;
});
socket.on('messages_clear', () => {
    if (chatContainer) {
        chatContainer.innerHTML = `<div class="empty-state"><div class="icon">💭</div><div class="title">Чат очищен</div><div class="desc">Новые сообщения появятся здесь</div></div>`;
    }
    allMessages.length = 0;
    messageCounter = 0;
    if (msgCount) msgCount.textContent = '0';
    if (searchCount) searchCount.textContent = '';
});
socket.on('parser_status', data => {
    updateUI(data.running);
    startTime = data.start_time ? new Date(data.start_time) : null;
});
socket.on('config_update', data => {
    if (ttlInput) ttlInput.value = data.ttl || 0;
    if (maxMessagesInput) maxMessagesInput.value = data.max_messages || 100;
    if (cssInput) cssInput.value = data.css || '';
    if (logToggle) logToggle.checked = data.log_messages || false;
    if (showViewersToggle) showViewersToggle.checked = data.show_viewers_in_overlay || false;
    // Обновляем переменную showAvatars
    showAvatars = data.show_avatars !== undefined ? data.show_avatars : true;
    // Перерисовываем сообщения, чтобы применить изменения
    recensorAllMessages(); // перецензурируем
    // Обновляем отображение аватаров – проходим по всем сообщениям
    allMessages.forEach(msg => {
        const avatar = msg.el.querySelector('.chat-avatar');
        if (avatar) {
            if (showAvatars) {
                avatar.style.display = '';
                // Если аватар не загружен – попробуем загрузить
                if (!avatar.src || avatar.src.includes('data:image')) {
                    loadAvatar(msg.username).then(url => {
                        if (url) avatar.src = url;
                        else avatar.style.display = 'none';
                    });
                }
            } else {
                avatar.style.display = 'none';
            }
        }
    });
});
socket.on('tts_update', data => {
    const usersInput = document.getElementById('ttsUsers');
    if (usersInput && data.users) usersInput.value = Array.isArray(data.users) ? data.users.join(',') : data.users;
    const volumeInput = document.getElementById('ttsVolume');
    const volumeLabel = document.getElementById('volumeValue');
    if (volumeInput && data.volume !== undefined) { volumeInput.value = data.volume; if (volumeLabel) volumeLabel.textContent = data.volume + '%'; }
    const rateInput = document.getElementById('ttsRate');
    const rateLabel = document.getElementById('rateValue');
    if (rateInput && data.rate !== undefined) { rateInput.value = data.rate; if (rateLabel) rateLabel.textContent = data.rate + ' wpm'; }
    if (data.ban_words) {
        const banInput = document.getElementById('banWords');
        if (banInput) banInput.value = data.ban_words.join(', ');
        updateBanList(true);
    }
});
socket.on('viewers_update', data => {
    if (viewersCountEl) viewersCountEl.textContent = data.count;
    if (viewersStatEl) viewersStatEl.textContent = data.count;
});

// ============ BIND EVENTS ============
const banWordsInput = document.getElementById('banWords');
if (banWordsInput) banWordsInput.addEventListener('change', onBanWordsChange);
const ttsVolume = document.getElementById('ttsVolume');
if (ttsVolume) ttsVolume.addEventListener('input', () => updateTTSSlider('volume'));
const ttsRate = document.getElementById('ttsRate');
if (ttsRate) ttsRate.addEventListener('input', () => updateTTSSlider('rate'));
const ttsEngine = document.getElementById('ttsEngine');
if (ttsEngine) ttsEngine.addEventListener('change', saveTTSSettings);
const ttsUsers = document.getElementById('ttsUsers');
if (ttsUsers) ttsUsers.addEventListener('change', saveTTSSettings);
if (logToggle) logToggle.addEventListener('change', updateConfig);
if (showViewersToggle) showViewersToggle.addEventListener('change', updateConfig);
if (maxMessagesInput) maxMessagesInput.addEventListener('change', updateConfig);
if (ttlInput) ttlInput.addEventListener('change', updateConfig);
if (cssInput) cssInput.addEventListener('change', updateConfig);
if (searchInput) searchInput.addEventListener('input', filterMessages);

document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); toggleParser(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); if (nicknameInput) { nicknameInput.focus(); nicknameInput.select(); } }
    if ((e.ctrlKey || e.metaKey) && e.key === 'f') { e.preventDefault(); if (searchInput) searchInput.focus(); }
});

// ============ КЛИК ПО НИКУ ДЛЯ ОТКРЫТИЯ КАНАЛА ============
if (chatContainer) {
    chatContainer.addEventListener('click', function(e) {
        const target = e.target.closest('.chat-username');
        if (target) {
            const username = target.dataset.username || target.textContent.trim();
            if (username) {
                // Отправляем запрос на сервер для открытия браузера
                fetch('/api/open_url', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ url: `https://twitch.tv/${username}` })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'ok') {
                        console.log(`Открыт канал: ${username}`);
                    } else {
                        console.error('Ошибка:', data.message);
                        // Fallback: открыть в новой вкладке браузера
                        window.open(`https://twitch.tv/${username}`, '_blank');
                    }
                })
                .catch(error => {
                    console.error('Ошибка запроса:', error);
                    // Fallback: открыть в новой вкладке браузера
                    window.open(`https://twitch.tv/${username}`, '_blank');
                });
            }
        }
    });
}

// Запуск инициализации
init();