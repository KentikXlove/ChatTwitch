import logging
import os
import sys
from datetime import datetime


class AppLogger:
    _initialized = False

    @classmethod
    def setup(cls, log_dir="logs", level=logging.DEBUG):
        if cls._initialized:
            return
        cls._initialized = True
        os.makedirs(log_dir, exist_ok=True)
        date_str = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(log_dir, f"log{date_str}.txt")
        fmt = "[%(asctime)s][%(levelname)s][%(name)s] %(message)s"
        datefmt = "%H:%M:%S"
        formatter = logging.Formatter(fmt, datefmt=datefmt)

        root_logger = logging.getLogger()
        root_logger.setLevel(level)

        # Файловый handler
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(level)
        root_logger.addHandler(file_handler)

        # Консольный handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)  # В консоль только INFO+
        root_logger.addHandler(console_handler)

        # Подавление лишних логов
        logging.getLogger('werkzeug').setLevel(logging.WARNING)
        logging.getLogger('socketio').setLevel(logging.WARNING)
        logging.getLogger('engineio').setLevel(logging.WARNING)


def get_logger(name):
    return logging.getLogger(name)