import requests
import os
import re


def download_large_from_google_drive(file_id, destination):
    """
    Скачивание больших файлов с Google Drive (обработка предупреждения)
    """
    # Начинаем с получения страницы с предупреждением
    url = "https://drive.google.com/uc"
    params = {'id': file_id, 'export': 'download'}

    session = requests.Session()
    response = session.get(url, params=params)

    # Проверяем, есть ли форма для подтверждения
    if 'uc-download-link' in response.text or 'confirm' in response.text:
        print("🔍 Обнаружено предупреждение о вирусах, подтверждаем...")

        # Извлекаем все параметры из формы
        import re
        form_data = {}

        # Ищем все hidden поля
        hidden_fields = re.findall(r'<input type="hidden" name="([^"]+)" value="([^"]+)"', response.text)
        for name, value in hidden_fields:
            form_data[name] = value

        # Ищем action формы
        action_match = re.search(r'<form[^>]+action="([^"]+)"', response.text)
        if action_match:
            action_url = action_match.group(1)
        else:
            action_url = "https://drive.usercontent.google.com/download"

        # Добавляем параметры из URL
        for key, value in params.items():
            if key not in form_data:
                form_data[key] = value

        print(f"📋 Параметры формы: {form_data}")

        # Отправляем запрос на скачивание
        download_response = session.get(action_url, params=form_data, stream=True)

        # Проверяем, не перенаправили ли нас
        if download_response.history:
            print("🔄 Следование по перенаправлению...")
            final_response = download_response.history[-1]
            if final_response.status_code == 302:
                redirect_url = final_response.headers.get('Location')
                if redirect_url:
                    download_response = session.get(redirect_url, stream=True)

        # Сохраняем файл
        if download_response.status_code == 200:
            total_size = int(download_response.headers.get('content-length', 0))
            print(f"📦 Размер файла: {total_size / (1024 * 1024):.2f} MB")

            with open(destination, 'wb') as f:
                downloaded = 0
                for chunk in download_response.iter_content(chunk_size=32768):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            print(f'\r📥 Загрузка: {percent:.1f}% ({downloaded // 1024}/{total_size // 1024} KB)',
                                  end='')

            print(f"\n✅ Файл сохранен: {destination}")
            print(f"📊 Размер: {os.path.getsize(destination) / (1024 * 1024):.2f} MB")
            return True
        else:
            print(f"❌ Ошибка скачивания: {download_response.status_code}")
            return False
    else:
        print("⚠️ Страница не содержит форму подтверждения")
        return False


# Использование
file_id = "19T1SC79tvlKysW8k7kHCKyVn5-O56ySj"
download_large_from_google_drive(file_id, "ChatTwitch-1.2.0.zip")