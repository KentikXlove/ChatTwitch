from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
from parser import TwitchIRC
from logger import get_logger
from data.version import VERSION
from settings import load_config, save_config, DEFAULT_CONFIG
from datetime import datetime
import threading
import subprocess
import platform
import time
import requests

logger = get_logger("web")

app = Flask(__name__)
app.config['SECRET_KEY'] = 'twitch-chat-overlay-secret-2024'
socketio = SocketIO(
    app,
    async_mode='threading',
    cors_allowed_origins="*",
    logger=False,
    engineio_logger=False,
    ping_timeout=60,
    ping_interval=25
)

parser = TwitchIRC(socketio)
current_config = load_config()

message_history = []
message_lock = threading.Lock()
start_time = None

# TTS настройки (оставляем без изменений)
tts_settings = {
    'enabled': True,
    'users': [],
    'volume': 80,
    'rate': 160,
    'engine': 'auto',
    'ban_words': []
}
tts_queue = []
tts_lock = threading.Lock()
tts_engine_instance = None

viewers_count = 0
viewers_running = False
viewers_thread = None
VIEWERS_UPDATE_INTERVAL = 60

logger.info(f"Конфигурация загружена: nickname={current_config.get('nickname')}")
logger.info(f"ОС: {platform.system()} {platform.release()}")

# ==================== TTS ENGINE ====================

class TTSEngine:
    def __init__(self):
        self.name = "base"
        self.available = False
    def speak(self, text, volume=80, rate=160):
        raise NotImplementedError
    def stop(self):
        pass

class Pyttsx3Engine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "pyttsx3"
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
            self.available = True
            voices = self.engine.getProperty('voices')
            logger.info(f"pyttsx3: найдено {len(voices)} голосов")
            for v in voices:
                logger.debug(f"  - {v.name} ({v.id}) [{', '.join(v.languages)}]")
            russian_voice = None
            for v in voices:
                if 'russian' in v.name.lower() or 'ru' in v.id.lower():
                    russian_voice = v.id
                    break
            if russian_voice:
                self.engine.setProperty('voice', russian_voice)
                logger.info(f"pyttsx3: установлен русский голос")
        except ImportError:
            logger.warning("pyttsx3 не установлен. Установите: pip install pyttsx3")
            self.available = False
        except Exception as e:
            logger.error(f"pyttsx3 ошибка инициализации: {e}")
            self.available = False

    def speak(self, text, volume=80, rate=160):
        if not self.available:
            return False
        try:
            self.engine.setProperty('volume', volume / 100.0)
            self.engine.setProperty('rate', rate)
            self.engine.say(text)
            self.engine.runAndWait()
            return True
        except Exception as e:
            logger.error(f"pyttsx3 speak error: {e}")
            return False
    def stop(self):
        if self.available:
            try:
                self.engine.stop()
            except:
                pass

class SAPIEngine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "sapi"
        self.available = platform.system() == "Windows"
        if self.available:
            logger.info("SAPI: доступен (Windows)")

    def speak(self, text, volume=80, rate=0):
        if not self.available:
            return False
        try:
            escaped = text.replace('"', '""').replace('$', '`$').replace('`', '``')
            cmd = f'''
Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$synth.Rate = {rate}
$synth.Volume = {volume}
$synth.Speak("{escaped}")
'''
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
                capture_output=True, text=True, timeout=15
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"SAPI error: {e}")
            return False

class EspeakEngine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "espeak"
        try:
            subprocess.run(["espeak", "--version"], capture_output=True)
            self.available = True
            logger.info("espeak: доступен")
        except FileNotFoundError:
            self.available = False
            logger.info("espeak: не найден")

    def speak(self, text, volume=80, rate=160):
        if not self.available:
            return False
        try:
            amplitude = int((volume / 100) * 200)
            speed = rate
            subprocess.run(
                ["espeak", "-a", str(amplitude), "-s", str(speed), "-v", "ru", text],
                capture_output=True, timeout=15
            )
            return True
        except Exception as e:
            logger.error(f"espeak error: {e}")
            return False

class SayEngine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "say"
        self.available = platform.system() == "Darwin"
        if self.available:
            logger.info("say: доступен (macOS)")

    def speak(self, text, volume=80, rate=200):
        if not self.available:
            return False
        try:
            vol = volume / 100.0
            subprocess.run(
                ["say", "-r", str(rate), "-v", str(vol), text],
                capture_output=True, timeout=15
            )
            return True
        except Exception as e:
            logger.error(f"say error: {e}")
            return False

class FestivalEngine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "festival"
        try:
            subprocess.run(["festival", "--version"], capture_output=True)
            self.available = True
            logger.info("festival: доступен")
        except FileNotFoundError:
            self.available = False

    def speak(self, text, volume=80, rate=160):
        if not self.available:
            return False
        try:
            subprocess.run(
                ["festival", "--tts"],
                input=text.encode(),
                capture_output=True, timeout=15
            )
            return True
        except Exception as e:
            logger.error(f"festival error: {e}")
            return False

def get_available_engines():
    engines = {}
    try:
        import pyttsx3
        engines['pyttsx3'] = Pyttsx3Engine()
    except ImportError:
        engines['pyttsx3'] = None
    engines['sapi'] = SAPIEngine()
    engines['espeak'] = EspeakEngine()
    engines['say'] = SayEngine()
    engines['festival'] = FestivalEngine()
    return engines

def get_tts_engine(engine_name='auto'):
    engines = get_available_engines()
    if engine_name == 'auto':
        priority = ['pyttsx3', 'sapi', 'espeak', 'say', 'festival']
        for name in priority:
            engine = engines.get(name)
            if engine and engine.available:
                logger.info(f"TTS: выбран движок '{name}'")
                return engine
    engine = engines.get(engine_name)
    if engine and engine.available:
        return engine
    logger.warning(f"TTS: движок '{engine_name}' недоступен, ищем альтернативу...")
    return get_tts_engine('auto')

def speak_text(text, engine_name='auto', volume=80, rate=160):
    engine = get_tts_engine(engine_name)
    if not engine:
        logger.warning("TTS: нет доступного движка")
        return False
    try:
        result = engine.speak(text, volume=volume, rate=rate)
        if result:
            logger.debug(f"TTS [{engine.name}]: озвучено ({len(text)} символов)")
        return result
    except Exception as e:
        logger.error(f"TTS ошибка: {e}")
        return False

# ==================== TTS WORKER ====================

def tts_worker():
    logger.info("TTS воркер запущен")
    while True:
        try:
            text = None
            with tts_lock:
                if tts_queue:
                    text = tts_queue.pop(0)
            if text:
                logger.info(f"TTS: озвучиваю [{len(tts_queue)} в очереди]")
                engine = tts_settings.get('engine', 'auto')
                volume = tts_settings.get('volume', 80)
                rate = tts_settings.get('rate', 160)
                def speak_thread():
                    speak_text(text, engine, volume, rate)
                threading.Thread(target=speak_thread, daemon=True).start()
            else:
                time.sleep(0.3)
        except Exception as e:
            logger.error(f"TTS worker error: {e}")
            time.sleep(0.5)

tts_thread = threading.Thread(target=tts_worker, daemon=True)
tts_thread.start()

def add_to_tts_queue(username, message):
    global tts_queue
    if not tts_settings.get('enabled', True):
        return
    users = tts_settings.get('users', [])
    if not users:
        return
    if username.lower() not in [u.lower() for u in users]:
        return
    ban_words = tts_settings.get('ban_words', [])
    if ban_words:
        message_lower = message.lower()
        for word in ban_words:
            if word in message_lower:
                logger.info(f"TTS: сообщение от {username} содержит запрещённое слово '{word}', не озвучивается")
                return
    text = f"{username} говорит: {message}"
    with tts_lock:
        tts_queue.append(text)
        if len(tts_queue) > 30:
            tts_queue = tts_queue[-20:]
        logger.info(f"TTS добавлено: {username} (очередь: {len(tts_queue)})")

# ==================== ЗРИТЕЛИ ====================

def get_viewers(channel):
    try:
        url = f"https://decapi.me/twitch/viewercount/{channel}"
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            text = resp.text.strip()
            if text.isdigit():
                return int(text)
            elif "offline" in text.lower():
                return "offline"          # канал не в эфире
            else:
                logger.warning(f"Неожиданный ответ от decapi.me: {text}")
                return None
        else:
            logger.warning(f"Ошибка получения зрителей: {resp.status_code}")
            return None
    except Exception as e:
        logger.error(f"Исключение при получении зрителей: {e}")
        return None

def viewers_loop(channel):
    global viewers_count, viewers_running
    logger.info(f"Запущен поток обновления зрителей для канала {channel}")
    while viewers_running:
        count = get_viewers(channel)
        if count is not None:
            viewers_count = count
            socketio.emit('viewers_update', {'count': viewers_count, 'channel': channel})
            logger.debug(f"Зрителей: {viewers_count}")
        else:
            viewers_count = 0
        time.sleep(VIEWERS_UPDATE_INTERVAL)
    logger.info("Поток обновления зрителей остановлен")

def start_viewers_updater(channel):
    global viewers_running, viewers_thread
    if viewers_running:
        stop_viewers_updater()
    viewers_running = True
    viewers_thread = threading.Thread(target=viewers_loop, args=(channel,), daemon=True)
    viewers_thread.start()

def stop_viewers_updater():
    global viewers_running, viewers_thread
    viewers_running = False
    if viewers_thread and viewers_thread.is_alive():
        viewers_thread.join(timeout=2)
    viewers_thread = None

# ==================== ROUTES ====================

@app.route('/')
def index():
    return render_template('app.html')

@app.route('/app')
def app_page():
    return render_template('app.html')

@app.route('/overlay')
def overlay():
    return render_template('overlay.html')

@app.route('/api/start', methods=['POST'])
def start_parser():
    global start_time
    data = request.get_json() or {}
    nickname = data.get('nickname', current_config.get('nickname', '')).strip()
    if not nickname:
        return jsonify({'status': 'error', 'message': 'Nickname is required'}), 400

    ttl = int(data.get('ttl', current_config.get('ttl', 0)))
    css = data.get('css', current_config.get('css', ''))
    log_messages = data.get('log_messages', current_config.get('log_messages', False))
    max_messages = int(data.get('max_messages', current_config.get('max_messages', 100)))
    show_viewers = data.get('show_viewers_in_overlay', current_config.get('show_viewers_in_overlay', False))

    current_config.update({
        'nickname': nickname,
        'ttl': ttl,
        'css': css,
        'log_messages': log_messages,
        'max_messages': max_messages,
        'show_viewers_in_overlay': show_viewers
    })
    save_config(current_config)

    with message_lock:
        message_history.clear()

    start_time = datetime.now()
    parser.start(nickname)
    start_viewers_updater(nickname)

    # Отправляем обновлённую конфигурацию с новыми полями
    socketio.emit('config_update', {
        'ttl': ttl,
        'css': css,
        'nickname': nickname,
        'log_messages': log_messages,
        'max_messages': max_messages,
        'show_viewers_in_overlay': show_viewers,
        'show_avatars': current_config.get('show_avatars', True),
        'username_color_mode': current_config.get('username_color_mode', 'twitch'),
        'username_fixed_color': current_config.get('username_fixed_color', '#7c5cfc'),
        'avatar_size': current_config.get('avatar_size', 28),
        'message_bg_color': current_config.get('message_bg_color', '#111118')
    })
    socketio.emit('parser_status', {
        'running': True,
        'nickname': nickname,
        'start_time': start_time.isoformat() if start_time else None
    })
    logger.info(f"Парсер запущен: канал={nickname}")
    return jsonify({'status': 'ok', 'nickname': nickname})

@app.route('/api/stop', methods=['POST'])
def stop_parser():
    global start_time
    parser.stop()
    start_time = None
    stop_viewers_updater()
    socketio.emit('parser_status', {'running': False, 'nickname': '', 'start_time': None})
    return jsonify({'status': 'ok'})

@app.route('/api/status')
def get_status():
    return jsonify({
        'running': parser.running,
        'nickname': current_config.get('nickname', ''),
        'ttl': current_config.get('ttl', 0),
        'log_messages': current_config.get('log_messages', False),
        'css': current_config.get('css', ''),
        'max_messages': current_config.get('max_messages', 100),
        'start_time': start_time.isoformat() if start_time else None,
        'message_count': len(message_history),
        'viewers': viewers_count,
        'show_viewers_in_overlay': current_config.get('show_viewers_in_overlay', False),
        'show_avatars': current_config.get('show_avatars', True),
        'username_color_mode': current_config.get('username_color_mode', 'twitch'),
        'username_fixed_color': current_config.get('username_fixed_color', '#7c5cfc'),
        'avatar_size': current_config.get('avatar_size', 28),
        'message_bg_color': current_config.get('message_bg_color', '#111118')
    })

@app.route('/api/messages')
def get_messages():
    with message_lock:
        return jsonify({
            'messages': message_history.copy(),
            'count': len(message_history),
            'start_time': start_time.isoformat() if start_time else None
        })

@app.route('/api/config', methods=['GET'])
def get_config():
    return jsonify(current_config)

@app.route('/api/config', methods=['PUT'])
def update_config():
    data = request.get_json() or {}
    allowed_keys = [
        'ttl', 'css', 'log_messages', 'nickname', 'max_messages', 'show_viewers_in_overlay',
        'show_avatars', 'username_color_mode', 'username_fixed_color', 'avatar_size', 'message_bg_color'
    ]
    for key in allowed_keys:
        if key in data:
            current_config[key] = data[key]
    save_config(current_config)

    max_msgs = current_config.get('max_messages', 100)
    with message_lock:
        while len(message_history) > max_msgs:
            message_history.pop(0)

    socketio.emit('config_update', {
        'ttl': current_config.get('ttl', 0),
        'css': current_config.get('css', ''),
        'nickname': current_config.get('nickname', ''),
        'log_messages': current_config.get('log_messages', False),
        'max_messages': current_config.get('max_messages', 100),
        'show_viewers_in_overlay': current_config.get('show_viewers_in_overlay', False),
        'show_avatars': current_config.get('show_avatars', True),
        'username_color_mode': current_config.get('username_color_mode', 'twitch'),
        'username_fixed_color': current_config.get('username_fixed_color', '#7c5cfc'),
        'avatar_size': current_config.get('avatar_size', 28),
        'message_bg_color': current_config.get('message_bg_color', '#111118')
    })
    return jsonify({'status': 'ok'})

@app.route('/api/tts/config', methods=['GET'])
def get_tts_config():
    engines = get_available_engines()
    available = [name for name, eng in engines.items() if eng and eng.available]
    current_engine = tts_settings.get('engine', 'auto')
    return jsonify({
        'enabled': tts_settings.get('enabled', True),
        'users': tts_settings.get('users', []),
        'volume': tts_settings.get('volume', 80),
        'rate': tts_settings.get('rate', 160),
        'engine': current_engine,
        'available_engines': available,
        'engine_status': {name: eng.available if eng else False for name, eng in engines.items()}
    })


# ==================== API АНИМАЦИЙ ====================
@app.route('/api/animation/config', methods=['GET'])
def get_animation_config():
    """Получить настройки анимаций"""
    config = load_config()
    return jsonify(config.get('animation', DEFAULT_CONFIG['animation']))


@app.route('/api/animation/config', methods=['PUT'])
def update_animation_config():
    """Обновить настройки анимаций"""
    data = request.get_json() or {}
    config = load_config()

    valid_entry_effects = ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip']
    valid_exit_effects = ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip']

    animation = config.get('animation', DEFAULT_CONFIG['animation'].copy())

    if 'entry' in data and data['entry'] in valid_entry_effects:
        animation['entry'] = data['entry']
    if 'exit' in data and data['exit'] in valid_exit_effects:
        animation['exit'] = data['exit']
    if 'speed' in data:
        animation['speed'] = max(50, min(2000, int(data['speed'])))
    if 'delay' in data:
        animation['delay'] = max(0, min(1000, int(data['delay'])))

    config['animation'] = animation
    save_config(config)

    socketio.emit('config_update', {
        'ttl': config.get('ttl', 0),
        'css': config.get('css', ''),
        'nickname': config.get('nickname', ''),
        'log_messages': config.get('log_messages', False),
        'max_messages': config.get('max_messages', 100),
        'show_viewers_in_overlay': config.get('show_viewers_in_overlay', False),
        'show_avatars': config.get('show_avatars', True),
        'username_color_mode': config.get('username_color_mode', 'twitch'),
        'username_fixed_color': config.get('username_fixed_color', '#7c5cfc'),
        'avatar_size': config.get('avatar_size', 28),
        'message_bg_color': config.get('message_bg_color', '#111118'),
        'animation': animation
    })

    return jsonify({'status': 'ok', 'animation': animation})


@app.route('/api/open_url', methods=['POST'])
def open_url():
    """Открыть URL в браузере по умолчанию"""
    data = request.get_json() or {}
    url = data.get('url', '')

    if not url:
        return jsonify({'status': 'error', 'message': 'URL is required'}), 400

    try:
        # Открываем URL в браузере по умолчанию
        if platform.system() == 'Windows':
            subprocess.run(['start', url], shell=True)
        elif platform.system() == 'Darwin':  # macOS
            subprocess.run(['open', url])
        else:  # Linux и другие
            subprocess.run(['xdg-open', url])

        logger.info(f"Открыт URL: {url}")
        return jsonify({'status': 'ok', 'message': f'Открыт {url}'})
    except Exception as e:
        logger.error(f"Ошибка открытия URL: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/animation/effects', methods=['GET'])
def get_animation_effects():
    """Получить список доступных эффектов"""
    return jsonify({
        'entry': ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip'],
        'exit': ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip']
    })

@app.route('/api/tts/config', methods=['PUT'])
def update_tts_config():
    global tts_settings
    data = request.get_json() or {}
    if 'users' in data:
        tts_settings['users'] = [u.strip() for u in data['users'].split(',') if u.strip()]
    if 'enabled' in data:
        tts_settings['enabled'] = bool(data['enabled'])
    if 'volume' in data:
        tts_settings['volume'] = max(0, min(100, int(data['volume'])))
    if 'rate' in data:
        tts_settings['rate'] = max(50, min(300, int(data['rate'])))
    if 'engine' in data:
        tts_settings['engine'] = data['engine']
    if 'ban_words' in data:
        tts_settings['ban_words'] = [w.strip().lower() for w in data['ban_words'].split(',') if w.strip()]
    socketio.emit('tts_update', tts_settings)
    return jsonify({'status': 'ok', 'settings': tts_settings})

@app.route('/api/tts/test', methods=['POST'])
def test_tts():
    data = request.get_json() or {}
    text = data.get('text', 'Привет! Это тестовое сообщение для проверки синтеза речи.')
    engine_name = data.get('engine', tts_settings.get('engine', 'auto'))
    volume = data.get('volume', tts_settings.get('volume', 80))
    rate = data.get('rate', tts_settings.get('rate', 160))
    def speak():
        speak_text(text, engine_name, volume, rate)
    threading.Thread(target=speak, daemon=True).start()
    return jsonify({
        'status': 'ok',
        'message': f'Озвучиваю через {engine_name}',
        'text': text,
        'engine': engine_name,
        'volume': volume,
        'rate': rate
    })

@app.route('/api/tts/engines', methods=['GET'])
def list_engines():
    engines = get_available_engines()
    result = {}
    for name, eng in engines.items():
        result[name] = {'available': eng.available if eng else False, 'name': eng.name if eng else name}
    return jsonify(result)

@app.route('/api/tts/stop', methods=['POST'])
def stop_tts():
    with tts_lock:
        tts_queue.clear()
    engine = get_tts_engine(tts_settings.get('engine', 'auto'))
    if engine:
        engine.stop()
    return jsonify({'status': 'ok', 'message': 'TTS остановлен, очередь очищена'})

@app.route('/api/clear', methods=['POST'])
def clear_messages():
    with message_lock:
        message_history.clear()
    socketio.emit('messages_clear')
    return jsonify({'status': 'ok'})

@app.route('/api/toggle', methods=['POST'])
def toggle_parser():
    global start_time
    if parser.running:
        parser.stop()
        start_time = None
        stop_viewers_updater()
        socketio.emit('parser_status', {'running': False, 'nickname': '', 'start_time': None})
        return jsonify({'status': 'ok', 'running': False})
    else:
        nickname = current_config.get('nickname', '').strip()
        if not nickname:
            return jsonify({'status': 'error', 'message': 'No nickname configured'}), 400
        with message_lock:
            message_history.clear()
        start_time = datetime.now()
        parser.start(nickname)
        start_viewers_updater(nickname)
        socketio.emit('parser_status', {'running': True, 'nickname': nickname, 'start_time': start_time.isoformat()})
        return jsonify({'status': 'ok', 'running': True, 'nickname': nickname})
@app.route('/api/emote/<emote_id>')
def proxy_emote(emote_id):
    import requests
    # Для BTTV
    url = f'https://cdn.betterttv.net/emote/{emote_id}/3x.webp'
    try:
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            # Возвращаем с правильным типом
            return resp.content, 200, {'Content-Type': resp.headers.get('Content-Type', 'image/webp')}
        else:
            return '', 404
    except Exception:
        return '', 500
@app.route('/api/avatar/<username>')
def get_avatar(username):
    import requests
    try:
        resp = requests.get(f'https://decapi.me/twitch/avatar/{username}', timeout=5)
        if resp.status_code == 200:
            # decapi.me возвращает чистый URL, но иногда может вернуть "offline" или html
            url = resp.text.strip()
            if url.startswith('http'):
                return jsonify({'url': url})
            else:
                return jsonify({'url': None, 'error': 'Not found'})
        else:
            return jsonify({'url': None, 'error': 'API error'}), 404
    except Exception as e:
        return jsonify({'url': None, 'error': str(e)}), 500

@app.context_processor
def inject_version():
    """Добавляет текущую версию приложения во все шаблоны."""
    return dict(version=VERSION)

# web.py (добавить после импортов)
@app.route('/api/emotes')
def get_emotes():
    import requests
    emotes = {}
    # Twitch глобальные эмоции
    try:
        resp = requests.get('https://twitchemotes.com/api_cache/v3/global.json', timeout=5)
        if resp.ok:
            data = resp.json()
            for code, info in data.items():
                emote_id = info.get('id')
                if emote_id:
                    url = f'https://static-cdn.jtvnw.net/emoticons/v2/{emote_id}/default/dark/3.0'
                    emotes[code] = url
    except Exception as e:
        logger.error(f"Ошибка загрузки Twitch-эмоций: {e}")
    # BTTV глобальные эмоции
    try:
        resp = requests.get('https://api.betterttv.net/3/cached/emotes/global', timeout=5)
        if resp.ok:
            data = resp.json()
            for emote in data:
                # Вместо прямого URL сохраняем ссылку на наш прокси
                url = f'/api/emote/{emote["id"]}'
                emotes[emote["code"]] = url
    except Exception as e:
        logger.error(f"Ошибка загрузки BTTV-эмоций: {e}")
    return jsonify(emotes)
def add_message_to_history(username, message, color, badges=None):
    global message_history
    with message_lock:
        msg_data = {
            'username': username,
            'message': message,
            'color': color,
            'timestamp': datetime.now().isoformat(),
            'badges': badges or []
        }
        message_history.append(msg_data)
        max_msgs = current_config.get('max_messages', 100)
        while len(message_history) > max_msgs:
            message_history.pop(0)
    add_to_tts_queue(username, message)

@socketio.on('connect')
def handle_connect():
    emit('config_update', {
        'ttl': current_config.get('ttl', 0),
        'css': current_config.get('css', ''),
        'nickname': current_config.get('nickname', ''),
        'log_messages': current_config.get('log_messages', False),
        'max_messages': current_config.get('max_messages', 100),
        'show_viewers_in_overlay': current_config.get('show_viewers_in_overlay', False),
        'show_avatars': current_config.get('show_avatars', True),
        'username_color_mode': current_config.get('username_color_mode', 'twitch'),
        'username_fixed_color': current_config.get('username_fixed_color', '#7c5cfc'),
        'avatar_size': current_config.get('avatar_size', 28),
        'message_bg_color': current_config.get('message_bg_color', '#111118')
    })
    emit('parser_status', {
        'running': parser.running,
        'nickname': current_config.get('nickname', ''),
        'start_time': start_time.isoformat() if start_time else None
    })
    emit('tts_update', tts_settings)
    emit('viewers_update', {
        'count': viewers_count,
        'channel': current_config.get('nickname', '')
    })
    with message_lock:
        if message_history:
            emit('message_history', {
                'messages': message_history.copy(),
                'start_time': start_time.isoformat() if start_time else None
            })

if __name__ == '__main__':
    socketio.run(app, host='127.0.0.1', port=5000, debug=False, use_reloader=False)