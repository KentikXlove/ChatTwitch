class Config:
    def __init__(self):
        self.nickname = ""
        self.message_ttl = 0       # 0 – не удалять сообщения
        self.custom_css = ""

config = Config()