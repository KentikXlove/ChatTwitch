import sys
import os
import logging
import threading
from pathlib import Path

# Настройка логирования
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app_debug.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def run_main_app():
    """Запускает основную программу (Flask + оверлей)"""
    try:
        from web import app, socketio
        from window import run_overlay_window

        logger.info("Запуск основной программы...")

        # Запускаем Flask‑сервер в отдельном потоке
        def start_flask():
            socketio.run(app, host='0.0.0.0', port=5000,
                        debug=False, use_reloader=False,
                        allow_unsafe_werkzeug=True)

        flask_thread = threading.Thread(target=start_flask, daemon=True)
        flask_thread.start()
        logger.info("Flask‑сервер запущен в фоновом потоке")

        # Запускаем окно оверлея
        run_overlay_window()
        logger.info("Окно оверлея закрыто, завершаем программу")

    except Exception as e:
        logger.error(f"Ошибка при запуске основной программы: {e}", exc_info=True)
        input("Нажмите Enter для выхода...")


if __name__ == '__main__':
    run_main_app()