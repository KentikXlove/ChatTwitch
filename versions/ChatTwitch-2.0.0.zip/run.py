import sys
import os
import json
import zipfile
import requests
import time
import logging
import re
import threading
import subprocess
import traceback
from pathlib import Path
from datetime import datetime
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

# Добавляем импорты из вашей программы
from web import app, socketio
from window import run_overlay_window
from logger import AppLogger, get_logger
TESTMODE = True
# Настройка логирования
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('launcher_debug.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class DownloadWorker(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, file_id, dest):
        super().__init__()
        self.file_id = file_id
        self.dest = dest
        self.session = requests.Session()

    def run(self):
        try:
            logger.info(f"Начинаем загрузку с Google Drive ID: {self.file_id}")
            self.download_from_google_drive()

            # Проверяем скачанный файл
            if not self.verify_download():
                return

            self.finished.emit()

        except Exception as e:
            logger.error(f"Ошибка загрузки: {str(e)}", exc_info=True)
            self.error.emit(str(e))

    def download_from_google_drive(self):
        """Скачивание больших файлов с Google Drive с обработкой предупреждения"""
        try:
            url = "https://drive.google.com/uc"
            params = {'id': self.file_id, 'export': 'download'}

            response = self.session.get(url, params=params)
            logger.info(f"Получен ответ от Google Drive: {response.status_code}")

            # Проверяем, есть ли форма для подтверждения
            if 'uc-download-link' in response.text or 'confirm' in response.text:
                logger.info("Обнаружено предупреждение о вирусах, подтверждаем...")

                # Извлекаем все параметры из формы
                form_data = {}

                # Ищем все hidden поля
                hidden_fields = re.findall(r'<input type="hidden" name="([^"]+)" value="([^"]+)"', response.text)
                for name, value in hidden_fields:
                    form_data[name] = value

                # Ищем action формы
                action_match = re.search(r'<form[^>]+action="([^"]+)"', response.text)
                if action_match:
                    action_url = action_match.group(1)
                else:
                    action_url = "https://drive.usercontent.google.com/download"

                # Добавляем параметры из URL
                for key, value in params.items():
                    if key not in form_data:
                        form_data[key] = value

                logger.info(f"Параметры формы: {form_data}")

                # Отправляем запрос на скачивание
                download_response = self.session.get(action_url, params=form_data, stream=True)

                # Проверяем, не перенаправили ли нас
                if download_response.history:
                    logger.info("Следование по перенаправлению...")
                    final_response = download_response.history[-1]
                    if final_response.status_code == 302:
                        redirect_url = final_response.headers.get('Location')
                        if redirect_url:
                            download_response = self.session.get(redirect_url, stream=True)

                # Сохраняем файл
                if download_response.status_code == 200:
                    total_size = int(download_response.headers.get('content-length', 0))
                    logger.info(f"Размер файла: {total_size / (1024 * 1024):.2f} MB")

                    with open(self.dest, 'wb') as f:
                        downloaded = 0
                        for chunk in download_response.iter_content(chunk_size=32768):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                if total_size > 0:
                                    percent = (downloaded / total_size) * 100
                                    self.progress.emit(int(percent))

                    logger.info(f"Файл сохранен: {self.dest}")
                    logger.info(f"Размер: {os.path.getsize(self.dest) / (1024 * 1024):.2f} MB")
                else:
                    raise Exception(f"Ошибка скачивания: {download_response.status_code}")
            else:
                # Если нет формы подтверждения, пробуем скачать напрямую
                logger.info("Прямое скачивание...")
                download_url = f"https://drive.google.com/uc?export=download&id={self.file_id}"
                download_response = self.session.get(download_url, stream=True)

                if download_response.status_code == 200:
                    total_size = int(download_response.headers.get('content-length', 0))
                    logger.info(f"Размер файла: {total_size / (1024 * 1024):.2f} MB")

                    with open(self.dest, 'wb') as f:
                        downloaded = 0
                        for chunk in download_response.iter_content(chunk_size=32768):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                if total_size > 0:
                                    percent = (downloaded / total_size) * 100
                                    self.progress.emit(int(percent))

                    logger.info(f"Файл сохранен: {self.dest}")
                else:
                    raise Exception(f"Ошибка скачивания: {download_response.status_code}")

        except Exception as e:
            logger.error(f"Ошибка в download_from_google_drive: {str(e)}")
            raise

    def verify_download(self):
        """Проверка скачанного файла"""
        try:
            logger.info(f"Проверка файла: {self.dest}")

            if not os.path.exists(self.dest):
                self.error.emit("Файл не был создан")
                return False

            file_size = os.path.getsize(self.dest)
            logger.info(f"Размер скачанного файла: {file_size} байт")

            if file_size == 0:
                self.error.emit("Скачанный файл пуст")
                return False

            # Проверяем, не HTML ли это
            with open(self.dest, 'rb') as f:
                header = f.read(200)
                if b'<!DOCTYPE' in header or b'<html' in header:
                    logger.error("Файл содержит HTML, а не zip архив")
                    self.safe_remove(self.dest)
                    self.error.emit("Google Drive вернул HTML страницу.\nВозможно, файл слишком большой.")
                    return False

            # Проверяем, что это zip
            if not zipfile.is_zipfile(self.dest):
                logger.error("Файл не является zip архивом")
                self.safe_remove(self.dest)
                self.error.emit("Файл не является zip архивом")
                return False

            logger.info("Файл успешно скачан и является zip архивом")
            return True

        except Exception as e:
            logger.error(f"Ошибка проверки файла: {str(e)}")
            self.error.emit(str(e))
            return False

    def safe_remove(self, filepath):
        """Безопасное удаление файла с повторными попытками"""
        for i in range(5):
            try:
                if os.path.exists(filepath):
                    os.remove(filepath)
                    logger.info(f"Файл удален: {filepath}")
                return True
            except Exception as e:
                logger.warning(f"Попытка {i + 1} удалить файл не удалась: {str(e)}")
                time.sleep(0.5)
        return False


class MainAppProcess(QProcess):
    """Класс для управления процессом основной программы"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent

    def start_app(self):
        """Запуск основной программы"""
        try:
            logger.info("Запуск основной программы...")

            # Путь к основной программе
            app_path = os.path.join(self.parent_window.install_path, "ChatTwitch.exe")

            if not os.path.exists(app_path):
                logger.error(f"Файл программы не найден: {app_path}")
                QMessageBox.warning(self.parent_window, "Ошибка",
                                    "Файл программы не найден. Установите программу.")
                return False

            # Запускаем процесс
            self.setProgram(app_path)
            self.start()

            # Скрываем лаунчер
            self.parent_window.hide()

            # Подключаем сигнал завершения процесса
            self.finished.connect(self.on_app_closed)

            logger.info("Основная программа запущена")
            return True

        except Exception as e:
            logger.error(f"Ошибка запуска программы: {str(e)}")
            QMessageBox.critical(self.parent_window, "Ошибка",
                                 f"Не удалось запустить программу:\n{str(e)}")
            return False

    def on_app_closed(self, exit_code, exit_status):
        """Обработка закрытия основной программы"""
        logger.info(f"Основная программа завершена (код: {exit_code})")

        # Сбрасываем состояние кнопки
        if self.parent_window:
            # Восстанавливаем UI
            self.parent_window.start_btn.setEnabled(True)
            self.parent_window.start_btn.setText("▶ Запустить")
            self.parent_window.statusBar().showMessage("Программа завершена")
            self.parent_window.status_label.setText("● Ожидание")
            self.parent_window.status_label.setStyleSheet("""
                font-size: 13px;
                color: #ff8c00;
                background-color: #fff4e6;
                padding: 6px 14px;
                border-radius: 12px;
            """)

            # Показываем лаунчер
            self.parent_window.show()
            self.parent_window.raise_()
            self.parent_window.activateWindow()


class ModernLauncher(QMainWindow):
    def __init__(self):
        super().__init__()
        self.versions_data = None
        self.latest_version = None
        self.install_path = "C:/ChatTwitch"
        self.current_version = None
        self.download_worker = None
        self.main_process = MainAppProcess(self)
        self.initUI()
        self.check_installation()
        self.load_versions()

    def initUI(self):
        self.setWindowTitle("ChatTwitch Launcher")
        self.setFixedSize(800, 650)  # Увеличил высоту для новой кнопки
        self.setWindowIcon(QIcon("icon.ico"))  # или полный путь

        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QLabel {
                color: #333333;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            QPushButton {
                background-color: #0078d4;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                font-size: 13px;
                font-weight: 500;
                font-family: 'Segoe UI', Arial, sans-serif;
                min-height: 36px;
            }
            QPushButton:hover {
                background-color: #106ebe;
            }
            QPushButton:pressed {
                background-color: #005a9e;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QPushButton#install_btn {
                background-color: #107c10;
                font-weight: 600;
            }
            QPushButton#install_btn:hover {
                background-color: #0a6b0a;
            }
            QPushButton#install_btn:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QPushButton#uninstall_btn {
                background-color: #d13438;
                font-weight: 600;
            }
            QPushButton#uninstall_btn:hover {
                background-color: #b8282c;
            }
            QPushButton#uninstall_btn:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QPushButton#start_btn {
                background-color: #4CAF50;
                font-weight: 600;
                font-size: 14px;
            }
            QPushButton#start_btn:hover {
                background-color: #45a049;
            }
            QPushButton#start_btn:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QGroupBox {
                font-family: 'Segoe UI', Arial, sans-serif;
                font-weight: 600;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                margin-top: 12px;
                padding-top: 12px;
                background-color: white;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 16px;
                padding: 0 8px 0 8px;
                color: #333333;
                background-color: white;
            }
            QListWidget {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                padding: 4px;
                background-color: white;
                font-family: 'Segoe UI', Arial, sans-serif;
                outline: none;
            }
            QListWidget::item {
                padding: 8px 12px;
                border-radius: 3px;
            }
            QListWidget::item:selected {
                background-color: #e6f2ff;
                color: #0078d4;
            }
            QListWidget::item:hover {
                background-color: #f0f6ff;
            }
            QProgressBar {
                background-color: #e0e0e0;
                border: none;
                border-radius: 3px;
                height: 8px;
                text-align: center;
                color: #333333;
                font-size: 11px;
            }
            QProgressBar::chunk {
                background-color: #0078d4;
                border-radius: 3px;
            }
            QLineEdit {
                border: 1px solid #d0d0d0;
                border-radius: 4px;
                padding: 8px 12px;
                font-family: 'Segoe UI', Arial, sans-serif;
                background-color: white;
                selection-background-color: #0078d4;
            }
            QLineEdit:focus {
                border: 1px solid #0078d4;
            }
            QCheckBox {
                font-family: 'Segoe UI', Arial, sans-serif;
                color: #333333;
                spacing: 8px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border-radius: 3px;
                border: 1px solid #d0d0d0;
                background-color: white;
            }
            QCheckBox::indicator:checked {
                background-color: #0078d4;
                border: 1px solid #0078d4;
            }
            QStatusBar {
                background-color: #f5f5f5;
                color: #666666;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(16)
        main_layout.setContentsMargins(32, 24, 32, 24)

        # Верхняя панель
        header_layout = QHBoxLayout()
        header_layout.setSpacing(12)

        title_label = QLabel("ChatTwitch")
        title_label.setStyleSheet("""
            font-size: 26px;
            font-weight: 300;
            color: #0078d4;
            letter-spacing: 0.5px;
        """)
        header_layout.addWidget(title_label)

        header_layout.addStretch()

        self.version_label = QLabel("Не установлено")
        self.version_label.setStyleSheet("""
            font-size: 13px;
            color: #666666;
            background-color: #f0f0f0;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        header_layout.addWidget(self.version_label)

        self.status_label = QLabel("● Ожидание")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #ff8c00;
            background-color: #fff4e6;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        header_layout.addWidget(self.status_label)

        main_layout.addLayout(header_layout)

        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setStyleSheet("background-color: #e0e0e0; max-height: 1px;")
        main_layout.addWidget(separator)

        # Основная сетка
        content_layout = QGridLayout()
        content_layout.setSpacing(16)

        # Новости
        news_group = QGroupBox("Новости и обновления")
        news_group.setMinimumHeight(150)
        news_layout = QVBoxLayout(news_group)

        self.news_label = QLabel("Загрузка информации...")
        self.news_label.setWordWrap(True)
        self.news_label.setStyleSheet("""
            padding: 12px;
            background-color: #fafafa;
            border-radius: 4px;
            font-size: 13px;
            line-height: 1.5;
            color: #444444;
        """)
        news_layout.addWidget(self.news_label)
        content_layout.addWidget(news_group, 0, 0, 1, 1)

        # Версии
        versions_group = QGroupBox("Доступные версии")
        versions_layout = QVBoxLayout(versions_group)

        self.versions_list = QListWidget()
        self.versions_list.setMaximumHeight(110)
        versions_layout.addWidget(self.versions_list)
        content_layout.addWidget(versions_group, 0, 1, 1, 1)

        # Настройки установки
        settings_group = QGroupBox("Настройки установки")
        settings_layout = QGridLayout(settings_group)
        settings_layout.setSpacing(10)
        settings_layout.setColumnStretch(1, 1)

        settings_layout.addWidget(QLabel("Путь установки:"), 0, 0)
        self.path_edit = QLineEdit(self.install_path)
        settings_layout.addWidget(self.path_edit, 0, 1)
        browse_btn = QPushButton("Обзор...")
        browse_btn.setFixedWidth(90)
        browse_btn.clicked.connect(self.browse_path)
        settings_layout.addWidget(browse_btn, 0, 2)

        self.desktop_check = QCheckBox("Создать ярлык на рабочем столе")
        self.desktop_check.setChecked(True)
        settings_layout.addWidget(self.desktop_check, 1, 0, 1, 2)

        self.startmenu_check = QCheckBox("Добавить в меню 'Пуск'")
        self.startmenu_check.setChecked(True)
        settings_layout.addWidget(self.startmenu_check, 2, 0, 1, 2)

        content_layout.addWidget(settings_group, 1, 0, 1, 2)

        main_layout.addLayout(content_layout)

        # Прогресс-бар
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)

        # Кнопки
        buttons_layout = QHBoxLayout()
        buttons_layout.setSpacing(12)

        self.install_btn = QPushButton("Установить / Обновить")
        self.install_btn.setObjectName("install_btn")
        self.install_btn.setMinimumWidth(180)
        self.install_btn.clicked.connect(self.install_or_update)
        buttons_layout.addWidget(self.install_btn)

        self.start_btn = QPushButton("▶ Запустить")
        self.start_btn.setObjectName("start_btn")
        self.start_btn.setMinimumWidth(140)
        self.start_btn.clicked.connect(self.start_main_app)
        buttons_layout.addWidget(self.start_btn)

        self.uninstall_btn = QPushButton("Удалить")
        self.uninstall_btn.setObjectName("uninstall_btn")
        self.uninstall_btn.setMinimumWidth(120)
        self.uninstall_btn.clicked.connect(self.uninstall_app)
        buttons_layout.addWidget(self.uninstall_btn)

        buttons_layout.addStretch()

        main_layout.addLayout(buttons_layout)

        self.statusBar().showMessage("Готов к работе")

        # Проверяем, установлена ли программа для активации кнопки "Запустить"
        self.update_start_button()

        logger.info("Лаунчер запущен")
        logger.info(f"Путь установки: {self.install_path}")

    def update_start_button(self):
        """Обновляет состояние кнопки 'Запустить'"""
        is_installed = os.path.exists(self.install_path) and \
                       os.path.exists(os.path.join(self.install_path, "ChatTwitch.exe"))
        self.start_btn.setEnabled(is_installed)
        if not is_installed:
            self.start_btn.setToolTip("Программа не установлена")
        else:
            self.start_btn.setToolTip("Запустить программу")

    def load_versions(self):
        try:
            logger.info("Загрузка информации о версиях...")
            response = requests.get("https://raw.githubusercontent.com/KentikXlove/ChatTwitch/main/versions.json")
            self.versions_data = response.json()
            self.latest_version = self.versions_data['latest']

            self.versions_list.clear()
            for ver in self.versions_data['versions']:
                item = QListWidgetItem(f"Версия {ver['version']}")
                if ver['version'] == self.latest_version['version']:
                    item.setText(f"⭐ {item.text()} (последняя)")
                    item.setForeground(QColor(0, 120, 212))
                self.versions_list.addItem(item)

            if self.versions_list.count() > 0:
                self.versions_list.setCurrentRow(0)

            if 'notes' in self.latest_version:
                self.news_label.setText(
                    f"<b>Версия {self.latest_version['version']}</b><br>{self.latest_version['notes']}")

            logger.info(f"Загружено {len(self.versions_data['versions'])} версий")
            logger.info(f"Последняя версия: {self.latest_version['version']}")

        except Exception as e:
            error_msg = f"Не удалось загрузить информацию о версиях: {str(e)}"
            self.news_label.setText(error_msg)
            logger.error(f"ОШИБКА: {error_msg}")
            self.statusBar().showMessage(error_msg)

    def check_installation(self):
        is_installed = os.path.exists(self.install_path) and \
                       os.path.exists(os.path.join(self.install_path, "ChatTwitch.exe"))

        if is_installed:
            self.current_version = self.get_installed_version()
            self.status_label.setText("● Установлено")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #107c10;
                background-color: #e6f2e6;
                padding: 6px 14px;
                border-radius: 12px;
            """)
            self.version_label.setText(f"Версия {self.current_version}")
            self.install_btn.setText("Обновить")
            self.uninstall_btn.setEnabled(True)
            logger.info(f"Программа установлена, версия {self.current_version}")
            self.statusBar().showMessage("Программа установлена")
        else:
            self.status_label.setText("● Не установлено")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #d13438;
                background-color: #fde7e9;
                padding: 6px 14px;
                border-radius: 12px;
            """)
            self.install_btn.setText("Установить")
            self.uninstall_btn.setEnabled(False)
            logger.info("Программа не установлена")
            self.statusBar().showMessage("Программа не установлена")

        self.update_start_button()

    def get_installed_version(self):
        version_file = os.path.join(self.install_path, "version.txt")
        if os.path.exists(version_file):
            with open(version_file, 'r') as f:
                return f.read().strip()
        return "Неизвестно"

    def browse_path(self):
        path = QFileDialog.getExistingDirectory(self, "Выберите папку для установки",
                                                os.path.dirname(self.install_path))
        if path:
            self.install_path = path
            self.path_edit.setText(path)
            logger.info(f"Путь установки изменен на: {path}")

    def install_or_update(self):
        if not self.versions_data:
            QMessageBox.warning(self, "Ошибка", "Не удалось загрузить информацию о версиях")
            return

        selected = self.versions_list.currentRow()
        if selected < 0:
            selected = 0

        version_info = self.versions_data['versions'][selected]
        logger.info(f"Выбрана версия {version_info['version']}")
        logger.info(f"ID файла Google Drive: {version_info['id']}")
        self.download_and_install(version_info)

    def download_and_install(self, version_info):
        os.makedirs(self.install_path, exist_ok=True)
        zip_path = os.path.join(self.install_path, "temp.zip")

        # Закрываем все возможные файловые дескрипторы
        self.safe_remove(zip_path)

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.status_label.setText("● Скачивание...")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #0078d4;
            background-color: #e6f2ff;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        self.install_btn.setEnabled(False)
        self.uninstall_btn.setEnabled(False)
        self.start_btn.setEnabled(False)

        logger.info("Начинаем скачивание...")

        # Используем ID файла из Google Drive
        self.download_worker = DownloadWorker(version_info['id'], zip_path)
        self.download_worker.progress.connect(self.update_progress)
        self.download_worker.finished.connect(lambda: self.extract_zip(zip_path, version_info))
        self.download_worker.error.connect(self.download_error)
        self.download_worker.start()

    def safe_remove(self, filepath):
        """Безопасное удаление файла"""
        for i in range(5):
            try:
                if os.path.exists(filepath):
                    os.remove(filepath)
                    logger.info(f"Файл удален: {filepath}")
                return True
            except Exception as e:
                logger.warning(f"Попытка {i + 1} удалить файл не удалась: {str(e)}")
                time.sleep(0.5)
        return False

    def update_progress(self, value):
        self.progress_bar.setValue(value)
        self.statusBar().showMessage(f"Загрузка: {value}%")

    def extract_zip(self, zip_path, version_info):
        logger.info(f"Начинаем распаковку: {zip_path}")
        self.status_label.setText("● Распаковка...")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #0078d4;
            background-color: #e6f2ff;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        self.statusBar().showMessage("Распаковка архива...")

        try:
            # Проверяем существование файла
            if not os.path.exists(zip_path):
                raise Exception(f"Файл не найден: {zip_path}")

            file_size = os.path.getsize(zip_path)
            logger.info(f"Размер файла: {file_size} байт")

            # Проверяем, что это zip
            if not zipfile.is_zipfile(zip_path):
                # Проверяем содержимое
                with open(zip_path, 'rb') as f:
                    header = f.read(100)
                    logger.info(f"Заголовок файла: {header[:50]}")
                raise Exception("Файл не является zip-архивом")

            logger.info("Распаковка архива...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(self.install_path)

            self.safe_remove(zip_path)
            logger.info("Архив распакован, временный файл удален")

            # Сохраняем версию
            version_file = os.path.join(self.install_path, "version.txt")
            with open(version_file, 'w') as f:
                f.write(version_info['version'])
            logger.info(f"Сохранена версия: {version_info['version']}")

            # Создаем ярлыки
            if self.desktop_check.isChecked():
                self.create_desktop_shortcut()

            if self.startmenu_check.isChecked():
                self.create_start_menu_shortcut()

            self.progress_bar.setVisible(False)
            self.install_btn.setEnabled(True)
            self.uninstall_btn.setEnabled(True)
            self.check_installation()

            logger.info("Установка завершена успешно")
            QMessageBox.information(self, "Успех",
                                    f"Версия {version_info['version']} успешно установлена!")

        except Exception as e:
            error_msg = str(e)
            logger.error(f"ОШИБКА РАСПАКОВКИ: {error_msg}")
            self.progress_bar.setVisible(False)
            self.install_btn.setEnabled(True)
            self.uninstall_btn.setEnabled(True)
            self.start_btn.setEnabled(False)
            self.status_label.setText("● Ошибка")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #d13438;
                background-color: #fde7e9;
                padding: 6px 14px;
                border-radius: 12px;
            """)
            QMessageBox.critical(self, "Ошибка распаковки",
                                 f"{error_msg}\n\nПроверьте файл launcher_debug.log для деталей.")

    def download_error(self, error_msg):
        logger.error(f"ОШИБКА СКАЧИВАНИЯ: {error_msg}")
        self.progress_bar.setVisible(False)
        self.install_btn.setEnabled(True)
        self.uninstall_btn.setEnabled(True)
        self.start_btn.setEnabled(False)
        self.status_label.setText("● Ошибка")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #d13438;
            background-color: #fde7e9;
            padding: 6px 14px;
            border-radius: 12px;
        """)

        QMessageBox.critical(self, "Ошибка скачивания",
                             f"{error_msg}\n\nПроверьте файл launcher_debug.log для деталей.")

    def create_desktop_shortcut(self):
        """Создает ярлык на рабочем столе"""
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        shortcut_path = os.path.join(desktop, "ChatTwitch.lnk")

        try:
            import pythoncom
            from win32com.client import Dispatch

            shell = Dispatch("WScript.Shell")
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.TargetPath = os.path.join(self.install_path, "ChatTwitch.exe")
            shortcut.WorkingDirectory = self.install_path
            shortcut.IconLocation = os.path.join(self.install_path, "ChatTwitch.exe")
            shortcut.save()
            logger.info("Ярлык создан на рабочем столе")
            self.statusBar().showMessage("Ярлык создан на рабочем столе")
        except Exception as e:
            logger.error(f"Ошибка создания ярлыка: {str(e)}")
            # Альтернативный способ
            bat_path = os.path.join(desktop, "ChatTwitch.bat")
            with open(bat_path, 'w') as f:
                f.write(f'@start "" "{os.path.join(self.install_path, "ChatTwitch.exe")}"')
            logger.info("Создан BAT-файл на рабочем столе")
            self.statusBar().showMessage("Создан BAT-файл на рабочем столе")

    def create_start_menu_shortcut(self):
        """Создает ярлык в меню 'Пуск'"""
        try:
            # Путь к папке программ в меню Пуск
            start_menu_path = os.path.join(
                os.environ.get('APPDATA', ''),
                'Microsoft', 'Windows', 'Start Menu', 'Programs'
            )

            # Создаем папку для программы, если её нет
            program_folder = os.path.join(start_menu_path, 'ChatTwitch')
            os.makedirs(program_folder, exist_ok=True)

            # Путь к ярлыку
            shortcut_path = os.path.join(program_folder, 'ChatTwitch.lnk')

            # Создаем ярлык
            import pythoncom
            from win32com.client import Dispatch

            shell = Dispatch("WScript.Shell")
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.TargetPath = os.path.join(self.install_path, "ChatTwitch.exe")
            shortcut.WorkingDirectory = self.install_path
            shortcut.IconLocation = os.path.join(self.install_path, "ChatTwitch.exe")
            shortcut.save()

            logger.info(f"Ярлык создан в меню 'Пуск': {shortcut_path}")
            self.statusBar().showMessage("Ярлык добавлен в меню 'Пуск'")

        except Exception as e:
            logger.error(f"Ошибка создания ярлыка в меню 'Пуск': {str(e)}")
            # Альтернативный способ с BAT-файлом
            try:
                start_menu_path = os.path.join(
                    os.environ.get('APPDATA', ''),
                    'Microsoft', 'Windows', 'Start Menu', 'Programs'
                )
                program_folder = os.path.join(start_menu_path, 'ChatTwitch')
                os.makedirs(program_folder, exist_ok=True)

                bat_path = os.path.join(program_folder, 'ChatTwitch.bat')
                with open(bat_path, 'w') as f:
                    f.write(f'@start "" "{os.path.join(self.install_path, "ChatTwitch.exe")}"')
                logger.info("Создан BAT-файл в меню 'Пуск'")
                self.statusBar().showMessage("BAT-файл добавлен в меню 'Пуск'")
            except Exception as e2:
                logger.error(f"Ошибка создания BAT-файла в меню 'Пуск': {str(e2)}")

    def start_main_app(self):
        """Запуск основной программы"""
        logger.info("Попытка запуска основной программы")
        self.statusBar().showMessage("Запуск программы...")

        # Запускаем основную программу
        if self.main_process.start_app():
            # Отключаем кнопку, пока программа запущена
            self.start_btn.setEnabled(False)
            self.start_btn.setText("⏳ Запущена...")
            self.status_label.setText("● Запущена")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #0078d4;
                background-color: #e6f2ff;
                padding: 6px 14px;
                border-radius: 12px;
            """)
            self.statusBar().showMessage("Программа запущена")

    def uninstall_app(self):
        reply = QMessageBox.question(self, "Удаление программы",
                                     "Вы уверены, что хотите удалить ChatTwitch?\n"
                                     f"Папка: {self.install_path}",
                                     QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            try:
                # Удаляем ярлыки
                # 1. С рабочего стола
                desktop = os.path.join(os.path.expanduser("~"), "Desktop")
                desktop_shortcut = os.path.join(desktop, "ChatTwitch.lnk")
                if os.path.exists(desktop_shortcut):
                    os.remove(desktop_shortcut)
                    logger.info(f"Удален ярлык с рабочего стола: {desktop_shortcut}")

                desktop_bat = os.path.join(desktop, "ChatTwitch.bat")
                if os.path.exists(desktop_bat):
                    os.remove(desktop_bat)
                    logger.info(f"Удален BAT-файл с рабочего стола: {desktop_bat}")

                # 2. Из меню 'Пуск'
                start_menu_path = os.path.join(
                    os.environ.get('APPDATA', ''),
                    'Microsoft', 'Windows', 'Start Menu', 'Programs', 'ChatTwitch'
                )
                if os.path.exists(start_menu_path):
                    import shutil
                    shutil.rmtree(start_menu_path)
                    logger.info(f"Удалена папка из меню 'Пуск': {start_menu_path}")

                # Удаляем папку с программой
                if os.path.exists(self.install_path):
                    import shutil
                    shutil.rmtree(self.install_path)
                    logger.info(f"Программа удалена из: {self.install_path}")

                self.check_installation()
                self.statusBar().showMessage("Программа удалена")
                QMessageBox.information(self, "Успех", "Программа успешно удалена!")
            except Exception as e:
                logger.error(f"Ошибка удаления: {str(e)}")
                QMessageBox.critical(self, "Ошибка", f"Не удалось удалить программу:\n{str(e)}")

    def closeEvent(self, event):
        """Обработка закрытия лаунчера"""
        logger.info("Закрытие лаунчера...")
        # Если основная программа запущена, завершаем её
        if self.main_process.state() == QProcess.Running:
            self.main_process.terminate()
            self.main_process.waitForFinished(3000)
        event.accept()

def run_main_app():
    """Запускает основную программу (Flask + оверлей) без лаунчера."""
    try:
        from web import app, socketio
        from window import run_overlay_window
        import threading

        # Запускаем Flask‑сервер в отдельном потоке (чтобы не блокировать GUI)
        def start_flask():
            socketio.run(app, host='0.0.0.0', port=5000, debug=False, use_reloader=False, allow_unsafe_werkzeug=True)

        flask_thread = threading.Thread(target=start_flask, daemon=True)
        flask_thread.start()
        logger.info("Flask‑сервер запущен в фоновом потоке")

        # Запускаем окно оверлея (это блокирующий вызов – пока окно открыто)
        run_overlay_window()
        logger.info("Окно оверлея закрыто, завершаем программу")

    except Exception as e:
        logger.error(f"Ошибка при запуске основной программы: {e}", exc_info=True)
        input("Нажмите Enter для выхода...")  # чтобы увидеть ошибку в консоли

def main():
    if TESTMODE:
        logger.info("Запуск в режиме разработки (лаунчер пропущен)")
        run_main_app()
        return

    # Стандартный запуск лаунчера для пользователей
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    launcher = ModernLauncher()
    launcher.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()