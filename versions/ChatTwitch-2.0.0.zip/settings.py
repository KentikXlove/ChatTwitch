import json
import os
from logger import get_logger

logger = get_logger(__name__)

SETTINGS_DIR = "data"
SETTINGS_FILE = os.path.join(SETTINGS_DIR, "config.json")

DEFAULT_CONFIG = {
    "nickname": "",
    "ttl": 0,
    "css": "",
    "log_messages": False,
    "max_messages": 100,
    "show_viewers_in_overlay": False,
    "group_messages": False,
    "show_avatars": True,
    "username_color_mode": "twitch",  # twitch, fixed, random
    "username_fixed_color": "#7c5cfc",
    "avatar_size": 28,
    "message_bg_color": "#111118",
    # НАСТРОЙКИ АНИМАЦИЙ
    "animation": {
        "entry": "fade",  # fade, slide, pop, typewriter, bounce, glow, flip
        "exit": "fade",  # fade, slide, pop, typewriter, bounce, glow, flip
        "speed": 300,  # миллисекунды (50-2000)
        "delay": 0  # миллисекунды (0-1000)
    }
}


# Для обратной совместимости — если в конфиге нет animation, добавляем
def _ensure_animation_field(config):
    """Гарантирует наличие поля animation в конфиге"""
    if "animation" not in config:
        config["animation"] = DEFAULT_CONFIG["animation"].copy()
        logger.info("Добавлено поле animation в конфиг (значения по умолчанию)")
    else:
        # Проверяем, что все подполя есть
        anim = config["animation"]
        default_anim = DEFAULT_CONFIG["animation"]
        for key, value in default_anim.items():
            if key not in anim:
                anim[key] = value
                logger.info(f"Добавлено поле animation.{key} = {value}")

    # Проверяем корректность значений
    valid_entry = ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip']
    valid_exit = ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip']

    if config["animation"]["entry"] not in valid_entry:
        config["animation"]["entry"] = "fade"
    if config["animation"]["exit"] not in valid_exit:
        config["animation"]["exit"] = "fade"
    config["animation"]["speed"] = max(50, min(2000, config["animation"].get("speed", 300)))
    config["animation"]["delay"] = max(0, min(1000, config["animation"].get("delay", 0)))

    return config


def _ensure_missing_fields(config):
    """Добавляет отсутствующие поля со значениями по умолчанию"""
    updated = False
    for key, value in DEFAULT_CONFIG.items():
        if key not in config:
            config[key] = value
            updated = True
            logger.info(f"Добавлено поле {key} = {value} (значение по умолчанию)")

    # Особо проверяем вложенные структуры
    if "animation" in config:
        _ensure_animation_field(config)
    else:
        config = _ensure_animation_field(config)
        updated = True

    return config, updated


def load_config():
    """Загружает конфиг, дополняя недостающие поля значениями по умолчанию"""
    os.makedirs(SETTINGS_DIR, exist_ok=True)

    if not os.path.exists(SETTINGS_FILE):
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()

    try:
        with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
            config = json.load(f)

        # Дополняем недостающие поля
        config, updated = _ensure_missing_fields(config)

        if updated:
            save_config(config)
            logger.info("Конфиг обновлён до актуальной версии")

        return config
    except Exception as e:
        logger.error(f"Ошибка загрузки конфига: {e}")
        # Возвращаем дефолтный конфиг, но сохраняем его
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()


def save_config(config):
    os.makedirs(SETTINGS_DIR, exist_ok=True)
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)