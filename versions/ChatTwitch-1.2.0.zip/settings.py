import json
import os
from logger import get_logger

logger = get_logger(__name__)

SETTINGS_DIR = "data"
SETTINGS_FILE = os.path.join(SETTINGS_DIR, "config.json")

DEFAULT_CONFIG = {
    "nickname": "",
    "ttl": 0,
    "css": "",
    "log_messages": False,
    "max_messages": 100,
    "show_viewers_in_overlay": False,
    "group_messages": False,
    "show_avatars": True,
    "username_color_mode": "twitch",   # twitch, fixed, random
    "username_fixed_color": "#7c5cfc",
    "avatar_size": 28,
    "message_bg_color": "#111118"
}

def load_config():
    if not os.path.exists(SETTINGS_FILE):
        os.makedirs(SETTINGS_DIR, exist_ok=True)
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    try:
        with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
            config = json.load(f)
        for key, value in DEFAULT_CONFIG.items():
            config.setdefault(key, value)
        return config
    except Exception as e:
        logger.error(f"Ошибка загрузки конфига: {e}")
        return DEFAULT_CONFIG.copy()

def save_config(config):
    os.makedirs(SETTINGS_DIR, exist_ok=True)
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)