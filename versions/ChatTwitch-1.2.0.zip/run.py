import threading
import time
import sys
import traceback
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import messagebox
import webbrowser

from data.version import VERSION
from web import app, socketio
from window import run_overlay_window
from logger import AppLogger, get_logger

# Глобальная переменная для хранения результата проверки версии
version_check_result = {
    'new_version_available': False,
    'remote_version': None,
    'user_agreed_to_update': False
}


def check_version():
    """Проверяет актуальность версии, сравнивая с удалённым version.txt."""
    logger = get_logger("version")
    url = "https://cdn.jsdelivr.net/gh/KentikXlove/ChatTwitch@main/version.txt"
    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            remote_version = response.read().decode('utf-8').strip()

        if remote_version != VERSION:
            logger.warning(
                f"Доступна новая версия: {remote_version} (текущая {VERSION}). "
                "Рекомендуется обновиться."
            )
            version_check_result['new_version_available'] = True
            version_check_result['remote_version'] = remote_version
        else:
            logger.info(f"Версия актуальна: {VERSION}")
            version_check_result['new_version_available'] = False
    except urllib.error.URLError as e:
        logger.error(f"Не удалось проверить версию: {e}")
        version_check_result['new_version_available'] = False
    except Exception as e:
        logger.error(f"Ошибка при проверке версии: {e}")
        version_check_result['new_version_available'] = False


def show_update_notification():
    """Показывает уведомление о доступном обновлении."""
    root = tk.Tk()
    root.withdraw()  # Скрываем главное окно

    # Создаем кастомное окно поверх всех
    dialog = tk.Toplevel(root)
    dialog.title("Доступно обновление!")
    dialog.geometry("500x220")
    dialog.resizable(False, False)
    dialog.attributes('-topmost', True)  # Всегда поверх всех окон

    # Центрируем окно
    dialog.update_idletasks()
    width = dialog.winfo_width()
    height = dialog.winfo_height()
    x = (dialog.winfo_screenwidth() // 2) - (width // 2)
    y = (dialog.winfo_screenheight() // 2) - (height // 2)
    dialog.geometry(f'{width}x{height}+{x}+{y}')

    # Заголовок
    title_label = tk.Label(
        dialog,
        text="🔄 Обнаружена новая версия!",
        font=("Arial", 16, "bold"),
        fg="#2196F3"
    )
    title_label.pack(pady=(20, 10))

    # Информация о версиях
    version_label = tk.Label(
        dialog,
        text=f"Текущая версия: {VERSION}\nДоступна версия: {version_check_result['remote_version']}",
        font=("Arial", 12)
    )
    version_label.pack(pady=5)

    # Информационное сообщение
    info_label = tk.Label(
        dialog,
        text="Рекомендуется обновиться для получения новых функций и исправлений.",
        font=("Arial", 10),
        fg="#666"
    )
    info_label.pack(pady=5)

    # Фрейм для кнопок
    button_frame = tk.Frame(dialog)
    button_frame.pack(pady=20)

    # Функция для скачивания обновления
    def download_update():
        # Формируем URL для скачивания
        download_url = f"https://github.com/KentikXlove/ChatTwitch/blob/main/versions/ChatTwitch-{version_check_result['remote_version']}.zip"
        webbrowser.open(download_url)
        # Показываем сообщение о скачивании
        messagebox.showinfo(
            "Скачивание обновления",
            "Файл обновления открыт в браузере.\n"
            "После скачивания распакуйте архив и замените файлы.\n"
            "Для применения обновления перезапустите программу."
        )
        # Закрываем диалог
        dialog.destroy()
        root.quit()

    # Функция для продолжения без обновления
    def continue_without_update():
        # Спрашиваем подтверждение
        if messagebox.askyesno(
                "Пропуск обновления",
                "Вы уверены, что хотите продолжить работу без обновления?\n"
                "Некоторые функции могут работать некорректно."
        ):
            version_check_result['user_agreed_to_update'] = False
            dialog.destroy()
            root.quit()

    # Кнопка "Скачать"
    download_btn = tk.Button(
        button_frame,
        text="📥 Скачать обновление",
        command=download_update,
        font=("Arial", 11),
        bg="#4CAF50",
        fg="white",
        padx=20,
        pady=8
    )
    download_btn.pack(side=tk.LEFT, padx=10)

    # Кнопка "Продолжить без обновления"
    skip_btn = tk.Button(
        button_frame,
        text="⏭️ Продолжить",
        command=continue_without_update,
        font=("Arial", 11),
        bg="#FF9800",
        fg="white",
        padx=20,
        pady=8
    )
    skip_btn.pack(side=tk.LEFT, padx=10)

    # Обработка закрытия окна через X (равносильно продолжению)
    def on_closing():
        if messagebox.askyesno(
                "Пропуск обновления",
                "Вы уверены, что хотите продолжить работу без обновления?"
        ):
            version_check_result['user_agreed_to_update'] = False
            dialog.destroy()
            root.quit()

    dialog.protocol("WM_DELETE_WINDOW", on_closing)

    # Запускаем главный цикл
    try:
        root.mainloop()
    except KeyboardInterrupt:
        sys.exit(0)


def start_flask():
    logger = get_logger("flask")
    logger.info("Запуск Flask-SocketIO сервера на 127.0.0.1:5000")
    try:
        socketio.run(app, host='127.0.0.1', port=5000, debug=False,
                     use_reloader=False, allow_unsafe_werkzeug=True)
    except Exception as e:
        logger.error(f"Ошибка Flask: {e}\n{traceback.format_exc()}")


if __name__ == '__main__':
    # Настройка логирования
    AppLogger.setup()
    main_logger = get_logger("main")


    # Перехват всех необработанных исключений
    def global_exception_handler(exc_type, exc_value, exc_tb):
        logger = get_logger("exception")
        logger.critical(
            "Необработанное исключение:\n"
            f"{''.join(traceback.format_exception(exc_type, exc_value, exc_tb))}"
        )


    sys.excepthook = global_exception_handler

    main_logger.info("=" * 50)
    main_logger.info("Запуск Twitch Chat Overlay v2.0")
    main_logger.info("=" * 50)

    # Проверка версии (с таймаутом, чтобы не задерживать старт)
    main_logger.info("Проверка обновлений...")
    check_version()

    # Если доступно обновление - показываем уведомление
    if version_check_result['new_version_available']:
        main_logger.info("Обнаружено обновление! Показываем уведомление пользователю.")
        show_update_notification()
        # Если пользователь закрыл уведомление без выбора, продолжаем работу
        # (по умолчанию user_agreed_to_update = False)

    # Продолжаем запуск независимо от решения пользователя
    try:
        flask_thread = threading.Thread(target=start_flask, daemon=True)
        flask_thread.start()
        main_logger.info("Ожидание запуска веб-сервера...")
        time.sleep(2)
        main_logger.info("Запуск нативного окна управления")
        run_overlay_window()
    except KeyboardInterrupt:
        main_logger.info("Приложение остановлено пользователем")
    except Exception as e:
        main_logger.critical(f"Критическая ошибка при запуске: {e}\n{traceback.format_exc()}")
    finally:
        main_logger.info("Завершение работы")