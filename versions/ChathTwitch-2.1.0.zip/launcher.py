import sys
import os
import json
import zipfile
import requests
import time
import logging
import re
import shutil
from pathlib import Path
from datetime import datetime
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

# Настройка логирования
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('launcher_debug.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Константы
VERSIONS_URL = "https://cdn.jsdelivr.net/gh/KentikXlove/ChatTwitch@main/versions.json"
INSTALL_BASE_PATH = "C:/ChatTwitch"
LAUNCHER_NAME = "launcher.exe"


class DownloadWorker(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, file_id, dest):
        super().__init__()
        self.file_id = file_id
        self.dest = dest
        self.session = requests.Session()

    def run(self):
        try:
            logger.info(f"Начинаем загрузку с Google Drive ID: {self.file_id}")
            self.download_from_google_drive()

            if not self.verify_download():
                return

            self.finished.emit()

        except Exception as e:
            logger.error(f"Ошибка загрузки: {str(e)}", exc_info=True)
            self.error.emit(str(e))

    def download_from_google_drive(self):
        """Скачивание больших файлов с Google Drive с обработкой предупреждения"""
        try:
            url = "https://drive.google.com/uc"
            params = {'id': self.file_id, 'export': 'download'}

            response = self.session.get(url, params=params)
            logger.info(f"Получен ответ от Google Drive: {response.status_code}")

            if 'uc-download-link' in response.text or 'confirm' in response.text:
                logger.info("Обнаружено предупреждение о вирусах, подтверждаем...")
                form_data = {}

                hidden_fields = re.findall(r'<input type="hidden" name="([^"]+)" value="([^"]+)"', response.text)
                for name, value in hidden_fields:
                    form_data[name] = value

                action_match = re.search(r'<form[^>]+action="([^"]+)"', response.text)
                action_url = action_match.group(1) if action_match else "https://drive.usercontent.google.com/download"

                for key, value in params.items():
                    if key not in form_data:
                        form_data[key] = value

                logger.info(f"Параметры формы: {form_data}")
                download_response = self.session.get(action_url, params=form_data, stream=True)

                if download_response.history:
                    logger.info("Следование по перенаправлению...")
                    final_response = download_response.history[-1]
                    if final_response.status_code == 302:
                        redirect_url = final_response.headers.get('Location')
                        if redirect_url:
                            download_response = self.session.get(redirect_url, stream=True)

                if download_response.status_code == 200:
                    total_size = int(download_response.headers.get('content-length', 0))
                    logger.info(f"Размер файла: {total_size / (1024 * 1024):.2f} MB")

                    with open(self.dest, 'wb') as f:
                        downloaded = 0
                        for chunk in download_response.iter_content(chunk_size=32768):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                if total_size > 0:
                                    percent = (downloaded / total_size) * 100
                                    self.progress.emit(int(percent))

                    logger.info(f"Файл сохранен: {self.dest}")
                else:
                    raise Exception(f"Ошибка скачивания: {download_response.status_code}")
            else:
                logger.info("Прямое скачивание...")
                download_url = f"https://drive.google.com/uc?export=download&id={self.file_id}"
                download_response = self.session.get(download_url, stream=True)

                if download_response.status_code == 200:
                    total_size = int(download_response.headers.get('content-length', 0))
                    with open(self.dest, 'wb') as f:
                        downloaded = 0
                        for chunk in download_response.iter_content(chunk_size=32768):
                            if chunk:
                                f.write(chunk)
                                downloaded += len(chunk)
                                if total_size > 0:
                                    percent = (downloaded / total_size) * 100
                                    self.progress.emit(int(percent))
                else:
                    raise Exception(f"Ошибка скачивания: {download_response.status_code}")

        except Exception as e:
            logger.error(f"Ошибка в download_from_google_drive: {str(e)}")
            raise

    def verify_download(self):
        """Проверка скачанного файла"""
        try:
            logger.info(f"Проверка файла: {self.dest}")

            if not os.path.exists(self.dest):
                self.error.emit("Файл не был создан")
                return False

            file_size = os.path.getsize(self.dest)
            if file_size == 0:
                self.error.emit("Скачанный файл пуст")
                return False

            with open(self.dest, 'rb') as f:
                header = f.read(200)
                if b'<!DOCTYPE' in header or b'<html' in header:
                    logger.error("Файл содержит HTML, а не zip архив")
                    self.safe_remove(self.dest)
                    self.error.emit("Google Drive вернул HTML страницу.\nВозможно, файл слишком большой.")
                    return False

            if not zipfile.is_zipfile(self.dest):
                logger.error("Файл не является zip архивом")
                self.safe_remove(self.dest)
                self.error.emit("Файл не является zip архивом")
                return False

            return True

        except Exception as e:
            logger.error(f"Ошибка проверки файла: {str(e)}")
            self.error.emit(str(e))
            return False

    def safe_remove(self, filepath):
        for i in range(5):
            try:
                if os.path.exists(filepath):
                    os.remove(filepath)
                return True
            except Exception as e:
                logger.warning(f"Попытка {i + 1} удалить файл не удалась: {str(e)}")
                time.sleep(0.5)
        return False


class MainAppProcess(QProcess):
    """Класс для управления процессом основной программы"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent

    def start_app(self, version_path):
        """Запуск основной программы"""
        try:
            logger.info(f"Запуск основной программы из {version_path}")
            app_path = os.path.join(version_path, "ChatTwitch.exe")

            if not os.path.exists(app_path):
                logger.error(f"Файл программы не найден: {app_path}")
                return False

            self.setProgram(app_path)
            self.start()

            self.parent_window.hide()

            self.finished.connect(self.on_app_closed)
            logger.info("Основная программа запущена")
            return True

        except Exception as e:
            logger.error(f"Ошибка запуска программы: {str(e)}")
            return False

    def on_app_closed(self, exit_code, exit_status):
        """Обработка закрытия основной программы"""
        logger.info(f"Основная программа завершена (код: {exit_code})")
        if self.parent_window:
            self.parent_window.show()
            self.parent_window.raise_()
            self.parent_window.activateWindow()
            self.parent_window.update_ui_state()


class ModernLauncher(QMainWindow):
    def __init__(self):
        super().__init__()
        self.versions_data = None
        self.latest_version = None
        self.install_base_path = INSTALL_BASE_PATH
        self.current_version = None
        self.current_version_path = None
        self.download_worker = None
        self.main_process = MainAppProcess(self)
        self.selected_version = None

        # Создаем базовую папку если её нет
        os.makedirs(self.install_base_path, exist_ok=True)

        self.initUI()
        self.check_installation()
        self.load_versions()

    def initUI(self):
        self.setWindowTitle("ChatTwitch Launcher")
        self.setFixedSize(800, 650)

        # Пробуем установить иконку
        try:
            self.setWindowIcon(QIcon("icon.ico"))
        except:
            pass

        self.setStyleSheet("""
            QMainWindow { background-color: #f5f5f5; }
            QLabel {
                color: #333333;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            QPushButton {
                background-color: #0078d4;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
                font-size: 13px;
                font-weight: 500;
                font-family: 'Segoe UI', Arial, sans-serif;
                min-height: 36px;
            }
            QPushButton:hover { background-color: #106ebe; }
            QPushButton:pressed { background-color: #005a9e; }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QPushButton#install_btn {
                background-color: #107c10;
                font-weight: 600;
            }
            QPushButton#install_btn:hover { background-color: #0a6b0a; }
            QPushButton#install_btn:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QPushButton#uninstall_btn {
                background-color: #d13438;
                font-weight: 600;
            }
            QPushButton#uninstall_btn:hover { background-color: #b8282c; }
            QPushButton#uninstall_btn:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QPushButton#start_btn {
                background-color: #4CAF50;
                font-weight: 600;
                font-size: 14px;
            }
            QPushButton#start_btn:hover { background-color: #45a049; }
            QPushButton#start_btn:disabled {
                background-color: #cccccc;
                color: #888888;
            }
            QGroupBox {
                font-family: 'Segoe UI', Arial, sans-serif;
                font-weight: 600;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                margin-top: 12px;
                padding-top: 12px;
                background-color: white;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 16px;
                padding: 0 8px 0 8px;
                color: #333333;
                background-color: white;
            }
            QListWidget {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                padding: 4px;
                background-color: white;
                font-family: 'Segoe UI', Arial, sans-serif;
                outline: none;
            }
            QListWidget::item {
                padding: 8px 12px;
                border-radius: 3px;
            }
            QListWidget::item:selected {
                background-color: #e6f2ff;
                color: #0078d4;
            }
            QListWidget::item:hover {
                background-color: #f0f6ff;
            }
            QProgressBar {
                background-color: #e0e0e0;
                border: none;
                border-radius: 3px;
                height: 8px;
                text-align: center;
                color: #333333;
                font-size: 11px;
            }
            QProgressBar::chunk {
                background-color: #0078d4;
                border-radius: 3px;
            }
            QStatusBar {
                background-color: #f5f5f5;
                color: #666666;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(16)
        main_layout.setContentsMargins(32, 24, 32, 24)

        # Верхняя панель
        header_layout = QHBoxLayout()
        header_layout.setSpacing(12)

        title_label = QLabel("ChatTwitch Launcher")
        title_label.setStyleSheet("""
            font-size: 26px;
            font-weight: 300;
            color: #0078d4;
            letter-spacing: 0.5px;
        """)
        header_layout.addWidget(title_label)

        header_layout.addStretch()

        self.version_label = QLabel("Не установлено")
        self.version_label.setStyleSheet("""
            font-size: 13px;
            color: #666666;
            background-color: #f0f0f0;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        header_layout.addWidget(self.version_label)

        self.status_label = QLabel("● Ожидание")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #ff8c00;
            background-color: #fff4e6;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        header_layout.addWidget(self.status_label)

        main_layout.addLayout(header_layout)

        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setStyleSheet("background-color: #e0e0e0; max-height: 1px;")
        main_layout.addWidget(separator)

        # Основная сетка
        content_layout = QGridLayout()
        content_layout.setSpacing(16)

        # Новости
        news_group = QGroupBox("Новости и обновления")
        news_group.setMinimumHeight(150)
        news_layout = QVBoxLayout(news_group)

        self.news_label = QLabel("Загрузка информации...")
        self.news_label.setWordWrap(True)
        self.news_label.setStyleSheet("""
            padding: 12px;
            background-color: #fafafa;
            border-radius: 4px;
            font-size: 13px;
            line-height: 1.5;
            color: #444444;
        """)
        news_layout.addWidget(self.news_label)
        content_layout.addWidget(news_group, 0, 0, 1, 1)

        # Версии
        versions_group = QGroupBox("Доступные версии")
        versions_layout = QVBoxLayout(versions_group)

        self.versions_list = QListWidget()
        self.versions_list.setMaximumHeight(110)
        self.versions_list.itemSelectionChanged.connect(self.on_version_selected)
        versions_layout.addWidget(self.versions_list)
        content_layout.addWidget(versions_group, 0, 1, 1, 1)

        # Информация о версиях
        info_group = QGroupBox("Установленные версии")
        info_layout = QVBoxLayout(info_group)

        self.installed_versions_list = QListWidget()
        self.installed_versions_list.setMaximumHeight(80)
        info_layout.addWidget(self.installed_versions_list)
        content_layout.addWidget(info_group, 1, 0, 1, 2)

        main_layout.addLayout(content_layout)

        # Прогресс-бар
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)

        # Кнопки
        buttons_layout = QHBoxLayout()
        buttons_layout.setSpacing(12)

        self.install_btn = QPushButton("Установить")
        self.install_btn.setObjectName("install_btn")
        self.install_btn.setMinimumWidth(180)
        self.install_btn.clicked.connect(self.install_or_update)
        self.install_btn.setEnabled(False)
        buttons_layout.addWidget(self.install_btn)

        self.start_btn = QPushButton("▶ Запустить")
        self.start_btn.setObjectName("start_btn")
        self.start_btn.setMinimumWidth(140)
        self.start_btn.clicked.connect(self.start_main_app)
        self.start_btn.setEnabled(False)
        buttons_layout.addWidget(self.start_btn)

        self.uninstall_btn = QPushButton("Удалить версию")
        self.uninstall_btn.setObjectName("uninstall_btn")
        self.uninstall_btn.setMinimumWidth(120)
        self.uninstall_btn.clicked.connect(self.uninstall_version)
        self.uninstall_btn.setEnabled(False)
        buttons_layout.addWidget(self.uninstall_btn)

        buttons_layout.addStretch()

        main_layout.addLayout(buttons_layout)

        self.statusBar().showMessage("Готов к работе")
        logger.info("Лаунчер запущен")

    def on_version_selected(self):
        """Обработка выбора версии в списке"""
        selected = self.versions_list.currentRow()
        if selected >= 0 and self.versions_data:
            self.selected_version = self.versions_data['versions'][selected]
            self.install_btn.setEnabled(True)

            # Проверяем, установлена ли эта версия
            version_path = os.path.join(self.install_base_path, f"v{self.selected_version['version']}")
            is_installed = os.path.exists(version_path) and os.path.exists(os.path.join(version_path, "ChatTwitch.exe"))

            if is_installed:
                self.install_btn.setText("Обновить")
                self.start_btn.setEnabled(True)
                self.uninstall_btn.setEnabled(True)
            else:
                self.install_btn.setText("Установить")
                self.start_btn.setEnabled(False)
                self.uninstall_btn.setEnabled(False)

    def load_versions(self):
        """Загрузка списка версий"""
        try:
            logger.info("Загрузка информации о версиях...")
            response = requests.get(VERSIONS_URL, timeout=10)
            self.versions_data = response.json()
            self.latest_version = self.versions_data['latest']

            self.versions_list.clear()
            for ver in self.versions_data['versions']:
                item = QListWidgetItem(f"Версия {ver['version']}")
                if ver['version'] == self.latest_version['version']:
                    item.setText(f"⭐ {item.text()} (последняя)")
                    item.setForeground(QColor(0, 120, 212))
                self.versions_list.addItem(item)

            if self.versions_list.count() > 0:
                self.versions_list.setCurrentRow(0)

            if 'notes' in self.latest_version:
                self.news_label.setText(
                    f"<b>Версия {self.latest_version['version']}</b><br>{self.latest_version['notes']}")

            logger.info(f"Загружено {len(self.versions_data['versions'])} версий")
            self.statusBar().showMessage("Информация о версиях загружена")

        except Exception as e:
            error_msg = f"Не удалось загрузить информацию о версиях: {str(e)}"
            self.news_label.setText(error_msg)
            logger.error(f"ОШИБКА: {error_msg}")
            self.statusBar().showMessage(error_msg)

    def check_installation(self):
        """Проверка установленных версий"""
        self.installed_versions_list.clear()
        installed = []

        # Проверяем папки с версиями
        for item in os.listdir(self.install_base_path):
            version_path = os.path.join(self.install_base_path, item)
            if os.path.isdir(version_path) and item.startswith('v'):
                exe_path = os.path.join(version_path, "ChatTwitch.exe")
                if os.path.exists(exe_path):
                    version_num = item[1:]  # Убираем 'v'
                    installed.append(version_num)
                    self.installed_versions_list.addItem(f"Версия {version_num}")

        if installed:
            # Сортируем по убыванию
            installed.sort(key=lambda x: [int(i) for i in x.split('.')], reverse=True)
            latest_installed = installed[0]

            self.current_version = latest_installed
            self.current_version_path = os.path.join(self.install_base_path, f"v{latest_installed}")
            self.version_label.setText(f"Версия {latest_installed}")
            self.status_label.setText("● Установлено")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #107c10;
                background-color: #e6f2e6;
                padding: 6px 14px;
                border-radius: 12px;
            """)

            # Если выбрана версия, проверяем её установку
            if self.selected_version:
                self.on_version_selected()

            logger.info(f"Найдена установленная версия: {latest_installed}")
        else:
            self.current_version = None
            self.current_version_path = None
            self.version_label.setText("Не установлено")
            self.status_label.setText("● Не установлено")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #d13438;
                background-color: #fde7e9;
                padding: 6px 14px;
                border-radius: 12px;
            """)
            self.start_btn.setEnabled(False)
            logger.info("Программа не установлена")

    def install_or_update(self):
        """Установка или обновление выбранной версии"""
        if not self.selected_version:
            QMessageBox.warning(self, "Ошибка", "Выберите версию для установки")
            return

        version = self.selected_version['version']
        version_path = os.path.join(self.install_base_path, f"v{version}")

        # Проверяем, не запущена ли программа
        if self.main_process.state() == QProcess.Running:
            QMessageBox.warning(self, "Ошибка", "Программа запущена. Закройте её перед установкой.")
            return

        logger.info(f"Установка версии {version}")
        self.download_and_install(self.selected_version)

    def download_and_install(self, version_info):
        """Скачивание и установка версии"""
        version = version_info['version']
        version_path = os.path.join(self.install_base_path, f"v{version}")
        os.makedirs(version_path, exist_ok=True)

        zip_path = os.path.join(version_path, "temp.zip")
        self.safe_remove(zip_path)

        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.status_label.setText("● Скачивание...")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #0078d4;
            background-color: #e6f2ff;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        self.install_btn.setEnabled(False)
        self.uninstall_btn.setEnabled(False)
        self.start_btn.setEnabled(False)

        logger.info(f"Начинаем скачивание версии {version}...")

        self.download_worker = DownloadWorker(version_info['id'], zip_path)
        self.download_worker.progress.connect(self.update_progress)
        self.download_worker.finished.connect(lambda: self.extract_zip(zip_path, version_info))
        self.download_worker.error.connect(self.download_error)
        self.download_worker.start()

    def safe_remove(self, filepath):
        """Безопасное удаление файла"""
        for i in range(5):
            try:
                if os.path.exists(filepath):
                    os.remove(filepath)
                return True
            except Exception as e:
                logger.warning(f"Попытка {i + 1} удалить файл не удалась: {str(e)}")
                time.sleep(0.5)
        return False

    def update_progress(self, value):
        self.progress_bar.setValue(value)
        self.statusBar().showMessage(f"Загрузка: {value}%")

    def extract_zip(self, zip_path, version_info):
        """Распаковка архива"""
        version = version_info['version']
        version_path = os.path.join(self.install_base_path, f"v{version}")

        logger.info(f"Начинаем распаковку: {zip_path}")
        self.status_label.setText("● Распаковка...")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #0078d4;
            background-color: #e6f2ff;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        self.statusBar().showMessage("Распаковка архива...")

        try:
            if not os.path.exists(zip_path):
                raise Exception(f"Файл не найден: {zip_path}")

            if not zipfile.is_zipfile(zip_path):
                raise Exception("Файл не является zip-архивом")

            # Распаковываем во временную папку
            temp_extract = os.path.join(version_path, "temp_extract")
            os.makedirs(temp_extract, exist_ok=True)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_extract)

            # Перемещаем файлы из временной папки
            for item in os.listdir(temp_extract):
                src = os.path.join(temp_extract, item)
                dst = os.path.join(version_path, item)
                if os.path.exists(dst):
                    if os.path.isdir(dst):
                        shutil.rmtree(dst)
                    else:
                        os.remove(dst)
                shutil.move(src, dst)

            # Удаляем временную папку
            shutil.rmtree(temp_extract)
            self.safe_remove(zip_path)

            logger.info("Архив распакован, временные файлы удалены")

            # Сохраняем информацию о версии
            version_file = os.path.join(version_path, "version.txt")
            with open(version_file, 'w') as f:
                f.write(version)

            self.progress_bar.setVisible(False)
            self.check_installation()
            self.on_version_selected()

            logger.info(f"Установка версии {version} завершена успешно")
            QMessageBox.information(self, "Успех",
                                    f"Версия {version} успешно установлена!")

        except Exception as e:
            error_msg = str(e)
            logger.error(f"ОШИБКА РАСПАКОВКИ: {error_msg}")
            self.progress_bar.setVisible(False)
            self.install_btn.setEnabled(True)
            self.status_label.setText("● Ошибка")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #d13438;
                background-color: #fde7e9;
                padding: 6px 14px;
                border-radius: 12px;
            """)
            QMessageBox.critical(self, "Ошибка распаковки",
                                 f"{error_msg}\n\nПроверьте файл launcher_debug.log для деталей.")

    def download_error(self, error_msg):
        """Обработка ошибки скачивания"""
        logger.error(f"ОШИБКА СКАЧИВАНИЯ: {error_msg}")
        self.progress_bar.setVisible(False)
        self.install_btn.setEnabled(True)
        self.status_label.setText("● Ошибка")
        self.status_label.setStyleSheet("""
            font-size: 13px;
            color: #d13438;
            background-color: #fde7e9;
            padding: 6px 14px;
            border-radius: 12px;
        """)
        QMessageBox.critical(self, "Ошибка скачивания",
                             f"{error_msg}\n\nПроверьте файл launcher_debug.log для деталей.")

    def start_main_app(self):
        """Запуск основной программы"""
        if not self.current_version_path:
            QMessageBox.warning(self, "Ошибка", "Программа не установлена")
            return

        logger.info(f"Запуск программы из {self.current_version_path}")
        self.statusBar().showMessage("Запуск программы...")

        if self.main_process.start_app(self.current_version_path):
            self.start_btn.setEnabled(False)
            self.start_btn.setText("⏳ Запущена...")
            self.status_label.setText("● Запущена")
            self.status_label.setStyleSheet("""
                font-size: 13px;
                color: #0078d4;
                background-color: #e6f2ff;
                padding: 6px 14px;
                border-radius: 12px;
            """)
            self.statusBar().showMessage("Программа запущена")

    def uninstall_version(self):
        """Удаление выбранной версии"""
        if not self.selected_version:
            return

        version = self.selected_version['version']
        version_path = os.path.join(self.install_base_path, f"v{version}")

        # Проверяем, не запущена ли программа
        if self.main_process.state() == QProcess.Running:
            QMessageBox.warning(self, "Ошибка", "Программа запущена. Закройте её перед удалением.")
            return

        reply = QMessageBox.question(self, "Удаление версии",
                                     f"Вы уверены, что хотите удалить версию {version}?\n"
                                     f"Папка: {version_path}",
                                     QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:
            try:
                if os.path.exists(version_path):
                    shutil.rmtree(version_path)
                    logger.info(f"Версия {version} удалена из: {version_path}")

                self.check_installation()
                self.on_version_selected()
                self.statusBar().showMessage(f"Версия {version} удалена")
                QMessageBox.information(self, "Успех", f"Версия {version} успешно удалена!")

            except Exception as e:
                logger.error(f"Ошибка удаления: {str(e)}")
                QMessageBox.critical(self, "Ошибка", f"Не удалось удалить версию:\n{str(e)}")

    def update_ui_state(self):
        """Обновление состояния UI после закрытия программы"""
        self.start_btn.setEnabled(True)
        self.start_btn.setText("▶ Запустить")
        self.check_installation()
        self.statusBar().showMessage("Программа завершена")

    def closeEvent(self, event):
        """Обработка закрытия лаунчера"""
        logger.info("Закрытие лаунчера...")
        if self.main_process.state() == QProcess.Running:
            self.main_process.terminate()
            self.main_process.waitForFinished(3000)
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    # Устанавливаем иконку приложения
    try:
        app.setWindowIcon(QIcon("icon.ico"))
    except:
        pass

    launcher = ModernLauncher()
    launcher.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()