// ================================================================
//  JAVASCRIPT – полная версия с вкладками и контекстным меню
// ================================================================

if (typeof io === 'undefined') {
    document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;color:#ff4757;font-size:18px;">Ошибка загрузки Socket.IO</div>';
    throw new Error('Socket.IO not loaded');
}

const socket = io();

// ============ TABS ============
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById(this.dataset.tab).classList.add('active');
    });
});

// ============ BAN LIST ============
let banWordList = [];
let suppressSave = false;

function updateBanList(silent = false) {
    const input = document.getElementById('banWords');
    if (!input) return;
    const newList = input.value.split(',').map(w => w.trim().toLowerCase()).filter(w => w.length > 0);
    if (JSON.stringify(newList) === JSON.stringify(banWordList)) return;
    banWordList = newList;
    localStorage.setItem('banWords', input.value);
    recensorAllMessages();
    if (!silent) {
        saveTTSSettings({ ban_words: input.value });
    }
}

function censorText(text) {
    let censored = text;
    let hasCensored = false;
    banWordList.forEach(word => {
        const regex = new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
        if (regex.test(censored)) {
            censored = censored.replace(regex, match => '★'.repeat(match.length));
            hasCensored = true;
        }
    });
    return { text: censored, hasCensored };
}

function recensorAllMessages() {
    allMessages.forEach(msg => {
        const result = censorText(msg.message);
        msg.message = result.text;
        const textNode = msg.el.querySelector('.chat-text');
        if (textNode) {
            textNode.textContent = result.text;
        }
        msg.el.classList.toggle('censored', result.hasCensored);
    });
    filterMessages();
}

function onBanWordsChange() {
    updateBanList(false);
}

// ============ AVATARS ============
const avatarCache = {};
async function loadAvatar(username) {
    if (avatarCache[username]) return avatarCache[username];
    try {
        const resp = await fetch(`/api/avatar/${encodeURIComponent(username)}`);
        if (resp.ok) {
            const data = await resp.json();
            if (data.url) {
                avatarCache[username] = data.url;
                return data.url;
            }
        }
    } catch (e) {
        console.warn('Ошибка загрузки аватара для', username, e);
    }
    return null;
}

// ============ BADGES ============
function renderBadges(badges) {
    if (!badges || badges.length === 0) return '';
    let html = '';
    badges.forEach(b => {
        const src = `https://static-cdn.jtvnw.net/badges/v1/${b.name}/${b.version}`;
        html += `<img class="chat-badge" src="${src}" alt="${b.name}" title="${b.name}" />`;
    });
    return html;
}

// ============ TTS FUNCTIONS ============
function toggleTTSUserFields(allUsers) {
    const usersGroup = document.getElementById('ttsUsersGroup');
    const excludeGroup = document.getElementById('ttsExcludeGroup');
    if (allUsers) {
        if (usersGroup) usersGroup.style.display = 'none';
        if (excludeGroup) excludeGroup.style.display = 'block';
    } else {
        if (usersGroup) usersGroup.style.display = 'block';
        if (excludeGroup) excludeGroup.style.display = 'none';
    }
}

async function loadVoices(engine) {
    try {
        const resp = await fetch(`/api/tts/voices?engine=${encodeURIComponent(engine)}`);
        const data = await resp.json();
        const select = document.getElementById('ttsVoice');
        if (!select) return;
        select.innerHTML = '<option value="">По умолчанию</option>';
        if (data.voices) {
            data.voices.forEach(voice => {
                const opt = document.createElement('option');
                opt.value = voice;
                opt.textContent = voice;
                select.appendChild(opt);
            });
        }
    } catch (e) {
        console.warn('Не удалось загрузить голоса:', e);
    }
}

function updateTTSSlider(type) {
    const volEl = document.getElementById('volumeValue');
    const rateEl = document.getElementById('rateValue');
    if (volEl) volEl.textContent = document.getElementById('ttsVolume').value + '%';
    if (rateEl) rateEl.textContent = document.getElementById('ttsRate').value + ' wpm';
    saveTTSSettings();
}

async function saveTTSSettings(extra = {}) {
    if (saveTTSSettings._pending) return;
    saveTTSSettings._pending = true;
    const payload = {
        enabled: document.getElementById('ttsEnabled').checked,
        users: document.getElementById('ttsUsers').value,
        exclude_users: document.getElementById('ttsExcludeUsers').value,
        all_users: document.getElementById('ttsAllUsers').checked,
        volume: parseInt(document.getElementById('ttsVolume').value),
        rate: parseInt(document.getElementById('ttsRate').value),
        engine: document.getElementById('ttsEngine').value,
        voice: document.getElementById('ttsVoice').value,
        ...extra
    };
    console.log('[TTS] Сохраняем настройки:', payload);
    try {
        const resp = await fetch('/api/tts/config', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await resp.json();
        console.log('[TTS] Ответ сервера:', data);
    } catch (e) {
        console.error('[TTS] Ошибка сохранения:', e);
    } finally {
        saveTTSSettings._pending = false;
    }
}
saveTTSSettings._pending = false;

async function testTTS() {
    try {
        const resp = await fetch('/api/tts/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                text: 'Привет! Это тест синтеза речи.',
                engine: document.getElementById('ttsEngine').value,
                volume: parseInt(document.getElementById('ttsVolume').value),
                rate: parseInt(document.getElementById('ttsRate').value),
                voice: document.getElementById('ttsVoice').value
            })
        });
        const data = await resp.json();
        showToast(data.message || 'Тест запущен');
    } catch (e) {
        showToast('Ошибка TTS');
    }
}

async function stopTTS() {
    await fetch('/api/tts/stop', { method: 'POST' });
    showToast('Озвучка остановлена');
}

async function loadTTSEngines() {
    try {
        const resp = await fetch('/api/tts/engines');
        const engines = await resp.json();
        const select = document.getElementById('ttsEngine');
        if (!select) return;
        select.innerHTML = '<option value="auto">Авто</option>';
        for (const [name, info] of Object.entries(engines)) {
            if (info.available) {
                const option = document.createElement('option');
                option.value = name;
                option.textContent = name + ' ✅';
                select.appendChild(option);
            }
        }
        select.value = localStorage.getItem('ttsEngine') || 'auto';
    } catch (e) {
        console.error('Load engines error:', e);
    }
}

async function loadTTSSettings() {
    try {
        const resp = await fetch('/api/tts/config');
        const cfg = await resp.json();
        const usersInput = document.getElementById('ttsUsers');
        const volumeInput = document.getElementById('ttsVolume');
        const rateInput = document.getElementById('ttsRate');
        const volumeLabel = document.getElementById('volumeValue');
        const rateLabel = document.getElementById('rateValue');
        const engineStatus = document.getElementById('engineStatus');
        const banWordsInput = document.getElementById('banWords');
        const allUsersCheck = document.getElementById('ttsAllUsers');
        const excludeInput = document.getElementById('ttsExcludeUsers');
        const voiceSelect = document.getElementById('ttsVoice');
        const enabledCheck = document.getElementById('ttsEnabled');

        if (enabledCheck) {
            enabledCheck.checked = cfg.enabled !== undefined ? cfg.enabled : true;
        }
        if (usersInput) usersInput.value = (cfg.users || []).join(',');
        if (excludeInput) excludeInput.value = (cfg.exclude_users || []).join(',');
        if (allUsersCheck) {
            allUsersCheck.checked = cfg.all_users || false;
            toggleTTSUserFields(allUsersCheck.checked);
        }
        if (volumeInput) volumeInput.value = cfg.volume || 80;
        if (rateInput) rateInput.value = cfg.rate || 160;
        if (volumeLabel) volumeLabel.textContent = (cfg.volume || 80) + '%';
        if (rateLabel) rateLabel.textContent = (cfg.rate || 160) + ' wpm';
        if (engineStatus && cfg.engine_status) {
            engineStatus.textContent = Object.entries(cfg.engine_status)
                .map(([n, a]) => n + ': ' + (a ? '✅' : '❌')).join(' | ');
        }
        if (cfg.ban_words && cfg.ban_words.length && banWordsInput) {
            banWordsInput.value = cfg.ban_words.join(', ');
            banWordList = cfg.ban_words.map(w => w.toLowerCase());
            recensorAllMessages();
        }
        await loadVoices(cfg.engine || 'auto');
        if (voiceSelect && cfg.voice) {
            voiceSelect.value = cfg.voice;
        }
    } catch (e) {
        console.error('Load TTS settings error:', e);
    }
}

// ============ GLOBAL STATE ============
const allMessages = [];
const nicknameInput = document.getElementById('nickname');
const ttlInput = document.getElementById('ttl');
const cssInput = document.getElementById('css');
const logToggle = document.getElementById('logToggle');
const showViewersToggle = document.getElementById('showViewersToggle');
const showAvatarsToggle = document.getElementById('showAvatars');
const hideLinksCheck = document.getElementById('hideLinks');
let showAvatars = true;
let hideLinks = false;

// ===== НАСТРОЙКИ ВНЕШНЕГО ВИДА =====
let usernameColorMode = 'twitch';
let usernameFixedColor = '#7c5cfc';
let avatarSize = 28;
let messageBgColor = '#111118';

const toggleBtn = document.getElementById('toggleBtn');
const btnIcon = document.getElementById('btnIcon');
const btnText = document.getElementById('btnText');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const chatContainer = document.getElementById('chatContainer');
const msgCount = document.getElementById('msgCount');
const uptimeEl = document.getElementById('uptime');
const viewersCountEl = document.getElementById('viewersCount');
const viewersStatEl = document.getElementById('viewersStat');
const copyBtn = document.getElementById('copyBtn');
const searchInput = document.getElementById('searchInput');
const searchCount = document.getElementById('searchCount');
let isRunning = false;
let messageCounter = 0;
let startTime = null;
let uptimeInterval = null;
let isNearBottom = true;

// ============ FILTERS ============
function refreshMessagesByLinkSetting() {
    const hide = hideLinksCheck ? hideLinksCheck.checked : false;
    allMessages.forEach(msg => {
        const textSpan = msg.el.querySelector('.chat-text');
        if (!textSpan) return;
        if (hide && msg.hasLink) {
            const newText = 'ссылка удалена';
            const censored = censorText(newText);
            textSpan.textContent = censored.text;
            msg.message = censored.text;
        } else if (!hide && msg.hasLink) {
            const original = msg.originalMessage;
            const censored = censorText(original);
            textSpan.textContent = censored.text;
            msg.message = censored.text;
        }
    });
    filterMessages();
}

function filterMessages() {
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    let visibleCount = 0;
    allMessages.forEach(msg => {
        let show = true;
        if (query && !(msg.username + ' ' + msg.message).toLowerCase().includes(query)) show = false;
        msg.el.classList.toggle('hidden', !show);
        if (show) {
            visibleCount++;
            if (query) highlightText(msg.el, query);
            else removeHighlight(msg.el);
        } else removeHighlight(msg.el);
    });
    if (searchCount) searchCount.textContent = query ? `Найдено: ${visibleCount}` : '';
}

function highlightText(el, query) {
    removeHighlight(el);
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
        const text = node.textContent;
        const lower = text.toLowerCase();
        if (lower.includes(query)) {
            const span = document.createElement('span');
            const idx = lower.indexOf(query);
            span.textContent = text.substring(0, idx);
            const mark = document.createElement('mark');
            mark.className = 'search-highlight';
            mark.textContent = text.substring(idx, idx + query.length);
            span.appendChild(mark);
            span.appendChild(document.createTextNode(text.substring(idx + query.length)));
            node.parentNode.replaceChild(span, node);
        }
    });
}

function removeHighlight(el) {
    el.querySelectorAll('.search-highlight').forEach(mark => {
        const parent = mark.parentNode;
        parent.replaceChild(document.createTextNode(mark.textContent), mark);
        parent.normalize();
    });
}

// ============ ЦВЕТ НИКА ============
function getRandomColorFromUsername(username) {
    let hash = 0;
    for (let i = 0; i < username.length; i++) {
        hash = username.charCodeAt(i) + ((hash << 5) - hash);
        hash = hash & hash;
    }
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue}, 70%, 55%)`;
}

function applyUsernameColor(msgEl, username) {
    const userSpan = msgEl.querySelector('.chat-username');
    if (!userSpan) return;
    let color;
    if (usernameColorMode === 'twitch') {
        // Используем оригинальный цвет, сохранённый при создании
        color = msgEl.dataset.originalColor || '#eaeaf0';
    } else if (usernameColorMode === 'fixed') {
        color = usernameFixedColor;
    } else { // random
        color = getRandomColorFromUsername(username);
    }
    userSpan.style.color = color;
}

function applyUsernameColorToAll() {
    allMessages.forEach(msg => applyUsernameColor(msg.el, msg.username));
}

// ============ РАЗМЕР АВАТАРА ============
function applyAvatarSize(msgEl) {
    const avatar = msgEl.querySelector('.chat-avatar');
    if (avatar) {
        avatar.style.width = avatarSize + 'px';
        avatar.style.height = avatarSize + 'px';
    }
}

function applyAvatarSizeToAll() {
    allMessages.forEach(msg => applyAvatarSize(msg.el));
}

// ============ ЦВЕТ ФОНА СООБЩЕНИЯ ============
function applyMessageBgColor(msgEl) {
    // Устанавливаем цвет фона с прозрачностью 30%
    const bg = hexToRgba(messageBgColor, 0.3);
    msgEl.style.backgroundColor = bg;
}

function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1,3), 16);
    const g = parseInt(hex.slice(3,5), 16);
    const b = parseInt(hex.slice(5,7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function applyMessageBgColorToAll() {
    allMessages.forEach(msg => applyMessageBgColor(msg.el));
}

// ============ ИНИЦИАЛИЗАЦИЯ ВКЛАДКИ "ЧАТ" ============
function initChatTabHandler() {
    const chatTab = document.querySelector('.tabs-container .tab[data-tab="main"]');
    if (chatTab) {
        chatTab.onclick = function() {
            switchToTab('main');
        };
        console.log('✅ Обработчик для вкладки "Чат" установлен');
    } else {
        console.warn('⚠️ Вкладка "Чат" не найдена');
    }
}

// ============ INIT ============
async function init() {
    initBanList();
    await loadTTSEngines();
    await loadTTSSettings();
    await loadAnimationSettings();
    setupAnimationSliders();

    initChatTabHandler();

    try {
        const cfg = await fetch('/api/config').then(r => r.json());
        if (nicknameInput) nicknameInput.value = cfg.nickname || '';
        if (ttlInput) ttlInput.value = cfg.ttl || 0;
        if (cssInput) cssInput.value = cfg.css || '';
        if (logToggle) logToggle.checked = cfg.log_messages || false;
        if (showViewersToggle) showViewersToggle.checked = cfg.show_viewers_in_overlay || false;
        showAvatars = cfg.show_avatars !== undefined ? cfg.show_avatars : true;
        if (showAvatarsToggle) showAvatarsToggle.checked = showAvatars;
        if (hideLinksCheck) {
            hideLinksCheck.checked = cfg.hide_links || false;
            hideLinks = hideLinksCheck.checked;
        }

        // ===== ЗАГРУЗКА НАСТРОЕК ВНЕШНЕГО ВИДА =====
        usernameColorMode = cfg.username_color_mode || 'twitch';
        usernameFixedColor = cfg.username_fixed_color || '#7c5cfc';
        avatarSize = cfg.avatar_size || 28;
        messageBgColor = cfg.message_bg_color || '#111118';

        // Установка значений в UI
        const colorModeSelect = document.getElementById('usernameColorMode');
        const fixedColorInput = document.getElementById('usernameFixedColor');
        const avatarSizeSlider = document.getElementById('avatarSize');
        const avatarSizeLabel = document.getElementById('avatarSizeLabel');
        const messageBgColorInput = document.getElementById('messageBgColor');
        const fixedColorGroup = document.getElementById('fixedColorGroup');

        if (colorModeSelect) colorModeSelect.value = usernameColorMode;
        if (fixedColorInput) fixedColorInput.value = usernameFixedColor;
        if (avatarSizeSlider) {
            avatarSizeSlider.value = avatarSize;
            if (avatarSizeLabel) avatarSizeLabel.textContent = avatarSize;
        }
        if (messageBgColorInput) messageBgColorInput.value = messageBgColor;
        if (fixedColorGroup) {
            fixedColorGroup.style.display = (usernameColorMode === 'fixed') ? 'block' : 'none';
        }

        // ===== ПРИМЕНЯЕМ НАСТРОЙКИ К СУЩЕСТВУЮЩИМ СООБЩЕНИЯМ =====
        // (после загрузки истории)

        const status = await fetch('/api/status').then(r => r.json());
        updateUI(status.running);
        if (status.start_time) {
            startTime = new Date(status.start_time);
            updateUptime();
            uptimeInterval = setInterval(updateUptime, 1000);
        }
        messageCounter = status.message_count || 0;
        if (msgCount) msgCount.textContent = messageCounter;
        if (viewersCountEl) viewersCountEl.textContent = status.viewers || 0;
        if (viewersStatEl) viewersStatEl.textContent = status.viewers || 0;

        const historyResp = await fetch('/api/messages').then(r => r.json());
        if (historyResp.messages && historyResp.messages.length > 0 && chatContainer) {
            const empty = chatContainer.querySelector('.empty-state');
            if (empty) empty.remove();
            historyResp.messages.forEach(msg => addMessageToDOM(msg, false));
            // После добавления всех сообщений применяем настройки внешнего вида
            applyUsernameColorToAll();
            applyAvatarSizeToAll();
            applyMessageBgColorToAll();
            chatContainer.scrollTop = chatContainer.scrollHeight;
            if (historyResp.start_time) startTime = new Date(historyResp.start_time);
        }
        refreshMessagesByLinkSetting();
    } catch (e) {
        console.error('Init error:', e);
    }

    // ===== ОБРАБОТЧИКИ ИЗМЕНЕНИЙ ВНЕШНЕГО ВИДА =====
    const colorModeSelect = document.getElementById('usernameColorMode');
    if (colorModeSelect) {
        colorModeSelect.addEventListener('change', function() {
            usernameColorMode = this.value;
            const group = document.getElementById('fixedColorGroup');
            if (group) group.style.display = (usernameColorMode === 'fixed') ? 'block' : 'none';
            updateConfig();
            applyUsernameColorToAll();
        });
    }

    const fixedColorInput = document.getElementById('usernameFixedColor');
    if (fixedColorInput) {
        fixedColorInput.addEventListener('input', function() {
            usernameFixedColor = this.value;
            updateConfig();
            applyUsernameColorToAll();
        });
    }

    const avatarSizeSlider = document.getElementById('avatarSize');
    if (avatarSizeSlider) {
        avatarSizeSlider.addEventListener('input', function() {
            avatarSize = parseInt(this.value);
            const label = document.getElementById('avatarSizeLabel');
            if (label) label.textContent = avatarSize;
            updateConfig();
            applyAvatarSizeToAll();
        });
    }

    const messageBgColorInput = document.getElementById('messageBgColor');
    if (messageBgColorInput) {
        messageBgColorInput.addEventListener('input', function() {
            messageBgColor = this.value;
            updateConfig();
            applyMessageBgColorToAll();
        });
    }

    // ===== ОСТАЛЬНЫЕ ОБРАБОТЧИКИ =====
    if (showAvatarsToggle) {
        showAvatarsToggle.addEventListener('change', function() {
            showAvatars = this.checked;
            updateConfig();
            allMessages.forEach(msg => {
                const avatar = msg.el.querySelector('.chat-avatar');
                if (avatar) {
                    if (showAvatars) {
                        avatar.style.display = '';
                        if (!avatar.src || avatar.src.includes('data:image')) {
                            loadAvatar(msg.username).then(url => {
                                if (url) avatar.src = url;
                                else avatar.style.display = 'none';
                            });
                        }
                    } else {
                        avatar.style.display = 'none';
                    }
                }
            });
        });
    }

    if (hideLinksCheck) {
        hideLinksCheck.addEventListener('change', function() {
            hideLinks = this.checked;
            updateConfig();
            refreshMessagesByLinkSetting();
        });
    }

    if (chatContainer) {
        chatContainer.addEventListener('scroll', () => {
            isNearBottom = chatContainer.scrollHeight - chatContainer.scrollTop - chatContainer.clientHeight < 60;
            updateScrollButton();
        });
    }

    const allUsersCheck = document.getElementById('ttsAllUsers');
    if (allUsersCheck) {
        allUsersCheck.addEventListener('change', function() {
            toggleTTSUserFields(this.checked);
            saveTTSSettings();
        });
    }
    const engineSelect = document.getElementById('ttsEngine');
    if (engineSelect) {
        engineSelect.addEventListener('change', function() {
            loadVoices(this.value);
            saveTTSSettings();
        });
    }
    const voiceSelect = document.getElementById('ttsVoice');
    if (voiceSelect) {
        voiceSelect.addEventListener('change', saveTTSSettings);
    }
    const ttsEnabledCheck = document.getElementById('ttsEnabled');
    if (ttsEnabledCheck) {
        ttsEnabledCheck.addEventListener('change', function() {
            saveTTSSettings();
        });
    }
}

function initBanList() {
    const saved = localStorage.getItem('banWords');
    if (saved) {
        const input = document.getElementById('banWords');
        if (input) input.value = saved;
        updateBanList(true);
    }
}

function updateUI(running) {
    isRunning = running;
    if (toggleBtn) toggleBtn.classList.toggle('running', running);
    if (btnIcon) btnIcon.innerHTML = running ? '<i class="fas fa-stop"></i>' : '<i class="fas fa-play"></i>';
    if (btnText) btnText.textContent = running ? 'Остановить парсер' : 'Запустить парсер';
    if (statusDot) statusDot.classList.toggle('active', running);
    if (statusText) statusText.textContent = running ? 'Парсер активен' : 'Готов к работе';
    if (running) {
        if (!startTime) { startTime = new Date(); updateUptime(); uptimeInterval = setInterval(updateUptime, 1000); }
    } else {
        startTime = null;
        if (uptimeInterval) { clearInterval(uptimeInterval); uptimeInterval = null; }
        if (uptimeEl) uptimeEl.textContent = '00:00';
    }
}

async function loadAnimationSettings() {
    try {
        const resp = await fetch('/api/animation/config');
        if (!resp.ok) throw new Error('Animation API error');
        const data = await resp.json();

        const entrySelect = document.getElementById('animEntry');
        const exitSelect = document.getElementById('animExit');
        const speedSlider = document.getElementById('animSpeed');
        const delaySlider = document.getElementById('animDelay');
        const speedLabel = document.getElementById('animSpeedLabel');
        const delayLabel = document.getElementById('animDelayLabel');

        if (entrySelect) entrySelect.value = data.entry || 'fade';
        if (exitSelect) exitSelect.value = data.exit || 'fade';
        if (speedSlider) {
            speedSlider.value = data.speed || 300;
            if (speedLabel) speedLabel.textContent = data.speed || 300;
        }
        if (delaySlider) {
            delaySlider.value = data.delay || 0;
            if (delayLabel) delayLabel.textContent = data.delay || 0;
        }

        return data;
    } catch (e) {
        console.error('Load animation settings error:', e);
        return null;
    }
}

async function saveAnimationSettings() {
    const entry = document.getElementById('animEntry')?.value || 'fade';
    const exit = document.getElementById('animExit')?.value || 'fade';
    const speed = parseInt(document.getElementById('animSpeed')?.value || 300);
    const delay = parseInt(document.getElementById('animDelay')?.value || 0);

    const payload = { entry, exit, speed, delay };

    try {
        const resp = await fetch('/api/animation/config', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!resp.ok) throw new Error('Save animation error');
        showToast('Настройки анимации сохранены');
    } catch (e) {
        console.error('Save animation error:', e);
        showToast('Ошибка сохранения настроек');
    }
}

function setupAnimationSliders() {
    const speedSlider = document.getElementById('animSpeed');
    const delaySlider = document.getElementById('animDelay');
    const speedLabel = document.getElementById('animSpeedLabel');
    const delayLabel = document.getElementById('animDelayLabel');

    if (speedSlider && speedLabel) {
        speedSlider.addEventListener('input', () => {
            speedLabel.textContent = speedSlider.value;
        });
        speedSlider.addEventListener('change', saveAnimationSettings);
    }

    if (delaySlider && delayLabel) {
        delaySlider.addEventListener('input', () => {
            delayLabel.textContent = delaySlider.value;
        });
        delaySlider.addEventListener('change', saveAnimationSettings);
    }

    const entrySelect = document.getElementById('animEntry');
    const exitSelect = document.getElementById('animExit');

    if (entrySelect) entrySelect.addEventListener('change', saveAnimationSettings);
    if (exitSelect) exitSelect.addEventListener('change', saveAnimationSettings);
}

function previewAnimation() {
    const entry = document.getElementById('animEntry')?.value || 'fade';
    const speed = parseInt(document.getElementById('animSpeed')?.value || 300);

    const container = document.getElementById('chatContainer');
    if (!container) return;

    const empty = container.querySelector('.empty-state');
    if (empty) empty.remove();

    const msgEl = document.createElement('div');
    msgEl.className = 'chat-msg';
    msgEl.style.setProperty('--anim-speed', (speed / 1000) + 's');
    msgEl.classList.add('anim-' + entry);

    const username = document.createElement('span');
    username.className = 'chat-username';
    username.style.color = '#7c5cfc';
    username.textContent = 'Тестовый_пользователь';

    const text = document.createElement('span');
    text.textContent = ' → Привет! Это тестовое сообщение для предпросмотра анимации.';

    msgEl.appendChild(username);
    msgEl.appendChild(document.createTextNode(': '));
    msgEl.appendChild(text);

    container.appendChild(msgEl);
    container.scrollTop = container.scrollHeight;

    setTimeout(() => {
        const exitEffect = document.getElementById('animExit')?.value || 'fade';
        msgEl.classList.remove('anim-' + entry);
        msgEl.classList.add('exit-' + exitEffect);
        msgEl.classList.add('removing');

        setTimeout(() => {
            if (msgEl.parentNode) {
                msgEl.remove();
                if (container.children.length === 0) {
                    container.innerHTML = `
                        <div class="empty-state">
                            <div class="icon"><i class="fas fa-comment-dots"></i></div>
                            <div class="title">Чат пока пуст</div>
                            <div class="desc">Запустите парсер, указав имя канала Twitch</div>
                        </div>
                    `;
                }
            }
        }, speed + 100);
    }, 3000);

    showToast(`Предпросмотр: ${entry}`);
}

function updateUptime() {
    if (!startTime || !uptimeEl) return;
    const diff = Math.floor((Date.now() - startTime.getTime()) / 1000);
    const h = Math.floor(diff / 3600);
    const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
    const s = (diff % 60).toString().padStart(2, '0');
    uptimeEl.textContent = h > 0 ? `${h}:${m}:${s}` : `${m}:${s}`;
}

function updateScrollButton() {
    const btn = document.getElementById('scrollBottomBtn');
    if (btn) btn.classList.toggle('visible', !isNearBottom && allMessages.length > 5);
}

function scrollToBottom() {
    if (chatContainer) {
        chatContainer.scrollTop = chatContainer.scrollHeight;
        isNearBottom = true;
        updateScrollButton();
    }
}

function showToast(message) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => toast.classList.remove('show'), 2000);
}

function copyOverlayURL() {
    const url = window.location.origin + '/overlay';
    const ta = document.createElement('textarea');
    ta.value = url;
    ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta);
    ta.select();
    try {
        document.execCommand('copy');
        if (copyBtn) {
            copyBtn.classList.add('success');
            copyBtn.innerHTML = '<i class="fas fa-check-circle"></i> Скопировано!';
        }
        showToast('URL скопирован');
        setTimeout(() => {
            if (copyBtn) {
                copyBtn.classList.remove('success');
                copyBtn.innerHTML = '<i class="fas fa-copy"></i> Копировать URL';
            }
        }, 2000);
    } catch (e) {
        prompt('Скопируйте вручную:', url);
    }
    document.body.removeChild(ta);
}

async function toggleParser() {
    if (isRunning) {
        await fetch('/api/stop', { method: 'POST' });
        updateUI(false);
    } else {
        const nickname = nicknameInput ? nicknameInput.value.trim() : '';
        if (!nickname) { alert('Введите имя канала'); return; }
        const resp = await fetch('/api/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                nickname,
                ttl: parseInt(ttlInput ? ttlInput.value : 0) || 0,
                css: cssInput ? cssInput.value : '',
                log_messages: logToggle ? logToggle.checked : false,
                show_viewers_in_overlay: showViewersToggle ? showViewersToggle.checked : false,
                show_avatars: showAvatars,
                hide_links: hideLinksCheck ? hideLinksCheck.checked : false,
                username_color_mode: usernameColorMode,
                username_fixed_color: usernameFixedColor,
                avatar_size: avatarSize,
                message_bg_color: messageBgColor
            })
        });
        if (resp.ok) {
            updateUI(true);
            if (chatContainer) {
                chatContainer.innerHTML = `<div class="empty-state"><div class="icon"><i class="fas fa-hourglass-half"></i></div><div class="title">Ожидание сообщений...</div><div class="desc">Подключение к чату <strong>${nickname}</strong></div></div>`;
            }
            allMessages.length = 0;
            messageCounter = 0;
            if (msgCount) msgCount.textContent = '0';
        }
    }
}

async function updateConfig() {
    const payload = {
        ttl: parseInt(ttlInput ? ttlInput.value : 0) || 0,
        css: cssInput ? cssInput.value : '',
        log_messages: logToggle ? logToggle.checked : false,
        show_viewers_in_overlay: showViewersToggle ? showViewersToggle.checked : false,
        show_avatars: showAvatars,
        hide_links: hideLinksCheck ? hideLinksCheck.checked : false,
        username_color_mode: usernameColorMode,
        username_fixed_color: usernameFixedColor,
        avatar_size: avatarSize,
        message_bg_color: messageBgColor
    };
    await fetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
}

async function clearMessages() {
    await fetch('/api/clear', { method: 'POST' });
    if (chatContainer) {
        chatContainer.innerHTML = `<div class="empty-state"><div class="icon"><i class="fas fa-comment-dots"></i></div><div class="title">Чат очищен</div><div class="desc">Новые сообщения появятся здесь</div></div>`;
    }
    allMessages.length = 0;
    messageCounter = 0;
    if (msgCount) msgCount.textContent = '0';
    if (searchCount) searchCount.textContent = '';
}

// ============ ДОБАВЛЕНИЕ СООБЩЕНИЯ В DOM ============
function addMessageToDOM(data, animate = true) {
    if (!chatContainer) return;

    const hide = hideLinksCheck ? hideLinksCheck.checked : false;
    const hasLink = /https?:\/\/|ftp:\/\/|t\.me\/|discord\.(com|gg)/i.test(data.message);
    let displayMessage = data.message;
    let originalMessage = data.message;
    if (hide && hasLink) {
        displayMessage = 'ссылка удалена';
    }

    const empty = chatContainer.querySelector('.empty-state');
    if (empty) empty.remove();

    const msgEl = document.createElement('div');
    msgEl.className = 'chat-msg';
    if (!animate) msgEl.style.animation = 'none';

    const censored = censorText(displayMessage);
    const finalMessage = censored.text;

    // ---- АВАТАР ----
    const avatarImg = document.createElement('img');
    avatarImg.className = 'chat-avatar';
    avatarImg.alt = data.username;
    if (showAvatars) {
        loadAvatar(data.username).then(url => {
            if (url) avatarImg.src = url;
            else avatarImg.style.display = 'none';
        });
        avatarImg.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"%3E%3Ccircle cx="16" cy="16" r="16" fill="%23333"/%3E%3Ctext x="16" y="20" text-anchor="middle" fill="%23999" font-size="14" font-family="sans-serif"%3E?%3C/text%3E%3C/svg%3E';
    } else {
        avatarImg.style.display = 'none';
    }
    // Применяем размер аватара
    avatarImg.style.width = avatarSize + 'px';
    avatarImg.style.height = avatarSize + 'px';

    // ---- БАДЖИ ----
    const badgesHtml = renderBadges(data.badges || []);
    const badgesSpan = document.createElement('span');
    badgesSpan.className = 'chat-badges';
    badgesSpan.innerHTML = badgesHtml;

    // ---- ИМЯ ----
    const userSpan = document.createElement('span');
    userSpan.className = 'chat-username';
    // Сохраняем оригинальный цвет от Twitch
    const originalColor = data.color || '#eaeaf0';
    msgEl.dataset.originalColor = originalColor;
    // Применяем цвет в соответствии с настройками
    userSpan.style.color = originalColor; // временно, потом перекрасим
    userSpan.textContent = data.username;
    userSpan.dataset.username = data.username;

    // ---- ТЕКСТ ----
    const textSpan = document.createElement('span');
    textSpan.className = 'chat-text';
    textSpan.textContent = finalMessage;

    // ---- ВРЕМЯ ----
    const timeSpan = document.createElement('span');
    timeSpan.className = 'chat-time';
    const ts = data.timestamp ? new Date(data.timestamp) : new Date();
    timeSpan.textContent = ts.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    // Собираем
    const userContainer = document.createElement('span');
    userContainer.className = 'chat-user-container';
    userContainer.appendChild(avatarImg);
    userContainer.appendChild(badgesSpan);
    userContainer.appendChild(userSpan);

    msgEl.appendChild(userContainer);
    msgEl.appendChild(document.createTextNode(': '));
    msgEl.appendChild(textSpan);
    msgEl.appendChild(timeSpan);

    if (censored.hasCensored) msgEl.classList.add('censored');

    // Применяем цвет фона
    applyMessageBgColor(msgEl);

    chatContainer.appendChild(msgEl);

    const msgObj = {
        username: data.username,
        originalMessage: originalMessage,
        message: finalMessage,
        color: data.color,
        timestamp: data.timestamp || new Date().toISOString(),
        el: msgEl,
        hasLink: hasLink
    };
    allMessages.push(msgObj);

    // Применяем цвет ника согласно настройкам
    applyUsernameColor(msgEl, data.username);

    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    if (query && !(data.username + ' ' + finalMessage).toLowerCase().includes(query)) msgEl.classList.add('hidden');
    else if (query) highlightText(msgEl, query);

    if (isNearBottom) chatContainer.scrollTop = chatContainer.scrollHeight;
    updateScrollButton();

    const ttl = parseInt(ttlInput ? ttlInput.value : 0) || 0;
    if (ttl > 0) setTimeout(() => {
        msgEl.style.opacity = '0';
        msgEl.style.transform = 'translateX(20px)';
        msgEl.style.transition = '0.3s';
        setTimeout(() => {
            if (msgEl.parentNode) {
                msgEl.remove();
                const idx = allMessages.indexOf(msgObj);
                if (idx > -1) allMessages.splice(idx, 1);
            }
        }, 300);
    }, ttl * 1000);
}

// ============ SOCKET EVENTS ============
socket.on('chat_message', data => {
    addMessageToDOM(data, true);
    messageCounter++;
    if (msgCount) msgCount.textContent = messageCounter;
});
socket.on('messages_clear', () => {
    if (chatContainer) {
        chatContainer.innerHTML = `<div class="empty-state"><div class="icon"><i class="fas fa-comment-dots"></i></div><div class="title">Чат очищен</div><div class="desc">Новые сообщения появятся здесь</div></div>`;
    }
    allMessages.length = 0;
    messageCounter = 0;
    if (msgCount) msgCount.textContent = '0';
    if (searchCount) searchCount.textContent = '';
});
socket.on('parser_status', data => {
    updateUI(data.running);
    startTime = data.start_time ? new Date(data.start_time) : null;
});
socket.on('config_update', data => {
    if (ttlInput) ttlInput.value = data.ttl || 0;
    if (cssInput) cssInput.value = data.css || '';
    if (logToggle) logToggle.checked = data.log_messages || false;
    if (showViewersToggle) showViewersToggle.checked = data.show_viewers_in_overlay || false;
    showAvatars = data.show_avatars !== undefined ? data.show_avatars : true;
    if (showAvatarsToggle) showAvatarsToggle.checked = showAvatars;
    if (hideLinksCheck) {
        hideLinksCheck.checked = data.hide_links || false;
        hideLinks = hideLinksCheck.checked;
        refreshMessagesByLinkSetting();
    }

    // Обновление настроек внешнего вида
    if (data.username_color_mode !== undefined) {
        usernameColorMode = data.username_color_mode;
        const select = document.getElementById('usernameColorMode');
        if (select) select.value = usernameColorMode;
        const group = document.getElementById('fixedColorGroup');
        if (group) group.style.display = (usernameColorMode === 'fixed') ? 'block' : 'none';
    }
    if (data.username_fixed_color !== undefined) {
        usernameFixedColor = data.username_fixed_color;
        const input = document.getElementById('usernameFixedColor');
        if (input) input.value = usernameFixedColor;
    }
    if (data.avatar_size !== undefined) {
        avatarSize = data.avatar_size;
        const slider = document.getElementById('avatarSize');
        if (slider) slider.value = avatarSize;
        const label = document.getElementById('avatarSizeLabel');
        if (label) label.textContent = avatarSize;
    }
    if (data.message_bg_color !== undefined) {
        messageBgColor = data.message_bg_color;
        const input = document.getElementById('messageBgColor');
        if (input) input.value = messageBgColor;
    }

    // Применяем изменения к сообщениям
    applyUsernameColorToAll();
    applyAvatarSizeToAll();
    applyMessageBgColorToAll();

    recensorAllMessages();
    allMessages.forEach(msg => {
        const avatar = msg.el.querySelector('.chat-avatar');
        if (avatar) {
            if (showAvatars) {
                avatar.style.display = '';
                if (!avatar.src || avatar.src.includes('data:image')) {
                    loadAvatar(msg.username).then(url => {
                        if (url) avatar.src = url;
                        else avatar.style.display = 'none';
                    });
                }
            } else {
                avatar.style.display = 'none';
            }
        }
    });
});
socket.on('tts_update', data => {
    console.log('[TTS] Получено обновление от сервера:', data);
    const usersInput = document.getElementById('ttsUsers');
    if (usersInput && data.users) usersInput.value = Array.isArray(data.users) ? data.users.join(',') : data.users;
    const excludeInput = document.getElementById('ttsExcludeUsers');
    if (excludeInput && data.exclude_users) excludeInput.value = Array.isArray(data.exclude_users) ? data.exclude_users.join(',') : data.exclude_users;
    const allUsersCheck = document.getElementById('ttsAllUsers');
    if (allUsersCheck && data.all_users !== undefined) {
        allUsersCheck.checked = data.all_users;
        toggleTTSUserFields(allUsersCheck.checked);
    }
    const volumeInput = document.getElementById('ttsVolume');
    const volumeLabel = document.getElementById('volumeValue');
    if (volumeInput && data.volume !== undefined) { volumeInput.value = data.volume; if (volumeLabel) volumeLabel.textContent = data.volume + '%'; }
    const rateInput = document.getElementById('ttsRate');
    const rateLabel = document.getElementById('rateValue');
    if (rateInput && data.rate !== undefined) { rateInput.value = data.rate; if (rateLabel) rateLabel.textContent = data.rate + ' wpm'; }
    if (data.ban_words) {
        const banInput = document.getElementById('banWords');
        if (banInput) banInput.value = data.ban_words.join(', ');
        updateBanList(true);
    }
    if (data.voice) {
        const voiceSelect = document.getElementById('ttsVoice');
        if (voiceSelect) voiceSelect.value = data.voice;
    }
    const enabledCheck = document.getElementById('ttsEnabled');
    if (enabledCheck && data.enabled !== undefined) {
        enabledCheck.checked = data.enabled;
    }
});
socket.on('viewers_update', data => {
    if (viewersCountEl) viewersCountEl.textContent = data.count;
    if (viewersStatEl) viewersStatEl.textContent = data.count;
});

// ============ BIND EVENTS ============
const banWordsInput = document.getElementById('banWords');
if (banWordsInput) banWordsInput.addEventListener('change', onBanWordsChange);
const ttsVolume = document.getElementById('ttsVolume');
if (ttsVolume) ttsVolume.addEventListener('input', () => updateTTSSlider('volume'));
const ttsRate = document.getElementById('ttsRate');
if (ttsRate) ttsRate.addEventListener('input', () => updateTTSSlider('rate'));
const ttsEngine = document.getElementById('ttsEngine');
if (ttsEngine) ttsEngine.addEventListener('change', saveTTSSettings);
const ttsUsers = document.getElementById('ttsUsers');
if (ttsUsers) ttsUsers.addEventListener('change', saveTTSSettings);
const ttsExclude = document.getElementById('ttsExcludeUsers');
if (ttsExclude) ttsExclude.addEventListener('change', saveTTSSettings);
if (logToggle) logToggle.addEventListener('change', updateConfig);
if (showViewersToggle) showViewersToggle.addEventListener('change', updateConfig);
if (ttlInput) ttlInput.addEventListener('change', updateConfig);
if (cssInput) cssInput.addEventListener('change', updateConfig);
if (searchInput) searchInput.addEventListener('input', filterMessages);

document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); toggleParser(); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); if (nicknameInput) { nicknameInput.focus(); nicknameInput.select(); } }
    if ((e.ctrlKey || e.metaKey) && e.key === 'f') { e.preventDefault(); if (searchInput) searchInput.focus(); }
});

// ============ КЛИК ПО НИКУ ДЛЯ ОТКРЫТИЯ КАНАЛА ============
if (chatContainer) {
    chatContainer.addEventListener('click', function(e) {
        const target = e.target.closest('.chat-username');
        if (target) {
            const username = target.dataset.username || target.textContent.trim();
            if (username) {
                fetch('/api/open_url', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ url: `https://twitch.tv/${username}` })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'ok') {
                        console.log(`Открыт канал: ${username}`);
                    } else {
                        console.error('Ошибка:', data.message);
                        window.open(`https://twitch.tv/${username}`, '_blank');
                    }
                })
                .catch(error => {
                    console.error('Ошибка запроса:', error);
                    window.open(`https://twitch.tv/${username}`, '_blank');
                });
            }
        }
    });
}

// ================================================================
//  ВКЛАДКИ И КОНТЕКСТНОЕ МЕНЮ
// ================================================================

console.log('🔵 Загрузка модуля вкладок');

let userTabs = {};
let currentTab = 'main';

function addUserTab(username) {
    console.log(`🟡 addUserTab вызван с: ${username}`);

    if (userTabs[username]) {
        console.log(`🟡 Вкладка для ${username} уже существует, переключаемся`);
        switchToTab(username);
        showToast(`Переключено на: ${username}`);
        return;
    }

    let tabsContainer = document.querySelector('.main-header .tabs-container');
    if (!tabsContainer) {
        console.log('🟡 Создание контейнера для вкладок');
        const mainHeader = document.querySelector('.main-header');
        if (!mainHeader) {
            console.error('❌ main-header не найден');
            return;
        }

        tabsContainer = document.createElement('div');
        tabsContainer.className = 'tabs-container';
        tabsContainer.style.cssText = `
            display: flex;
            align-items: center;
            gap: 4px;
            flex: 1;
            overflow-x: auto;
            padding: 4px 0;
        `;

        const chatTab = document.createElement('div');
        chatTab.className = 'tab active';
        chatTab.dataset.tab = 'main';
        chatTab.innerHTML = '<i class="fas fa-comment-dots"></i> Чат в реальном времени';
        chatTab.style.cssText = 'cursor: pointer; padding: 8px 16px; border-radius: 8px; background: var(--surface3); color: var(--text); border: 1px solid var(--border); font-size: 13px; font-weight: 600; white-space: nowrap;';
        chatTab.onclick = function() {
            console.log('🟡 Клик по вкладке "Чат"');
            switchToTab('main');
        };
        tabsContainer.appendChild(chatTab);

        const searchWrap = mainHeader.querySelector('.search-wrap');
        if (searchWrap) {
            mainHeader.insertBefore(tabsContainer, searchWrap);
            console.log('🟡 Контейнер вставлен перед поиском');
        } else {
            mainHeader.appendChild(tabsContainer);
            console.log('🟡 Контейнер добавлен в конец');
        }
    }

    console.log(`🟡 Создание вкладки для ${username}`);
    const tab = document.createElement('div');
    tab.className = 'tab';
    tab.dataset.tab = username;
    tab.dataset.username = username;
    tab.style.cssText = `
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: 6px;
        background: rgba(124, 92, 252, 0.1);
        border: 1px solid rgba(124, 92, 252, 0.2);
        font-size: 12px;
        white-space: nowrap;
        flex-shrink: 0;
        transition: all 0.2s;
        color: #eaeaf0;
    `;
    tab.innerHTML = `
        <i class="fas fa-user"></i> ${username}
        <span class="tab-close" style="
            cursor: pointer;
            opacity: 0.5;
            font-size: 14px;
            margin-left: 4px;
            padding: 0 4px;
        ">✕</span>
    `;

    tab.querySelector('.tab-close').addEventListener('click', function(e) {
        e.stopPropagation();
        console.log(`🟡 Закрытие вкладки: ${username}`);
        closeUserTab(username);
    });

    tab.onclick = function() {
        console.log(`🟡 Клик по вкладке: ${username}`);
        switchToTab(username);
    };

    tabsContainer.appendChild(tab);
    console.log(`🟡 Вкладка для ${username} добавлена в контейнер`);

    userTabs[username] = {
        tab: tab,
        container: null
    };

    const mainContent = document.querySelector('.main-content');
    if (!mainContent) {
        console.error('❌ main-content не найден');
        return;
    }

    console.log(`🟡 Создание контейнера для сообщений ${username}`);
    const userContainer = document.createElement('div');
    userContainer.className = 'user-chat-container';
    userContainer.dataset.username = username;
    userContainer.style.cssText = `
        display: none;
        height: 100%;
        overflow: hidden;
    `;
    userContainer.innerHTML = `
        <iframe src="/user/${username}" style="
            width: 100%;
            height: 100%;
            border: none;
            background: #09090f;
            border-radius: 8px;
        "></iframe>
    `;

    mainContent.appendChild(userContainer);
    userTabs[username].container = userContainer;
    console.log(`🟡 Контейнер для ${username} создан`);

    switchToTab(username);
    showToast(`Открыта вкладка: ${username}`);
    updateScrollButton();
    console.log(`✅ Вкладка для ${username} полностью создана`);
}

function switchToTab(tabId) {
    console.log(`🟡 switchToTab: ${tabId}`);
    currentTab = tabId;

    const tabs = document.querySelectorAll('.tabs-container .tab');
    console.log(`🟡 Найдено вкладок: ${tabs.length}`);

    tabs.forEach(t => {
        t.classList.remove('active');
        t.style.background = '';
        t.style.borderColor = '';
        if (t.dataset.tab === tabId) {
            t.classList.add('active');
            t.style.background = 'rgba(124, 92, 252, 0.3)';
            t.style.borderColor = '#7c5cfc';
            console.log(`🟡 Активирована вкладка: ${tabId}`);
        }
    });

    const mainContent = document.querySelector('.main-content');
    if (!mainContent) {
        console.error('❌ main-content не найден');
        return;
    }

    mainContent.querySelectorAll('.chat-container, .user-chat-container').forEach(el => {
        el.style.display = 'none';
        console.log(`🟡 Скрыт элемент: ${el.className}`);
    });

    if (tabId === 'main') {
        const chatContainerEl = document.getElementById('chatContainer');
        if (chatContainerEl) {
            chatContainerEl.style.display = 'flex';
            console.log('🟡 Показан главный чат');
        } else {
            console.warn('⚠️ chatContainer не найден');
        }
    } else {
        const userContainer = mainContent.querySelector(`.user-chat-container[data-username="${tabId}"]`);
        if (userContainer) {
            userContainer.style.display = 'block';
            console.log(`🟡 Показан чат пользователя: ${tabId}`);
        } else {
            console.warn(`⚠️ Контейнер для ${tabId} не найден`);
        }
    }
}

function closeUserTab(username) {
    console.log(`🟡 closeUserTab: ${username}`);
    if (!userTabs[username]) {
        console.warn(`⚠️ Вкладка ${username} не найдена`);
        return;
    }

    const tab = userTabs[username].tab;
    if (tab && tab.parentNode) {
        tab.parentNode.removeChild(tab);
        console.log(`🟡 Вкладка ${username} удалена из DOM`);
    }

    const container = userTabs[username].container;
    if (container && container.parentNode) {
        container.parentNode.removeChild(container);
        console.log(`🟡 Контейнер ${username} удалён из DOM`);
    }

    delete userTabs[username];
    console.log(`🟡 Вкладка ${username} удалена из кэша`);

    if (currentTab === username) {
        console.log('🟡 Закрыта активная вкладка, переключение на главную');
        switchToTab('main');
    }

    showToast(`Закрыта вкладка: ${username}`);
}

// ============ КОНТЕКСТНОЕ МЕНЮ ============

let lastClickedUsername = null;

function getUsernameFromEvent(e) {
    const target = e.target;
    let usernameEl = null;

    if (target.classList && target.classList.contains('chat-username')) {
        usernameEl = target;
    } else if (target.closest) {
        usernameEl = target.closest('.chat-username');
    }

    if (usernameEl) {
        return usernameEl.textContent.trim();
    }
    return null;
}

function setupChatContextMenu() {
    console.log('🟡 setupChatContextMenu');
    const container = document.getElementById('chatContainer');
    if (!container) {
        console.warn('⚠️ chatContainer не найден');
        return;
    }

    container.addEventListener('click', function(e) {
        const username = getUsernameFromEvent(e);
        if (username) {
            lastClickedUsername = username;
            console.log(`🟡 Сохранён ник: ${username}`);
        }
    });

    container.addEventListener('contextmenu', function(e) {
        let username = getUsernameFromEvent(e);
        if (!username) {
            username = lastClickedUsername;
        }

        if (username) {
            e.preventDefault();
            e.stopPropagation();
            console.log(`🟡 Показываем меню для: ${username}`);
            showContextMenu(e.clientX, e.clientY, username);
        } else {
            console.log('🟡 Не удалось определить имя пользователя');
        }
    });

    console.log('✅ Контекстное меню настроено');
}

function showContextMenu(x, y, username) {
    console.log(`🟡 showContextMenu: ${username} at (${x}, ${y})`);
    const oldMenu = document.getElementById('customContextMenu');
    if (oldMenu) oldMenu.remove();

    const menu = document.createElement('div');
    menu.id = 'customContextMenu';
    menu.style.cssText = `
        position: fixed;
        left: ${Math.min(x, window.innerWidth - 220)}px;
        top: ${Math.min(y, window.innerHeight - 200)}px;
        background: #111118;
        border: 1px solid #282836;
        border-radius: 10px;
        padding: 6px 0;
        min-width: 210px;
        z-index: 999999;
        box-shadow: 0 8px 40px rgba(0,0,0,0.9);
        animation: menuFadeIn 0.12s ease;
    `;

    const items = [
        { icon: 'fa-folder-open', text: 'Открыть отдельно', action: () => {
            console.log(`🟡 Выбрано "Открыть отдельно" для ${username}`);
            openUserWindow(username);
        }},
        { icon: 'fa-window-restore', text: 'Открыть во вкладке', action: () => {
            console.log(`🟡 Выбрано "Открыть во вкладке" для ${username}`);
            addUserTab(username);
        }},
        { divider: true },
        { icon: 'fa-copy', text: 'Копировать имя', action: () => {
            console.log(`🟡 Выбрано "Копировать имя" для ${username}`);
            copyUsernameToClipboard(username);
        }},
        { icon: 'fa-twitch', text: 'Профиль Twitch', action: () => {
            console.log(`🟡 Выбрано "Профиль Twitch" для ${username}`);
            openTwitchProfile(username);
        }}
    ];

    items.forEach(item => {
        if (item.divider) {
            const hr = document.createElement('hr');
            hr.style.cssText = 'border-color: #282836; margin: 4px 12px;';
            menu.appendChild(hr);
            return;
        }

        const btn = document.createElement('button');
        btn.style.cssText = `
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
            padding: 8px 16px;
            background: transparent;
            border: none;
            color: #eaeaf0;
            font-size: 13px;
            font-family: 'Segoe UI', Arial, sans-serif;
            cursor: pointer;
            text-align: left;
            transition: background 0.1s;
        `;
        btn.innerHTML = `<i class="fas ${item.icon}" style="width:22px; flex-shrink:0; text-align:center;"></i> <span>${item.text}</span>`;
        btn.onmouseover = () => btn.style.background = '#20202c';
        btn.onmouseout = () => btn.style.background = 'transparent';
        btn.onclick = () => {
            console.log(`🟡 Клик по пункту меню: ${item.text}`);
            item.action();
            menu.remove();
        };
        menu.appendChild(btn);
    });

    document.body.appendChild(menu);
    console.log('✅ Меню отображено');

    setTimeout(() => {
        const closeHandler = function(e) {
            if (!menu.contains(e.target)) {
                menu.remove();
                document.removeEventListener('click', closeHandler);
                document.removeEventListener('contextmenu', closeHandler);
                console.log('🟡 Меню закрыто');
            }
        };
        document.addEventListener('click', closeHandler);
        document.addEventListener('contextmenu', closeHandler);
    }, 10);
}

// ============ ДЕЙСТВИЯ МЕНЮ ============
function openUserWindow(username) {
    console.log(`🟡 openUserWindow: ${username}`);
    fetch('/api/open_window', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'ok') {
            showToast(`Открыто окно: ${username}`);
        } else {
            console.error('Ошибка:', data.message);
            window.open(`/user/${username}`, '_blank');
            showToast(`Открыто в браузере: ${username}`);
        }
    })
    .catch(error => {
        console.error('Ошибка запроса:', error);
        window.open(`/user/${username}`, '_blank');
        showToast(`Открыто в браузере: ${username}`);
    });
}
function copyUsernameToClipboard(username) {
    console.log(`🟡 copyUsernameToClipboard: ${username}`);
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(username).then(() => {
            showToast(`Скопировано: ${username}`);
        }).catch(() => {
            fallbackCopyText(username);
        });
    } else {
        fallbackCopyText(username);
    }
}

function fallbackCopyText(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none;z-index:-1;';
    document.body.appendChild(ta);
    ta.select();
    try {
        document.execCommand('copy');
        showToast(`Скопировано: ${text}`);
    } catch (e) {
        console.error('Ошибка копирования:', e);
    }
    ta.remove();
}

function openTwitchProfile(username) {
    console.log(`🟡 openTwitchProfile: ${username}`);
    window.open(`https://twitch.tv/${username}`, '_blank');
    showToast(`Открыт профиль: ${username}`);
}

// ============ СТИЛИ ============

const menuStyles = document.createElement('style');
menuStyles.textContent = `
    @keyframes menuFadeIn {
        from { opacity: 0; transform: scale(0.95) translateY(-5px); }
        to { opacity: 1; transform: scale(1) translateY(0); }
    }

    .tabs-container .tab {
        cursor: pointer !important;
        transition: all 0.2s !important;
        user-select: none !important;
    }

    .tabs-container .tab:hover {
        background: rgba(124, 92, 252, 0.15) !important;
    }

    .tabs-container .tab.active {
        background: rgba(124, 92, 252, 0.3) !important;
        border-color: #7c5cfc !important;
        color: #eaeaf0 !important;
    }

    .tabs-container .tab .tab-close:hover {
        opacity: 1 !important;
        color: #f43f5e !important;
    }

    .tabs-container::-webkit-scrollbar {
        height: 2px;
    }
    .tabs-container::-webkit-scrollbar-thumb {
        background: #282836;
        border-radius: 2px;
    }

    .user-chat-container {
        height: 100%;
        overflow: hidden;
    }
`;
document.head.appendChild(menuStyles);
console.log('✅ Стили добавлены');

// ============ ИНИЦИАЛИЗАЦИЯ ============

function initContextMenu() {
    console.log('🔵 Инициализация контекстного меню...');
    const container = document.getElementById('chatContainer');
    if (container) {
        setupChatContextMenu();
        console.log('✅ Контекстное меню инициализировано');
    } else {
        console.log('🟡 chatContainer ещё не создан, повторная попытка через 500ms');
        setTimeout(initContextMenu, 500);
    }
}

window.addUserTab = addUserTab;
window.switchToTab = switchToTab;
window.closeUserTab = closeUserTab;
window.openUserWindow = openUserWindow;

console.log('🟡 Функции зарегистрированы глобально');

if (document.readyState === 'complete' || document.readyState === 'interactive') {
    console.log('🟡 DOM готов, запуск инициализации');
    setTimeout(initContextMenu, 300);
} else {
    console.log('🟡 Ожидание загрузки DOM');
    document.addEventListener('DOMContentLoaded', () => {
        console.log('🟡 DOM загружен, запуск инициализации');
        setTimeout(initContextMenu, 300);
    });
}

window.addEventListener('load', () => {
    console.log('🟡 Страница полностью загружена');
    setTimeout(initContextMenu, 500);
});

console.log('✅ Модуль вкладок и контекстного меню загружен');

// Запуск основной инициализации
init();