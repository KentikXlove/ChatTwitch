import socket
import threading
import hashlib
from datetime import datetime
import os
from logger import get_logger
from settings import load_config, SETTINGS_DIR

logger = get_logger(__name__)

class TwitchIRC:
    def __init__(self, socketio):
        self.socketio = socketio
        self.sock = None
        self.channel = None
        self.thread = None
        self.running = False

    def start(self, channel):
        if self.running:
            self.stop()
        self.channel = channel.lower()
        self.running = True
        self.thread = threading.Thread(target=self._connect, daemon=True)
        self.thread.start()
        logger.info(f"IRC-парсер запущен для канала {self.channel}")

    def stop(self):
        self.running = False
        if self.sock:
            try:
                self.sock.close()
            except:
                pass
        logger.info("IRC-парсер остановлен")

    def _connect(self):
        try:
            self.sock = socket.socket()
            self.sock.settimeout(2)
            self.sock.connect(("irc.chat.twitch.tv", 6667))
            self.sock.send(b"PASS justinfan123\r\n")
            self.sock.send(b"NICK justinfan123\r\n")
            self.sock.send(f"JOIN #{self.channel}\r\n".encode())
            logger.info(f"Подключён к IRC, канал #{self.channel}")

            buffer = ""
            while self.running:
                try:
                    data = self.sock.recv(4096).decode('utf-8', errors='ignore')
                    if not data:
                        break
                    buffer += data
                    while '\r\n' in buffer:
                        line, buffer = buffer.split('\r\n', 1)
                        try:
                            self._handle_line(line)
                        except Exception as e:
                            logger.error(f"Ошибка обработки строки: {e}")
                except socket.timeout:
                    continue
                except Exception as e:
                    logger.error(f"Ошибка чтения: {e}")
                    break
        except Exception as e:
            logger.error(f"Не удалось подключиться к IRC: {e}")
        finally:
            self.running = False
            if self.sock:
                self.sock.close()

    def _handle_line(self, line):
        if line.startswith("PING"):
            self.sock.send(b"PONG :tmi.twitch.tv\r\n")
            return

        tags = {}
        if line.startswith('@'):
            end_tags = line.find(' ')
            if end_tags != -1:
                tags_part = line[1:end_tags]
                for item in tags_part.split(';'):
                    if '=' in item:
                        key, val = item.split('=', 1)
                        tags[key] = val
                line = line[end_tags+1:]

        if "PRIVMSG" not in line:
            return

        try:
            parts = line.split(':', 2)
            if len(parts) < 3:
                return
            user_info = parts[1]
            username = user_info.split('!')[0]
            message = parts[2].strip()
        except Exception:
            return

        badges_str = tags.get('badges', '')
        badges = []
        if badges_str:
            for b in badges_str.split(','):
                if '/' in b:
                    name, version = b.split('/', 1)
                    badges.append({'name': name, 'version': version})

        color = self._generate_color(username)

        message_data = {
            'username': username,
            'message': message,
            'color': color,
            'timestamp': datetime.now().isoformat(),
            'badges': badges
        }

        # ===== ИСПРАВЛЕНИЕ: вызываем обработчик напрямую =====
        from web import add_message_to_history
        add_message_to_history(username, message, color, badges)
        # =====================================================

        # Отправляем событие клиентам (для оверлея)
        self.socketio.emit('chat_message', message_data)

        # Логирование в файл (если включено)
        config = load_config()
        if config.get("log_messages", False):
            self._log_message(username, message)

    def _generate_color(self, username):
        hash_bytes = hashlib.md5(username.encode()).digest()
        r, g, b = hash_bytes[0], hash_bytes[1], hash_bytes[2]
        return f"#{r:02x}{g:02x}{b:02x}"

    def _log_message(self, username, message):
        date_str = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(SETTINGS_DIR, f"chat_log_{date_str}.txt")
        timestamp = datetime.now().strftime("%H:%M:%S")
        try:
            os.makedirs(SETTINGS_DIR, exist_ok=True)
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(f"[{timestamp}] {username}: {message}\n")
        except Exception as e:
            logger.error(f"Не удалось записать лог сообщения: {e}")