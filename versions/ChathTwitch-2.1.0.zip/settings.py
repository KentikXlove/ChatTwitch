# settings.py
import json
import os
from logger import get_logger

logger = get_logger(__name__)

SETTINGS_DIR = "data"
SETTINGS_FILE = os.path.join(SETTINGS_DIR, "config.json")

DEFAULT_CONFIG = {
    "nickname": "",
    "ttl": 0,
    "css": "",
    "log_messages": False,
    "max_messages": 100,
    "show_viewers_in_overlay": False,
    "show_avatars": True,
    "username_color_mode": "twitch",
    "username_fixed_color": "#7c5cfc",
    "avatar_size": 28,
    "message_bg_color": "#111118",
    "hide_links": False,
    "ban_words": [],
    "animation": {
        "entry": "fade",
        "exit": "fade",
        "speed": 300,
        "delay": 0
    },
    "tts": {
        "enabled": True,
        "users": [],
        "exclude_users": [],
        "all_users": False,
        "volume": 80,
        "rate": 160,
        "engine": "auto",
        "voice": ""
    }
}

_config = None  # глобальный объект

def load_config():
    """Загружает конфиг из файла, создаёт дефолтный при отсутствии."""
    global _config
    os.makedirs(SETTINGS_DIR, exist_ok=True)

    if not os.path.exists(SETTINGS_FILE):
        save_config(DEFAULT_CONFIG.copy())
        import copy

        _config = copy.deepcopy(DEFAULT_CONFIG)
        return _config

    try:
        with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
            config = json.load(f)
        config = _merge_defaults(config)
        _config = config
        return config
    except Exception as e:
        logger.error(f"Ошибка загрузки конфига: {e}")
        save_config(DEFAULT_CONFIG.copy())
        _config = DEFAULT_CONFIG.copy()
        return _config

def save_config(config=None):
    """Сохраняет переданный конфиг (или текущий глобальный) в файл."""
    global _config
    if config is None:
        config = _config
    if config is None:
        config = DEFAULT_CONFIG.copy()
    os.makedirs(SETTINGS_DIR, exist_ok=True)
    with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    _config = config
    logger.debug("Конфиг сохранён")

def get_config():
    """Возвращает текущий конфиг (гарантированно загруженный)."""
    global _config
    if _config is None:
        load_config()
    return _config

def update_config(updates):
    """Обновляет конфиг переданными значениями и сохраняет."""
    config = get_config()
    _deep_update(config, updates)
    save_config(config)
    return config

def _deep_update(target, source):
    """Рекурсивное обновление словаря."""
    for key, value in source.items():
        if isinstance(value, dict) and key in target and isinstance(target[key], dict):
            _deep_update(target[key], value)
        else:
            target[key] = value

def _merge_defaults(config):
    """Рекурсивно дополняет недостающие поля до DEFAULT_CONFIG."""
    def merge(base, defaults):
        for key, value in defaults.items():
            if key not in base:
                base[key] = value
            elif isinstance(value, dict) and isinstance(base.get(key), dict):
                merge(base[key], value)
        return base
    return merge(config, DEFAULT_CONFIG)