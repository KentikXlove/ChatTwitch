from functools import lru_cache
from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
from parser import TwitchIRC
from logger import get_logger
from data.version import VERSION
from settings import load_config, save_config, DEFAULT_CONFIG
from datetime import datetime
import threading
import subprocess
import platform
import time
import requests
import re
from settings import get_config

logger = get_logger("web")

app = Flask(__name__)
app.config['SECRET_KEY'] = 'twitch-chat-overlay-secret-2024'
socketio = SocketIO(
    app,
    async_mode='threading',
    cors_allowed_origins="*",
    logger=False,
    engineio_logger=False,
    ping_timeout=60,
    ping_interval=25
)

parser = TwitchIRC(socketio)

# Глобальные настройки – загружаем сразу
current_config = get_config()          # словарь из settings
tts_settings = current_config.get('tts', {}).copy()
tts_settings['ban_words'] = current_config.get('ban_words', [])

message_history = []
message_lock = threading.Lock()
start_time = None

user_messages_cache = {}
user_messages_lock = threading.Lock()
MAX_USER_MESSAGES = 200

tts_queue = []
tts_lock = threading.Lock()

viewers_count = 0
viewers_running = False
viewers_thread = None
VIEWERS_UPDATE_INTERVAL = 60

logger.info(f"Конфигурация загружена: nickname={current_config.get('nickname')}")
logger.info(f"ОС: {platform.system()} {platform.release()}")

# ==================== TTS ENGINE ====================

class TTSEngine:
    def __init__(self):
        self.name = "base"
        self.available = False

    def speak(self, text, volume=80, rate=160):
        raise NotImplementedError

    def stop(self):
        pass


class Pyttsx3Engine(TTSEngine):
    def __init__(self, voice_name=None):
        super().__init__()
        self.name = "pyttsx3"
        self._voice_name = voice_name
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
            self.available = True
            if self._voice_name:
                self.set_voice(self._voice_name)
            voices = self.engine.getProperty('voices')
            logger.info(f"pyttsx3: найдено {len(voices)} голосов")
            for v in voices:
                logger.debug(f"  - {v.name} ({v.id}) [{', '.join(v.languages)}]")
            if not self._voice_name:
                for v in voices:
                    if 'russian' in v.name.lower() or 'ru' in v.id.lower():
                        self.engine.setProperty('voice', v.id)
                        self._voice_name = v.name
                        break
        except ImportError:
            logger.warning("pyttsx3 не установлен. Установите: pip install pyttsx3")
            self.available = False
        except Exception as e:
            logger.error(f"pyttsx3 ошибка инициализации: {e}")
            self.available = False

    def set_voice(self, voice_name):
        if not self.available:
            return
        try:
            voices = self.engine.getProperty('voices')
            for v in voices:
                if v.name == voice_name or v.id == voice_name:
                    self.engine.setProperty('voice', v.id)
                    self._voice_name = voice_name
                    break
        except Exception as e:
            logger.warning(f"Не удалось установить голос {voice_name}: {e}")

    def speak(self, text, volume=80, rate=160):
        if not self.available:
            logger.error("pyttsx3 недоступен")
            return False
        try:
            new_voice = tts_settings.get('voice')
            if new_voice and new_voice != self._voice_name:
                self.set_voice(new_voice)
            self.engine.setProperty('volume', volume / 100.0)
            self.engine.setProperty('rate', rate)
            logger.info(f"pyttsx3: говорю '{text[:50]}...' (громкость={volume}, скорость={rate})")
            self.engine.say(text)
            self.engine.runAndWait()
            logger.debug("pyttsx3: озвучивание завершено")
            return True
        except Exception as e:
            logger.error(f"pyttsx3 speak error: {e}")
            return False

    def stop(self):
        if self.available:
            try:
                self.engine.stop()
            except:
                pass


class EspeakEngine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "espeak"
        try:
            subprocess.run(["espeak", "--version"], capture_output=True)
            self.available = True
            logger.info("espeak: доступен")
        except FileNotFoundError:
            self.available = False
            logger.info("espeak: не найден")

    def speak(self, text, volume=80, rate=160):
        if not self.available:
            return False
        try:
            amplitude = int((volume / 100) * 200)
            speed = rate
            logger.info(f"espeak: говорю '{text[:50]}...' (амплитуда={amplitude}, скорость={speed})")
            subprocess.run(
                ["espeak", "-a", str(amplitude), "-s", str(speed), "-v", "ru", text],
                capture_output=True, timeout=15
            )
            return True
        except Exception as e:
            logger.error(f"espeak error: {e}")
            return False


class SayEngine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "say"
        self.available = platform.system() == "Darwin"
        if self.available:
            logger.info("say: доступен (macOS)")

    def speak(self, text, volume=80, rate=200):
        if not self.available:
            return False
        try:
            vol = volume / 100.0
            logger.info(f"say: говорю '{text[:50]}...' (громкость={vol}, скорость={rate})")
            subprocess.run(
                ["say", "-r", str(rate), "-v", str(vol), text],
                capture_output=True, timeout=15
            )
            return True
        except Exception as e:
            logger.error(f"say error: {e}")
            return False


class FestivalEngine(TTSEngine):
    def __init__(self):
        super().__init__()
        self.name = "festival"
        try:
            subprocess.run(["festival", "--version"], capture_output=True)
            self.available = True
            logger.info("festival: доступен")
        except FileNotFoundError:
            self.available = False

    def speak(self, text, volume=80, rate=160):
        if not self.available:
            return False
        try:
            logger.info(f"festival: говорю '{text[:50]}...'")
            subprocess.run(
                ["festival", "--tts"],
                input=text.encode(),
                capture_output=True, timeout=15
            )
            return True
        except Exception as e:
            logger.error(f"festival error: {e}")
            return False


def get_available_engines():
    engines = {}
    try:
        import pyttsx3
        engines['pyttsx3'] = Pyttsx3Engine()
    except ImportError:
        engines['pyttsx3'] = None
    engines['espeak'] = EspeakEngine()
    engines['say'] = SayEngine()
    engines['festival'] = FestivalEngine()
    return engines


def get_tts_engine(engine_name='auto', voice=None):
    engines = get_available_engines()
    if engine_name == 'auto':
        priority = ['pyttsx3', 'espeak', 'say', 'festival']
        for name in priority:
            engine = engines.get(name)
            if engine and engine.available:
                if voice and name == 'pyttsx3':
                    engine.set_voice(voice)
                logger.info(f"TTS: выбран движок '{name}'")
                return engine
    engine = engines.get(engine_name)
    if engine and engine.available:
        if voice and engine_name == 'pyttsx3':
            engine.set_voice(voice)
        return engine
    logger.warning(f"TTS: движок '{engine_name}' недоступен, ищем альтернативу...")
    return get_tts_engine('auto', voice)


def speak_text(text, engine_name='auto', volume=80, rate=160, voice=None):
    logger.info(
        f"speak_text вызван: текст='{text[:50]}...', engine={engine_name}, volume={volume}, rate={rate}, voice={voice}")
    engine = get_tts_engine(engine_name, voice)
    if not engine:
        logger.warning("TTS: нет доступного движка")
        return False
    try:
        result = engine.speak(text, volume=volume, rate=rate)
        if result:
            logger.debug(f"TTS [{engine.name}]: озвучено ({len(text)} символов)")
        else:
            logger.warning(f"TTS [{engine.name}]: озвучивание вернуло False")
        return result
    except Exception as e:
        logger.error(f"TTS ошибка: {e}")
        return False


def tts_worker():
    logger.info("TTS воркер запущен (последовательный режим)")
    while True:
        try:
            text = None
            with tts_lock:
                if tts_queue:
                    text = tts_queue.pop(0)
            if text:
                logger.info(f"TTS воркер: озвучиваю '{text[:50]}...' (очередь: {len(tts_queue)})")
                engine = tts_settings.get('engine', 'auto')
                volume = tts_settings.get('volume', 80)
                rate = tts_settings.get('rate', 160)
                voice = tts_settings.get('voice')
                speak_text(text, engine, volume, rate, voice)
            else:
                time.sleep(0.2)
        except Exception as e:
            logger.error(f"TTS worker error: {e}")
            time.sleep(0.5)


def stop_tts_immediately():
    with tts_lock:
        tts_queue.clear()
    engine = get_tts_engine(tts_settings.get('engine', 'auto'))
    if engine and hasattr(engine, 'stop'):
        engine.stop()
    logger.info("TTS остановлен, очередь очищена")


tts_thread = threading.Thread(target=tts_worker, daemon=True)
tts_thread.start()


def add_to_tts_queue(username, message, tts_queue):
    logger.debug(
        f"TTS check: user={username}, enabled={tts_settings.get('enabled')}, all_users={tts_settings.get('all_users')}")
    if not tts_settings.get('enabled', True):
        logger.info(f"TTS: отключено глобально, сообщение от {username} не озвучивается")
        return

    ban_words = tts_settings.get('ban_words', [])
    if ban_words:
        message_lower = message.lower()
        for word in ban_words:
            if word in message_lower:
                logger.info(f"TTS: сообщение от {username} содержит запрещённое слово '{word}', не озвучивается")
                return

    all_users = tts_settings.get('all_users', False)
    if all_users:
        exclude = [u.lower() for u in tts_settings.get('exclude_users', [])]
        if username.lower() in exclude:
            logger.info(f"TTS: пользователь {username} в списке исключений, не озвучивается")
            return
    else:
        allowed = [u.lower() for u in tts_settings.get('users', [])]
        if username.lower() not in allowed:
            logger.info(f"TTS: пользователь {username} не в списке разрешённых, не озвучивается (список: {allowed})")
            return

    text = f"{username} говорит: {message}"
    with tts_lock:
        tts_queue.append(text)
        if len(tts_queue) > 30:
            tts_queue = tts_queue[-20:]
        logger.info(f"TTS добавлено: {username} (очередь: {len(tts_queue)})")


# ==================== ЗРИТЕЛИ ====================

def get_viewers(channel):
    try:
        url = f"https://decapi.me/twitch/viewercount/{channel}"
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            text = resp.text.strip()
            if text.isdigit():
                return int(text)
            elif "offline" in text.lower():
                return "offline"
            else:
                logger.warning(f"Неожиданный ответ от decapi.me: {text}")
                return None
        else:
            logger.warning(f"Ошибка получения зрителей: {resp.status_code}")
            return None
    except Exception as e:
        logger.error(f"Исключение при получении зрителей: {e}")
        return None


def viewers_loop(channel):
    global viewers_count, viewers_running
    logger.info(f"Запущен поток обновления зрителей для канала {channel}")
    while viewers_running:
        count = get_viewers(channel)
        if count is not None:
            viewers_count = count
            socketio.emit('viewers_update', {'count': viewers_count, 'channel': channel})
            logger.debug(f"Зрителей: {viewers_count}")
        else:
            viewers_count = 0
        time.sleep(VIEWERS_UPDATE_INTERVAL)
    logger.info("Поток обновления зрителей остановлен")


def start_viewers_updater(channel):
    global viewers_running, viewers_thread
    if viewers_running:
        stop_viewers_updater()
    viewers_running = True
    viewers_thread = threading.Thread(target=viewers_loop, args=(channel,), daemon=True)
    viewers_thread.start()


def stop_viewers_updater():
    global viewers_running, viewers_thread
    viewers_running = False
    if viewers_thread and viewers_thread.is_alive():
        viewers_thread.join(timeout=2)
    viewers_thread = None


# ==================== ROUTES ====================

@app.route('/')
def index():
    return render_template('app.html')

@app.route('/app')
def app_page():
    return render_template('app.html')

@app.route('/overlay')
def overlay():
    return render_template('overlay.html')

@app.route('/user/<username>')
def user_page(username):
    return render_template('user.html', username=username)

@app.route('/api/user/<username>/messages')
def get_user_messages(username):
    with user_messages_lock:
        messages = user_messages_cache.get(username, [])
        return jsonify({
            'messages': messages,
            'count': len(messages),
            'username': username
        })

@app.route('/api/start', methods=['POST'])
def start_parser():
    global start_time, current_config
    data = request.get_json() or {}
    nickname = data.get('nickname', current_config.get('nickname', '')).strip()
    if not nickname:
        return jsonify({'status': 'error', 'message': 'Nickname is required'}), 400

    # Обновляем конфиг
    current_config.update({
        'nickname': nickname,
        'ttl': int(data.get('ttl', current_config.get('ttl', 0))),
        'css': data.get('css', current_config.get('css', '')),
        'log_messages': data.get('log_messages', current_config.get('log_messages', False)),
        'max_messages': int(data.get('max_messages', current_config.get('max_messages', 100))),
        'show_viewers_in_overlay': data.get('show_viewers_in_overlay', current_config.get('show_viewers_in_overlay', False)),
        'hide_links': data.get('hide_links', current_config.get('hide_links', False)),
        'show_avatars': data.get('show_avatars', current_config.get('show_avatars', True)),
        'username_color_mode': data.get('username_color_mode', current_config.get('username_color_mode', 'twitch')),
        'username_fixed_color': data.get('username_fixed_color', current_config.get('username_fixed_color', '#7c5cfc')),
        'avatar_size': int(data.get('avatar_size', current_config.get('avatar_size', 28))),
        'message_bg_color': data.get('message_bg_color', current_config.get('message_bg_color', '#111118'))
    })
    save_config(current_config)

    with message_lock:
        message_history.clear()
    with user_messages_lock:
        user_messages_cache.clear()

    start_time = datetime.now()
    parser.start(nickname)
    start_viewers_updater(nickname)

    socketio.emit('config_update', _get_config_dict())
    socketio.emit('parser_status', {
        'running': True,
        'nickname': nickname,
        'start_time': start_time.isoformat() if start_time else None
    })
    logger.info(f"Парсер запущен: канал={nickname}")
    return jsonify({'status': 'ok', 'nickname': nickname})

@app.route('/api/stop', methods=['POST'])
def stop_parser():
    global start_time
    parser.stop()
    start_time = None
    stop_viewers_updater()
    socketio.emit('parser_status', {'running': False, 'nickname': '', 'start_time': None})
    return jsonify({'status': 'ok'})

@app.route('/api/status')
def get_status():
    return jsonify({
        'running': parser.running,
        'nickname': current_config.get('nickname', ''),
        'ttl': current_config.get('ttl', 0),
        'log_messages': current_config.get('log_messages', False),
        'css': current_config.get('css', ''),
        'max_messages': current_config.get('max_messages', 100),
        'start_time': start_time.isoformat() if start_time else None,
        'message_count': len(message_history),
        'viewers': viewers_count,
        'show_viewers_in_overlay': current_config.get('show_viewers_in_overlay', False),
        'show_avatars': current_config.get('show_avatars', True),
        'username_color_mode': current_config.get('username_color_mode', 'twitch'),
        'username_fixed_color': current_config.get('username_fixed_color', '#7c5cfc'),
        'avatar_size': current_config.get('avatar_size', 28),
        'message_bg_color': current_config.get('message_bg_color', '#111118'),
        'hide_links': current_config.get('hide_links', False)
    })

@app.route('/api/messages')
def get_messages():
    with message_lock:
        return jsonify({
            'messages': message_history.copy(),
            'count': len(message_history),
            'start_time': start_time.isoformat() if start_time else None
        })

# ===== ИСПРАВЛЕННЫЙ /api/config (GET) =====
@app.route('/api/config', methods=['GET'])
def config_api_get():
    return jsonify(current_config)

# ===== ИСПРАВЛЕННЫЙ /api/config (PUT) =====
@app.route('/api/config', methods=['PUT'])
def config_api_update():
    global current_config
    data = request.get_json() or {}
    allowed_keys = [
        'ttl', 'css', 'log_messages', 'nickname', 'max_messages',
        'show_viewers_in_overlay', 'show_avatars', 'username_color_mode',
        'username_fixed_color', 'avatar_size', 'message_bg_color',
        'hide_links', 'ban_words'
    ]
    for key in allowed_keys:
        if key in data:
            current_config[key] = data[key]

    # Если переданы ban_words, сохраняем как список
    if 'ban_words' in data:
        if isinstance(data['ban_words'], str):
            current_config['ban_words'] = [w.strip().lower() for w in data['ban_words'].split(',') if w.strip()]
        else:
            current_config['ban_words'] = data['ban_words']

    save_config(current_config)

    # Ограничиваем историю
    max_msgs = current_config.get('max_messages', 100)
    with message_lock:
        while len(message_history) > max_msgs:
            message_history.pop(0)

    # Отправляем обновление всем клиентам
    socketio.emit('config_update', _get_config_dict())
    return jsonify({'status': 'ok'})

# Вспомогательная функция для формирования словаря для отправки
def _get_config_dict():
    return {
        'ttl': current_config.get('ttl', 0),
        'css': current_config.get('css', ''),
        'nickname': current_config.get('nickname', ''),
        'log_messages': current_config.get('log_messages', False),
        'max_messages': current_config.get('max_messages', 100),
        'show_viewers_in_overlay': current_config.get('show_viewers_in_overlay', False),
        'show_avatars': current_config.get('show_avatars', True),
        'username_color_mode': current_config.get('username_color_mode', 'twitch'),
        'username_fixed_color': current_config.get('username_fixed_color', '#7c5cfc'),
        'avatar_size': current_config.get('avatar_size', 28),
        'message_bg_color': current_config.get('message_bg_color', '#111118'),
        'hide_links': current_config.get('hide_links', False),
        'ban_words': current_config.get('ban_words', [])
    }

# ===== TTS CONFIG =====
@app.route('/api/tts/config', methods=['GET'])
def get_tts_config():
    tts = current_config.get('tts', {})
    # Добавляем ban_words из корня
    tts['ban_words'] = current_config.get('ban_words', [])
    return jsonify(tts)

@app.route('/api/tts/config', methods=['PUT'])
def update_tts_config():
    global current_config, tts_settings
    data = request.get_json() or {}
    tts = current_config.get('tts', {})

    # Обновляем поля TTS
    for key in ['enabled', 'users', 'exclude_users', 'all_users', 'volume', 'rate', 'engine', 'voice']:
        if key in data:
            tts[key] = data[key]

    # Преобразуем строки в списки
    if 'users' in data and isinstance(data['users'], str):
        tts['users'] = [u.strip() for u in data['users'].split(',') if u.strip()]
    if 'exclude_users' in data and isinstance(data['exclude_users'], str):
        tts['exclude_users'] = [u.strip() for u in data['exclude_users'].split(',') if u.strip()]

    # ban_words отдельно
    if 'ban_words' in data:
        if isinstance(data['ban_words'], str):
            current_config['ban_words'] = [w.strip().lower() for w in data['ban_words'].split(',') if w.strip()]
        else:
            current_config['ban_words'] = data['ban_words']
        tts['ban_words'] = current_config['ban_words']

    current_config['tts'] = tts
    tts_settings.update(tts)
    tts_settings['ban_words'] = current_config.get('ban_words', [])
    save_config(current_config)

    socketio.emit('tts_update', tts_settings)
    return jsonify({'status': 'ok'})

# ===== ANIMATION CONFIG =====
@app.route('/api/animation/config', methods=['GET'])
def get_animation_config():
    return jsonify(current_config.get('animation', DEFAULT_CONFIG['animation']))

@app.route('/api/animation/config', methods=['PUT'])
def update_animation_config():
    global current_config
    data = request.get_json() or {}
    animation = current_config.get('animation', DEFAULT_CONFIG['animation'].copy())

    if 'entry' in data and data['entry'] in ['fade','slide','pop','typewriter','bounce','glow','flip']:
        animation['entry'] = data['entry']
    if 'exit' in data and data['exit'] in ['fade','slide','pop','typewriter','bounce','glow','flip']:
        animation['exit'] = data['exit']
    if 'speed' in data:
        animation['speed'] = max(50, min(2000, int(data['speed'])))
    if 'delay' in data:
        animation['delay'] = max(0, min(1000, int(data['delay'])))

    current_config['animation'] = animation
    save_config(current_config)

    # Отправляем обновление конфига целиком
    socketio.emit('config_update', _get_config_dict())
    return jsonify({'status': 'ok', 'animation': animation})

@app.route('/api/tts/test', methods=['POST'])
def test_tts():
    data = request.get_json() or {}
    text = data.get('text', 'Привет! Это тестовое сообщение для проверки синтеза речи.')
    engine_name = data.get('engine', tts_settings.get('engine', 'auto'))
    volume = data.get('volume', tts_settings.get('volume', 80))
    rate = data.get('rate', tts_settings.get('rate', 160))
    voice = data.get('voice', tts_settings.get('voice'))
    logger.info(f"Тест TTS: текст='{text[:50]}...', engine={engine_name}, volume={volume}, rate={rate}, voice={voice}")

    def speak():
        speak_text(text, engine_name, volume, rate, voice)

    threading.Thread(target=speak, daemon=True).start()
    return jsonify({
        'status': 'ok',
        'message': f'Озвучиваю через {engine_name}',
        'text': text,
        'engine': engine_name,
        'volume': volume,
        'rate': rate,
        'voice': voice
    })

@app.route('/api/tts/engines', methods=['GET'])
def list_engines():
    engines = get_available_engines()
    result = {}
    for name, eng in engines.items():
        result[name] = {'available': eng.available if eng else False, 'name': eng.name if eng else name}
    return jsonify(result)

@app.route('/api/tts/voices', methods=['GET'])
def get_tts_voices():
    engine_name = request.args.get('engine', 'pyttsx3')
    voices = []
    if engine_name == 'pyttsx3':
        try:
            import pyttsx3
            engine = pyttsx3.init()
            for v in engine.getProperty('voices'):
                voices.append(v.name)
            engine.stop()
        except Exception as e:
            logger.error(f"Ошибка получения голосов pyttsx3: {e}")
    return jsonify({'voices': voices})

@app.route('/api/tts/stop', methods=['POST'])
def stop_tts():
    with tts_lock:
        tts_queue.clear()
    engine = get_tts_engine(tts_settings.get('engine', 'auto'))
    if engine:
        engine.stop()
    return jsonify({'status': 'ok', 'message': 'TTS остановлен, очередь очищена'})

@app.route('/api/clear', methods=['POST'])
def clear_messages():
    with message_lock:
        message_history.clear()
    with user_messages_lock:
        user_messages_cache.clear()
    socketio.emit('messages_clear')
    return jsonify({'status': 'ok'})

@app.route('/api/toggle', methods=['POST'])
def toggle_parser():
    global start_time
    if parser.running:
        parser.stop()
        start_time = None
        stop_viewers_updater()
        socketio.emit('parser_status', {'running': False, 'nickname': '', 'start_time': None})
        return jsonify({'status': 'ok', 'running': False})
    else:
        nickname = current_config.get('nickname', '').strip()
        if not nickname:
            return jsonify({'status': 'error', 'message': 'No nickname configured'}), 400
        with message_lock:
            message_history.clear()
        with user_messages_lock:
            user_messages_cache.clear()
        start_time = datetime.now()
        parser.start(nickname)
        start_viewers_updater(nickname)
        socketio.emit('parser_status', {'running': True, 'nickname': nickname, 'start_time': start_time.isoformat()})
        return jsonify({'status': 'ok', 'running': True, 'nickname': nickname})

@app.route('/api/avatar/<username>')
def get_avatar(username):
    try:
        resp = requests.get(f'https://decapi.me/twitch/avatar/{username}', timeout=5)
        if resp.status_code == 200:
            url = resp.text.strip()
            if url.startswith('http'):
                return jsonify({'url': url})
            else:
                return jsonify({'url': None, 'error': 'Not found'})
        else:
            return jsonify({'url': None, 'error': 'API error'}), 404
    except Exception as e:
        return jsonify({'url': None, 'error': str(e)}), 500

@app.route('/api/animation/effects', methods=['GET'])
def get_animation_effects():
    return jsonify({
        'entry': ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip'],
        'exit': ['fade', 'slide', 'pop', 'typewriter', 'bounce', 'glow', 'flip']
    })

@app.route('/api/open_url', methods=['POST'])
def open_url():
    data = request.get_json() or {}
    url = data.get('url', '')
    if not url:
        return jsonify({'status': 'error', 'message': 'URL is required'}), 400
    try:
        if platform.system() == 'Windows':
            subprocess.run(['start', url], shell=True)
        elif platform.system() == 'Darwin':
            subprocess.run(['open', url])
        else:
            subprocess.run(['xdg-open', url])
        logger.info(f"Открыт URL: {url}")
        return jsonify({'status': 'ok', 'message': f'Открыт {url}'})
    except Exception as e:
        logger.error(f"Ошибка открытия URL: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/channel_info')
def get_channel_info():
    nickname = current_config.get('nickname', '')
    if not nickname:
        return jsonify({'status': 'error', 'message': 'No channel configured'}), 400
    try:
        resp = requests.get(f'https://decapi.me/twitch/channel/{nickname}', timeout=5)
        if resp.status_code == 200:
            data = resp.text.strip()
            try:
                import json
                channel_data = json.loads(data)
                return jsonify({'status': 'ok', 'channel': channel_data})
            except:
                return jsonify({'status': 'ok', 'channel': {'name': nickname, 'display_name': nickname, 'title': 'Информация недоступна'}})
        else:
            return jsonify({'status': 'ok', 'channel': {'name': nickname, 'display_name': nickname, 'title': 'Офлайн или недоступен'}})
    except Exception as e:
        logger.error(f"Ошибка получения информации о канале: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/top_chatters')
def get_top_chatters():
    with user_messages_lock:
        chatters = {}
        for username, messages in user_messages_cache.items():
            chatters[username] = len(messages)
        sorted_chatters = sorted(chatters.items(), key=lambda x: x[1], reverse=True)[:20]
        return jsonify({'status': 'ok', 'chatters': [{'username': name, 'count': count} for name, count in sorted_chatters]})

@app.route('/api/open_window', methods=['POST'])
def open_window():
    data = request.get_json()
    username = data.get('username')
    if not username:
        return jsonify({'status': 'error', 'message': 'No username'}), 400
    if window.overlay_window is None:
        return jsonify({'status': 'error', 'message': 'Окно ещё не создано'}), 503
    window.signal_bus.open_user_window_signal.emit(username)
    return jsonify({'status': 'ok'})

# ===== ОБРАБОТЧИКИ СОБЫТИЙ SOCKET.IO =====
@socketio.on('chat_message')
def handle_chat_message(data):
    add_message_to_history(
        data['username'],
        data['message'],
        data['color'],
        data.get('badges', [])
    )

# ===== ИСПРАВЛЕННЫЙ ОБРАБОТЧИК CONNECT =====
@socketio.on('connect')
def handle_connect(auth=None):
    emit('config_update', _get_config_dict())
    emit('parser_status', {
        'running': parser.running,
        'nickname': current_config.get('nickname', ''),
        'start_time': start_time.isoformat() if start_time else None
    })
    emit('tts_update', tts_settings)
    emit('viewers_update', {
        'count': viewers_count,
        'channel': current_config.get('nickname', '')
    })
    with message_lock:
        if message_history:
            emit('message_history', {
                'messages': message_history.copy(),
                'start_time': start_time.isoformat() if start_time else None
            })

def add_message_to_history(username, message, color, badges=None):
    global message_history
    with message_lock:
        msg_data = {
            'username': username,
            'message': message,
            'color': color,
            'timestamp': datetime.now().isoformat(),
            'badges': badges or []
        }
        message_history.append(msg_data)
        max_msgs = current_config.get('max_messages', 100)
        while len(message_history) > max_msgs:
            message_history.pop(0)

    with user_messages_lock:
        if username not in user_messages_cache:
            user_messages_cache[username] = []
        user_messages_cache[username].append(msg_data)
        while len(user_messages_cache[username]) > MAX_USER_MESSAGES:
            user_messages_cache[username].pop(0)

    add_to_tts_queue(username, message, tts_queue)

def auto_start_parser():
    nickname = current_config.get('nickname', '').strip()
    if nickname:
        logger.info(f"Автоматический запуск парсера для канала: {nickname}")
        time.sleep(1)
        with app.app_context():
            global start_time
            with message_lock:
                message_history.clear()
            with user_messages_lock:
                user_messages_cache.clear()
            start_time = datetime.now()
            parser.start(nickname)
            start_viewers_updater(nickname)
            socketio.emit('parser_status', {
                'running': True,
                'nickname': nickname,
                'start_time': start_time.isoformat() if start_time else None
            })
            logger.info(f"Автозапуск завершён для канала {nickname}")
    else:
        logger.info("Канал не настроен, автозапуск пропущен")

# Импорт window для маршрута /api/open_window
import window

if __name__ == '__main__':
    threading.Thread(target=auto_start_parser, daemon=True).start()
    socketio.run(app, host='127.0.0.1', port=5000, debug=False, use_reloader=False)