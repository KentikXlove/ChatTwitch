import os
import sys
import re
import shutil
import zipfile
import requests
from pathlib import Path
from win32com.client import Dispatch
import ctypes


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def download_from_google_drive(file_id, destination):
    """
    Скачивание файлов с Google Drive (обработка предупреждения)
    """
    print("📥 Скачивание файла с Google Drive...")

    url = "https://drive.google.com/uc"
    params = {'id': file_id, 'export': 'download'}

    session = requests.Session()
    response = session.get(url, params=params)

    # Проверяем, есть ли форма для подтверждения
    if 'uc-download-link' in response.text or 'confirm' in response.text:
        print("🔍 Обнаружено предупреждение о вирусах, подтверждаем...")

        # Извлекаем все параметры из формы
        form_data = {}

        # Ищем все hidden поля
        hidden_fields = re.findall(r'<input type="hidden" name="([^"]+)" value="([^"]+)"', response.text)
        for name, value in hidden_fields:
            form_data[name] = value

        # Ищем action формы
        action_match = re.search(r'<form[^>]+action="([^"]+)"', response.text)
        if action_match:
            action_url = action_match.group(1)
        else:
            action_url = "https://drive.usercontent.google.com/download"

        # Добавляем параметры из URL
        for key, value in params.items():
            if key not in form_data:
                form_data[key] = value

        print(f"📋 Параметры формы: {form_data}")

        # Отправляем запрос на скачивание
        download_response = session.get(action_url, params=form_data, stream=True)

        # Проверяем, не перенаправили ли нас
        if download_response.history:
            print("🔄 Следование по перенаправлению...")
            final_response = download_response.history[-1]
            if final_response.status_code == 302:
                redirect_url = final_response.headers.get('Location')
                if redirect_url:
                    download_response = session.get(redirect_url, stream=True)

        # Сохраняем файл
        if download_response.status_code == 200:
            total_size = int(download_response.headers.get('content-length', 0))
            print(f"📦 Размер файла: {total_size / (1024 * 1024):.2f} MB")

            with open(destination, 'wb') as f:
                downloaded = 0
                for chunk in download_response.iter_content(chunk_size=32768):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total_size > 0:
                            percent = (downloaded / total_size) * 100
                            print(f'\r📥 Загрузка: {percent:.1f}% ({downloaded // 1024}/{total_size // 1024} KB)',
                                  end='')

            print(f"\n✅ Файл сохранен: {destination}")
            print(f"📊 Размер: {os.path.getsize(destination) / (1024 * 1024):.2f} MB")
            return True
        else:
            print(f"❌ Ошибка скачивания: {download_response.status_code}")
            return False
    else:
        print("⚠️ Страница не содержит форму подтверждения")
        return False


def create_shortcut(target_path, shortcut_path, working_dir):
    """Создание ярлыка"""
    try:
        shell = Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.TargetPath = target_path
        shortcut.WorkingDirectory = working_dir
        shortcut.WindowStyle = 1  # Normal window
        shortcut.Save()
        return True
    except Exception as e:
        print(f"❌ Ошибка создания ярлыка: {e}")
        return False


def find_exe_in_directory(directory):
    """Поиск EXE файла в папке"""
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith('.exe'):
                return os.path.join(root, file)
    return None


def main():
    # Проверка прав администратора
    if not is_admin():
        print("⚠️ Программа не запущена от имени администратора!")
        print("Некоторые операции могут не работать.")
        print()

    INSTALL_DIR = "C:\\ChatTwitch"
    APP_NAME = "ChatTwitch"
    FILE_ID = "1_OI3M53ScZBm1SKVHXwXoonXA-alzPvy"
    ZIP_NAME = "ChatTwitch.zip"

    print("========================================")
    print(f"    Установка {APP_NAME}")
    print("========================================")
    print()

    # Создание папки установки
    if not os.path.exists(INSTALL_DIR):
        print(f"📁 Создание папки {INSTALL_DIR}...")
        os.makedirs(INSTALL_DIR)

    os.chdir(INSTALL_DIR)
    zip_path = os.path.join(INSTALL_DIR, ZIP_NAME)

    # Скачивание файла
    if not os.path.exists(zip_path):
        if not download_from_google_drive(FILE_ID, zip_path):
            print()
            print("❌ Не удалось скачать файл!")
            print()
            print("Пожалуйста, скачайте файл вручную:")
            print(f"https://drive.google.com/file/d/{FILE_ID}/view")
            print(f"И поместите его в папку: {INSTALL_DIR}")
            print()
            input("Нажмите Enter для выхода...")
            sys.exit(1)
    else:
        print(f"✅ Файл уже существует: {ZIP_NAME}")

    # Распаковка
    print()
    print("📦 Распаковка архива...")
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(INSTALL_DIR)
        print("✅ Архив успешно распакован")

        # Удаление ZIP файла
        os.remove(zip_path)
        print("🗑️ ZIP файл удален")
    except Exception as e:
        print(f"❌ Ошибка распаковки: {e}")
        print()
        print("Распакуйте архив вручную в папку:", INSTALL_DIR)
        input("Нажмите Enter для выхода...")
        sys.exit(1)

    print()

    # Поиск EXE файла
    print("📌 Создание ярлыков...")
    exe_path = find_exe_in_directory(INSTALL_DIR)

    if not exe_path:
        print("⚠️ EXE файл не найден в папке установки")
        print()
        print("📂 Содержимое папки", INSTALL_DIR)
        for item in os.listdir(INSTALL_DIR):
            print(f"  - {item}")
        print()
        input("Нажмите Enter для выхода...")
        sys.exit(1)

    print(f"📱 Найден исполняемый файл: {exe_path}")

    # Создание ярлыков
    desktop = os.path.join(os.environ['USERPROFILE'], 'Desktop')
    start_menu = os.path.join(os.environ['APPDATA'], 'Microsoft', 'Windows', 'Start Menu', 'Programs')

    # Ярлык на рабочем столе
    desktop_shortcut = os.path.join(desktop, f"{APP_NAME}.lnk")
    if create_shortcut(exe_path, desktop_shortcut, INSTALL_DIR):
        print("✅ Ярлык создан на рабочем столе")

    # Ярлык в меню Пуск
    start_shortcut = os.path.join(start_menu, f"{APP_NAME}.lnk")
    if create_shortcut(exe_path, start_shortcut, INSTALL_DIR):
        print("✅ Ярлык создан в меню Пуск")

    print()
    print("========================================")
    print("    ✅ Установка завершена!")
    print("========================================")
    print()
    print(f"📂 Папка установки: {INSTALL_DIR}")
    print(f"🖥️  Ярлык на рабочем столе: {APP_NAME}")
    print(f"🏁 Ярлык в меню Пуск: {APP_NAME}")
    print()
    input("Нажмите Enter для выхода...")


if __name__ == "__main__":
    main()