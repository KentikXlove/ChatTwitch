import sys
import subprocess
import webbrowser
import os
import shutil
from pathlib import Path
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QHBoxLayout, QLabel, QAction, QMenu
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineProfile
from PyQt5.QtCore import QUrl, Qt, QSize, QTimer, pyqtSlot, QObject, pyqtSignal
from PyQt5.QtGui import QIcon, QCursor
from PyQt5.QtWebChannel import QWebChannel
from logger import get_logger
import json

logger = get_logger("window")

API_BASE = "http://127.0.0.1:5000"

# ===== ГЛОБАЛЬНАЯ ПЕРЕМЕННАЯ ДЛЯ ГЛАВНОГО ОКНА =====
overlay_window = None

# ===== СИГНАЛЬНЫЙ БУС ДЛЯ КРОСС-ТРЕДОВОЙ КОММУНИКАЦИИ =====
class SignalBus(QObject):
    open_user_window_signal = pyqtSignal(str)

signal_bus = SignalBus()


def ensure_qwebchannel_js():
    """Копирует qwebchannel.js в static/js, если его нет."""
    static_js_dir = Path("static/js")
    static_js_dir.mkdir(parents=True, exist_ok=True)
    target_file = static_js_dir / "qwebchannel.js"
    if target_file.exists():
        return str(target_file)

    try:
        from PyQt5 import QtCore
        qt_lib_dir = Path(QtCore.QLibraryInfo.location(QtCore.QLibraryInfo.LibrariesPath))
        possible_paths = [
            qt_lib_dir / "qml/QtWebChannel/qwebchannel.js",
            qt_lib_dir / "QtWebChannel/qwebchannel.js",
            Path(sys.prefix) / "lib/site-packages/PyQt5/Qt5/qml/QtWebChannel/qwebchannel.js",
            Path(sys.prefix) / "Lib/site-packages/PyQt5/Qt5/qml/QtWebChannel/qwebchannel.js",
        ]
        for path in possible_paths:
            if path.exists():
                shutil.copy2(path, target_file)
                logger.info(f"Скопирован qwebchannel.js из {path} в {target_file}")
                return str(target_file)
        logger.warning("qwebchannel.js не найден. Будет использован fallback.")
    except Exception as e:
        logger.warning(f"Не удалось скопировать qwebchannel.js: {e}")
    return None


class UserWindow(QMainWindow):
    """Независимое окно чата пользователя"""
    def __init__(self, username):
        super().__init__(None)  # Никакого родителя
        self.setWindowTitle(f"💬 {username}")
        self.resize(420, 540)
        self.setMinimumSize(320, 300)

        # Окно будет отдельным (не закрывается при закрытии главного)
        self.setAttribute(Qt.WA_DeleteOnClose)

        webview = QWebEngineView()
        webview.setUrl(QUrl(f"{API_BASE}/user/{username}"))
        self.setCentralWidget(webview)

        logger.info(f"Создано отдельное окно для {username}")


class OverlayWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Twitch Chat Overlay")
        self.resize(1100, 700)
        self.setMinimumSize(900, 600)

        try:
            self.setWindowIcon(QIcon("icon.ico"))
        except:
            pass

        self.setStyleSheet("""
            QMainWindow {
                background-color: #0a0a0f;
            }
        """)

        # Копируем qwebchannel.js в static/js, если нужно
        ensure_qwebchannel_js()

        self.webview = QWebEngineView()
        self.webview.setContextMenuPolicy(Qt.CustomContextMenu)
        self.webview.customContextMenuRequested.connect(self.show_context_menu)
        self.webview.setUrl(QUrl(f"{API_BASE}/app"))
        self.setCentralWidget(self.webview)

        self.user_windows = {}

        self.channel = QWebChannel()
        self.webview.page().setWebChannel(self.channel)
        self.channel.registerObject("pybridge", self)

        self.webview.loadFinished.connect(self.on_page_loaded)

        # ===== ПОДКЛЮЧАЕМ СИГНАЛ ДЛЯ ОТКРЫТИЯ ОКОН ИЗ ДРУГИХ ПОТОКОВ =====
        signal_bus.open_user_window_signal.connect(self.open_user_window)

        logger.info("Окно WebEngine создано")

    def on_page_loaded(self, ok):
        if ok:
            logger.info("Страница загружена, pybridge зарегистрирован через QWebChannel")

    @pyqtSlot(str)
    def open_user_window(self, username):
        logger.info(f"Открытие окна для пользователя: {username}")
        if not username:
            return

        # Если окно уже существует – переключиться на него
        if username in self.user_windows and self.user_windows[username].isVisible():
            self.user_windows[username].raise_()
            self.user_windows[username].activateWindow()
            return

        # Создаём без родителя
        window = UserWindow(username)  # без parent
        window.show()
        self.user_windows[username] = window

        def on_close():
            self.user_windows.pop(username, None)

        window.destroyed.connect(on_close)

    @pyqtSlot(str)
    def open_user_tab(self, username):
        logger.info(f"Открытие вкладки для пользователя: {username}")
        js_code = f"""
        (function() {{
            if (typeof window.addUserTab === 'function') {{
                window.addUserTab("{username}");
            }} else {{
                console.error("addUserTab not found");
            }}
        }})();
        """
        self.webview.page().runJavaScript(js_code)

    def show_context_menu(self, position):
        js_code = """
        (function() {
            var selection = window.getSelection();
            if (selection && selection.rangeCount > 0) {
                var range = selection.getRangeAt(0);
                var node = range.startContainer;
                if (node.nodeType === Node.TEXT_NODE) {
                    node = node.parentElement;
                }
                if (node && node.closest) {
                    var el = node.closest('.chat-username');
                    if (el) {
                        return el.textContent.trim();
                    }
                }
            }
            return null;
        })();
        """
        self.webview.page().runJavaScript(js_code, self._on_username_extracted)

    def _on_username_extracted(self, username):
        if not username:
            return
        logger.info(f"Извлечено имя: {username}")

        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: #111118;
                border: 1px solid #282836;
                border-radius: 10px;
                padding: 6px 0;
            }
            QMenu::item {
                padding: 8px 24px;
                color: #eaeaf0;
                font-size: 13px;
            }
            QMenu::item:selected {
                background-color: #20202c;
            }
            QMenu::separator {
                height: 1px;
                background-color: #282836;
                margin: 4px 12px;
            }
        """)

        action_open = QAction("📂 Открыть отдельно", self)
        action_open.triggered.connect(lambda: self.open_user_window(username))
        menu.addAction(action_open)

        action_tab = QAction("📋 Открыть во вкладке", self)
        action_tab.triggered.connect(lambda: self.open_user_tab(username))
        menu.addAction(action_tab)

        menu.addSeparator()

        action_copy = QAction("📋 Копировать имя", self)
        action_copy.triggered.connect(lambda: self.copy_username(username))
        menu.addAction(action_copy)

        action_twitch = QAction("👤 Профиль Twitch", self)
        action_twitch.triggered.connect(lambda: self.open_twitch_profile(username))
        menu.addAction(action_twitch)

        menu.exec_(QCursor.pos())

    def copy_username(self, username):
        clipboard = QApplication.clipboard()
        clipboard.setText(username)
        logger.info(f"Скопировано имя: {username}")

    def open_twitch_profile(self, username):
        webbrowser.open(f"https://twitch.tv/{username}")
        logger.info(f"Открыт профиль Twitch: {username}")

    def closeEvent(self, event):
        for window in list(self.user_windows.values()):
            window.close()
        event.accept()


def run_overlay_window():
    global overlay_window
    logger.info("Запуск оконного приложения")
    app = QApplication(sys.argv)
    app.setApplicationName("Twitch Chat Overlay")
    overlay_window = OverlayWindow()
    overlay_window.show()
    logger.info("Окно отображено")
    sys.exit(app.exec_())